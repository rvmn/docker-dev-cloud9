process.stdout.write("other program\n");
process.exit(44);
