// For testing meteor run-command.
main = function (argv) {
  console.log("argv", argv);
  return 17;
};
