// This will execute a shell script, print its output, and process.exit(0).
Npm.require('meteor-test-executable').doIt();
