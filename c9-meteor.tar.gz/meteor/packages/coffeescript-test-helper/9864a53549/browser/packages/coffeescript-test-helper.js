(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/coffeescript-test-helper/exporting.coffee.js             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                          

COFFEESCRIPT_EXPORTED = 123;
///////////////////////////////////////////////////////////////////////

}).call(this);
