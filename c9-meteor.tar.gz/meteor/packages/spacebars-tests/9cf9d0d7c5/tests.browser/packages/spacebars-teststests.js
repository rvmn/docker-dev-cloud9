(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/spacebars-tests/template.template_tests.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__define__("spacebars_template_test_aaa", (function() {                                                      // 2
  var view = this;                                                                                                    // 3
  return "aaa";                                                                                                       // 4
}));                                                                                                                  // 5
                                                                                                                      // 6
Template.__define__("spacebars_template_test_bbb", (function() {                                                      // 7
  var view = this;                                                                                                    // 8
  return "bbb";                                                                                                       // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__define__("spacebars_template_test_bracketed_this", (function() {                                           // 12
  var view = this;                                                                                                    // 13
  return [ "[", Blaze.View(function() {                                                                               // 14
    return Spacebars.mustache(view.lookup("."));                                                                      // 15
  }), "]" ];                                                                                                          // 16
}));                                                                                                                  // 17
                                                                                                                      // 18
Template.__define__("spacebars_template_test_span_this", (function() {                                                // 19
  var view = this;                                                                                                    // 20
  return HTML.SPAN(Blaze.View(function() {                                                                            // 21
    return Spacebars.mustache(view.lookup("."));                                                                      // 22
  }));                                                                                                                // 23
}));                                                                                                                  // 24
                                                                                                                      // 25
Template.__define__("spacebars_template_test_content", (function() {                                                  // 26
  var view = this;                                                                                                    // 27
  return Blaze.InOuterTemplateScope(view, function() {                                                                // 28
    return Spacebars.include(function() {                                                                             // 29
      return Spacebars.call(view.templateContentBlock);                                                               // 30
    });                                                                                                               // 31
  });                                                                                                                 // 32
}));                                                                                                                  // 33
                                                                                                                      // 34
Template.__define__("spacebars_template_test_elsecontent", (function() {                                              // 35
  var view = this;                                                                                                    // 36
  return Blaze.InOuterTemplateScope(view, function() {                                                                // 37
    return Spacebars.include(function() {                                                                             // 38
      return Spacebars.call(view.templateElseBlock);                                                                  // 39
    });                                                                                                               // 40
  });                                                                                                                 // 41
}));                                                                                                                  // 42
                                                                                                                      // 43
Template.__define__("spacebars_template_test_iftemplate", (function() {                                               // 44
  var view = this;                                                                                                    // 45
  return Blaze.If(function() {                                                                                        // 46
    return Spacebars.call(view.lookup("condition"));                                                                  // 47
  }, function() {                                                                                                     // 48
    return [ "\n    ", Blaze.InOuterTemplateScope(view, function() {                                                  // 49
      return Spacebars.include(function() {                                                                           // 50
        return Spacebars.call(view.templateContentBlock);                                                             // 51
      });                                                                                                             // 52
    }), "\n  " ];                                                                                                     // 53
  }, function() {                                                                                                     // 54
    return [ "\n    ", Blaze.InOuterTemplateScope(view, function() {                                                  // 55
      return Spacebars.include(function() {                                                                           // 56
        return Spacebars.call(view.templateElseBlock);                                                                // 57
      });                                                                                                             // 58
    }), "\n  " ];                                                                                                     // 59
  });                                                                                                                 // 60
}));                                                                                                                  // 61
                                                                                                                      // 62
Template.__define__("spacebars_template_test_simple_helper", (function() {                                            // 63
  var view = this;                                                                                                    // 64
  return Blaze.View(function() {                                                                                      // 65
    return Spacebars.mustache(view.lookup("foo"), view.lookup("bar"));                                                // 66
  });                                                                                                                 // 67
}));                                                                                                                  // 68
                                                                                                                      // 69
Template.__define__("spacebars_template_test_dynamic_template", (function() {                                         // 70
  var view = this;                                                                                                    // 71
  return Spacebars.include(view.lookupTemplate("foo"));                                                               // 72
}));                                                                                                                  // 73
                                                                                                                      // 74
Template.__define__("spacebars_template_test_interpolate_attribute", (function() {                                    // 75
  var view = this;                                                                                                    // 76
  return HTML.DIV({                                                                                                   // 77
    "class": function() {                                                                                             // 78
      return [ "aaa", Spacebars.mustache(view.lookup("foo"), view.lookup("bar")), "zzz" ];                            // 79
    }                                                                                                                 // 80
  });                                                                                                                 // 81
}));                                                                                                                  // 82
                                                                                                                      // 83
Template.__define__("spacebars_template_test_dynamic_attrs", (function() {                                            // 84
  var view = this;                                                                                                    // 85
  return HTML.SPAN(HTML.Attrs(function() {                                                                            // 86
    return Spacebars.attrMustache(view.lookup("attrsObj"));                                                           // 87
  }, function() {                                                                                                     // 88
    return Spacebars.attrMustache(view.lookup("singleAttr"));                                                         // 89
  }, function() {                                                                                                     // 90
    return Spacebars.attrMustache(view.lookup("nonexistent"));                                                        // 91
  }), "hi");                                                                                                          // 92
}));                                                                                                                  // 93
                                                                                                                      // 94
Template.__define__("spacebars_template_test_triple", (function() {                                                   // 95
  var view = this;                                                                                                    // 96
  return Blaze.View(function() {                                                                                      // 97
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("html")));                                                // 98
  });                                                                                                                 // 99
}));                                                                                                                  // 100
                                                                                                                      // 101
Template.__define__("spacebars_template_test_triple2", (function() {                                                  // 102
  var view = this;                                                                                                    // 103
  return [ "x", Blaze.View(function() {                                                                               // 104
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("html")));                                                // 105
  }), Blaze.View(function() {                                                                                         // 106
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("html2")));                                               // 107
  }), Blaze.View(function() {                                                                                         // 108
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("html3")));                                               // 109
  }), "y" ];                                                                                                          // 110
}));                                                                                                                  // 111
                                                                                                                      // 112
Template.__define__("spacebars_template_test_inclusion_args", (function() {                                           // 113
  var view = this;                                                                                                    // 114
  return Spacebars.TemplateWith(function() {                                                                          // 115
    return Spacebars.call(view.lookup("bar"));                                                                        // 116
  }, function() {                                                                                                     // 117
    return Spacebars.include(view.lookupTemplate("foo"));                                                             // 118
  });                                                                                                                 // 119
}));                                                                                                                  // 120
                                                                                                                      // 121
Template.__define__("spacebars_template_test_inclusion_args2", (function() {                                          // 122
  var view = this;                                                                                                    // 123
  return Spacebars.TemplateWith(function() {                                                                          // 124
    return Spacebars.dataMustache(view.lookup("bar"), Spacebars.kw({                                                  // 125
      q: view.lookup("baz")                                                                                           // 126
    }));                                                                                                              // 127
  }, function() {                                                                                                     // 128
    return Spacebars.include(view.lookupTemplate("foo"));                                                             // 129
  });                                                                                                                 // 130
}));                                                                                                                  // 131
                                                                                                                      // 132
Template.__define__("spacebars_template_test_inclusion_dotted_args", (function() {                                    // 133
  var view = this;                                                                                                    // 134
  return Spacebars.TemplateWith(function() {                                                                          // 135
    return Spacebars.call(Spacebars.dot(view.lookup("bar"), "baz"));                                                  // 136
  }, function() {                                                                                                     // 137
    return Spacebars.include(view.lookupTemplate("foo"));                                                             // 138
  });                                                                                                                 // 139
}));                                                                                                                  // 140
                                                                                                                      // 141
Template.__define__("spacebars_template_test_inclusion_slashed_args", (function() {                                   // 142
  var view = this;                                                                                                    // 143
  return Spacebars.TemplateWith(function() {                                                                          // 144
    return Spacebars.call(Spacebars.dot(view.lookup("bar"), "baz"));                                                  // 145
  }, function() {                                                                                                     // 146
    return Spacebars.include(view.lookupTemplate("foo"));                                                             // 147
  });                                                                                                                 // 148
}));                                                                                                                  // 149
                                                                                                                      // 150
Template.__define__("spacebars_template_test_block_helper", (function() {                                             // 151
  var view = this;                                                                                                    // 152
  return Spacebars.include(view.lookupTemplate("foo"), function() {                                                   // 153
    return "\n    bar\n  ";                                                                                           // 154
  }, function() {                                                                                                     // 155
    return "\n    baz\n  ";                                                                                           // 156
  });                                                                                                                 // 157
}));                                                                                                                  // 158
                                                                                                                      // 159
Template.__define__("spacebars_template_test_block_helper_function_one_string_arg", (function() {                     // 160
  var view = this;                                                                                                    // 161
  return Spacebars.TemplateWith(function() {                                                                          // 162
    return "bar";                                                                                                     // 163
  }, function() {                                                                                                     // 164
    return Spacebars.include(view.lookupTemplate("foo"), function() {                                                 // 165
      return "\n    content\n  ";                                                                                     // 166
    });                                                                                                               // 167
  });                                                                                                                 // 168
}));                                                                                                                  // 169
                                                                                                                      // 170
Template.__define__("spacebars_template_test_block_helper_function_one_helper_arg", (function() {                     // 171
  var view = this;                                                                                                    // 172
  return Spacebars.TemplateWith(function() {                                                                          // 173
    return Spacebars.call(view.lookup("bar"));                                                                        // 174
  }, function() {                                                                                                     // 175
    return Spacebars.include(view.lookupTemplate("foo"), function() {                                                 // 176
      return "\n    content\n  ";                                                                                     // 177
    });                                                                                                               // 178
  });                                                                                                                 // 179
}));                                                                                                                  // 180
                                                                                                                      // 181
Template.__define__("spacebars_template_test_block_helper_component_one_helper_arg", (function() {                    // 182
  var view = this;                                                                                                    // 183
  return Blaze.If(function() {                                                                                        // 184
    return Spacebars.call(view.lookup("bar"));                                                                        // 185
  }, function() {                                                                                                     // 186
    return "\n    content\n  ";                                                                                       // 187
  });                                                                                                                 // 188
}));                                                                                                                  // 189
                                                                                                                      // 190
Template.__define__("spacebars_template_test_block_helper_component_three_helper_args", (function() {                 // 191
  var view = this;                                                                                                    // 192
  return Blaze.If(function() {                                                                                        // 193
    return Spacebars.dataMustache(view.lookup("equals"), view.lookup("bar_or_baz"), "bar");                           // 194
  }, function() {                                                                                                     // 195
    return "\n    content\n  ";                                                                                       // 196
  });                                                                                                                 // 197
}));                                                                                                                  // 198
                                                                                                                      // 199
Template.__define__("spacebars_template_test_block_helper_dotted_arg", (function() {                                  // 200
  var view = this;                                                                                                    // 201
  return Spacebars.TemplateWith(function() {                                                                          // 202
    return Spacebars.dataMustache(Spacebars.dot(view.lookup("bar"), "baz"), view.lookup("qux"));                      // 203
  }, function() {                                                                                                     // 204
    return Spacebars.include(view.lookupTemplate("foo"), function() {                                                 // 205
      return null;                                                                                                    // 206
    });                                                                                                               // 207
  });                                                                                                                 // 208
}));                                                                                                                  // 209
                                                                                                                      // 210
Template.__define__("spacebars_template_test_nested_content", (function() {                                           // 211
  var view = this;                                                                                                    // 212
  return Spacebars.TemplateWith(function() {                                                                          // 213
    return {                                                                                                          // 214
      condition: Spacebars.call(view.lookup("flag"))                                                                  // 215
    };                                                                                                                // 216
  }, function() {                                                                                                     // 217
    return Spacebars.include(view.lookupTemplate("spacebars_template_test_iftemplate"), function() {                  // 218
      return "\n    hello\n  ";                                                                                       // 219
    }, function() {                                                                                                   // 220
      return "\n    world\n  ";                                                                                       // 221
    });                                                                                                               // 222
  });                                                                                                                 // 223
}));                                                                                                                  // 224
                                                                                                                      // 225
Template.__define__("spacebars_template_test_iftemplate2", (function() {                                              // 226
  var view = this;                                                                                                    // 227
  return Spacebars.TemplateWith(function() {                                                                          // 228
    return {                                                                                                          // 229
      condition: Spacebars.call(view.lookup("flag"))                                                                  // 230
    };                                                                                                                // 231
  }, function() {                                                                                                     // 232
    return Spacebars.include(view.lookupTemplate("spacebars_template_test_iftemplate"), function() {                  // 233
      return [ "\n    ", Blaze.InOuterTemplateScope(view, function() {                                                // 234
        return Spacebars.include(function() {                                                                         // 235
          return Spacebars.call(view.templateContentBlock);                                                           // 236
        });                                                                                                           // 237
      }), "\n  " ];                                                                                                   // 238
    }, function() {                                                                                                   // 239
      return [ "\n    ", Blaze.InOuterTemplateScope(view, function() {                                                // 240
        return Spacebars.include(function() {                                                                         // 241
          return Spacebars.call(view.templateElseBlock);                                                              // 242
        });                                                                                                           // 243
      }), "\n  " ];                                                                                                   // 244
    });                                                                                                               // 245
  });                                                                                                                 // 246
}));                                                                                                                  // 247
                                                                                                                      // 248
Template.__define__("spacebars_template_test_nested_content2", (function() {                                          // 249
  var view = this;                                                                                                    // 250
  return Spacebars.TemplateWith(function() {                                                                          // 251
    return {                                                                                                          // 252
      flag: Spacebars.call(view.lookup("x"))                                                                          // 253
    };                                                                                                                // 254
  }, function() {                                                                                                     // 255
    return Spacebars.include(view.lookupTemplate("spacebars_template_test_iftemplate2"), function() {                 // 256
      return "\n    hello\n  ";                                                                                       // 257
    }, function() {                                                                                                   // 258
      return "\n    world\n  ";                                                                                       // 259
    });                                                                                                               // 260
  });                                                                                                                 // 261
}));                                                                                                                  // 262
                                                                                                                      // 263
Template.__define__("spacebars_template_test_if", (function() {                                                       // 264
  var view = this;                                                                                                    // 265
  return Blaze.If(function() {                                                                                        // 266
    return Spacebars.call(view.lookup("foo"));                                                                        // 267
  }, function() {                                                                                                     // 268
    return [ "\n    ", Blaze.View(function() {                                                                        // 269
      return Spacebars.mustache(view.lookup("bar"));                                                                  // 270
    }), "\n  " ];                                                                                                     // 271
  }, function() {                                                                                                     // 272
    return [ "\n    ", Blaze.View(function() {                                                                        // 273
      return Spacebars.mustache(view.lookup("baz"));                                                                  // 274
    }), "\n  " ];                                                                                                     // 275
  });                                                                                                                 // 276
}));                                                                                                                  // 277
                                                                                                                      // 278
Template.__define__("spacebars_template_test_if_in_with", (function() {                                               // 279
  var view = this;                                                                                                    // 280
  return Spacebars.With(function() {                                                                                  // 281
    return Spacebars.call(view.lookup("foo"));                                                                        // 282
  }, function() {                                                                                                     // 283
    return [ "\n    ", Blaze.View(function() {                                                                        // 284
      return Spacebars.mustache(view.lookup("bar"));                                                                  // 285
    }), "\n    ", Blaze.If(function() {                                                                               // 286
      return true;                                                                                                    // 287
    }, function() {                                                                                                   // 288
      return [ "\n      ", Blaze.View(function() {                                                                    // 289
        return Spacebars.mustache(view.lookup("bar"));                                                                // 290
      }), "\n    " ];                                                                                                 // 291
    }), "\n  " ];                                                                                                     // 292
  });                                                                                                                 // 293
}));                                                                                                                  // 294
                                                                                                                      // 295
Template.__define__("spacebars_template_test_each", (function() {                                                     // 296
  var view = this;                                                                                                    // 297
  return Blaze.Each(function() {                                                                                      // 298
    return Spacebars.call(view.lookup("items"));                                                                      // 299
  }, function() {                                                                                                     // 300
    return [ "\n    ", Blaze.View(function() {                                                                        // 301
      return Spacebars.mustache(view.lookup("text"));                                                                 // 302
    }), "\n  " ];                                                                                                     // 303
  }, function() {                                                                                                     // 304
    return "\n    else-clause\n  ";                                                                                   // 305
  });                                                                                                                 // 306
}));                                                                                                                  // 307
                                                                                                                      // 308
Template.__define__("spacebars_template_test_dots", (function() {                                                     // 309
  var view = this;                                                                                                    // 310
  return Spacebars.With(function() {                                                                                  // 311
    return Spacebars.call(view.lookup("foo"));                                                                        // 312
  }, function() {                                                                                                     // 313
    return [ "\n    A\n    ", Spacebars.With(function() {                                                             // 314
      return Spacebars.call(view.lookup("bar"));                                                                      // 315
    }, function() {                                                                                                   // 316
      return [ "\n      B\n      \n      ", Blaze.If(function() {                                                     // 317
        return true;                                                                                                  // 318
      }, function() {                                                                                                 // 319
        return [ "\n        C\n        ", Blaze.Each(function() {                                                     // 320
          return Spacebars.call(view.lookup("items"));                                                                // 321
        }, function() {                                                                                               // 322
          return [ "\n          D\n          \n          ", Spacebars.include(view.lookupTemplate("spacebars_template_test_dots_subtemplate")), "\n          ", Spacebars.TemplateWith(function() {
            return Spacebars.call(view.lookup(".."));                                                                 // 324
          }, function() {                                                                                             // 325
            return Spacebars.include(view.lookupTemplate("spacebars_template_test_dots_subtemplate"));                // 326
          }), "\n        " ];                                                                                         // 327
        }), "\n      " ];                                                                                             // 328
      }), "\n    " ];                                                                                                 // 329
    }), "\n  " ];                                                                                                     // 330
  });                                                                                                                 // 331
}));                                                                                                                  // 332
                                                                                                                      // 333
Template.__define__("spacebars_template_test_dots_subtemplate", (function() {                                         // 334
  var view = this;                                                                                                    // 335
  return [ "TITLE\n  1", Blaze.View(function() {                                                                      // 336
    return Spacebars.mustache(view.lookup("title"));                                                                  // 337
  }), "\n  2", Blaze.View(function() {                                                                                // 338
    return Spacebars.mustache(Spacebars.dot(view.lookup("."), "title"));                                              // 339
  }), "\n  3", Blaze.View(function() {                                                                                // 340
    return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "title"));                                             // 341
  }), "\n  4", Blaze.View(function() {                                                                                // 342
    return Spacebars.mustache(Spacebars.dot(view.lookup("..."), "title"));                                            // 343
  }), "\n\n  GETTITLE\n  5", Blaze.View(function() {                                                                  // 344
    return Spacebars.mustache(view.lookup("getTitle"), view.lookup("."));                                             // 345
  }), "\n  6", Blaze.View(function() {                                                                                // 346
    return Spacebars.mustache(view.lookup("getTitle"), view.lookup(".."));                                            // 347
  }), "\n  7", Blaze.View(function() {                                                                                // 348
    return Spacebars.mustache(view.lookup("getTitle"), view.lookup("..."));                                           // 349
  }) ];                                                                                                               // 350
}));                                                                                                                  // 351
                                                                                                                      // 352
Template.__define__("spacebars_template_test_select_tag", (function() {                                               // 353
  var view = this;                                                                                                    // 354
  return HTML.SELECT("\n    ", Blaze.Each(function() {                                                                // 355
    return Spacebars.call(view.lookup("optgroups"));                                                                  // 356
  }, function() {                                                                                                     // 357
    return [ "\n      ", HTML.OPTGROUP({                                                                              // 358
      label: function() {                                                                                             // 359
        return Spacebars.mustache(view.lookup("label"));                                                              // 360
      }                                                                                                               // 361
    }, "\n        ", Blaze.Each(function() {                                                                          // 362
      return Spacebars.call(view.lookup("options"));                                                                  // 363
    }, function() {                                                                                                   // 364
      return [ "\n          ", HTML.OPTION(HTML.Attrs({                                                               // 365
        value: function() {                                                                                           // 366
          return Spacebars.mustache(view.lookup("value"));                                                            // 367
        }                                                                                                             // 368
      }, function() {                                                                                                 // 369
        return Spacebars.attrMustache(view.lookup("selectedAttr"));                                                   // 370
      }), Blaze.View(function() {                                                                                     // 371
        return Spacebars.mustache(view.lookup("label"));                                                              // 372
      })), "\n        " ];                                                                                            // 373
    }), "\n      "), "\n    " ];                                                                                      // 374
  }), "\n  ");                                                                                                        // 375
}));                                                                                                                  // 376
                                                                                                                      // 377
Template.__define__("test_template_issue770", (function() {                                                           // 378
  var view = this;                                                                                                    // 379
  return [ Spacebars.With(function() {                                                                                // 380
    return Spacebars.call(view.lookup("value1"));                                                                     // 381
  }, function() {                                                                                                     // 382
    return [ "\n    ", Blaze.View(function() {                                                                        // 383
      return Spacebars.mustache(view.lookup("."));                                                                    // 384
    }), "\n  " ];                                                                                                     // 385
  }, function() {                                                                                                     // 386
    return "\n    xxx\n  ";                                                                                           // 387
  }), "\n\n  ", Spacebars.With(function() {                                                                           // 388
    return Spacebars.call(view.lookup("value2"));                                                                     // 389
  }, function() {                                                                                                     // 390
    return [ "\n    ", Blaze.View(function() {                                                                        // 391
      return Spacebars.mustache(view.lookup("."));                                                                    // 392
    }), "\n  " ];                                                                                                     // 393
  }, function() {                                                                                                     // 394
    return "\n    xxx\n  ";                                                                                           // 395
  }), "\n\n  ", Spacebars.With(function() {                                                                           // 396
    return Spacebars.call(view.lookup("value1"));                                                                     // 397
  }, function() {                                                                                                     // 398
    return [ "\n    ", Blaze.View(function() {                                                                        // 399
      return Spacebars.mustache(view.lookup("."));                                                                    // 400
    }), "\n  " ];                                                                                                     // 401
  }), "\n\n  ", Spacebars.With(function() {                                                                           // 402
    return Spacebars.call(view.lookup("value2"));                                                                     // 403
  }, function() {                                                                                                     // 404
    return [ "\n    ", Blaze.View(function() {                                                                        // 405
      return Spacebars.mustache(view.lookup("."));                                                                    // 406
    }), "\n  " ];                                                                                                     // 407
  }) ];                                                                                                               // 408
}));                                                                                                                  // 409
                                                                                                                      // 410
Template.__define__("spacebars_template_test_tricky_attrs", (function() {                                             // 411
  var view = this;                                                                                                    // 412
  return [ HTML.INPUT({                                                                                               // 413
    type: function() {                                                                                                // 414
      return Spacebars.mustache(view.lookup("theType"));                                                              // 415
    }                                                                                                                 // 416
  }), HTML.INPUT({                                                                                                    // 417
    type: "checkbox",                                                                                                 // 418
    "class": function() {                                                                                             // 419
      return Spacebars.mustache(view.lookup("theClass"));                                                             // 420
    }                                                                                                                 // 421
  }) ];                                                                                                               // 422
}));                                                                                                                  // 423
                                                                                                                      // 424
Template.__define__("spacebars_template_test_no_data", (function() {                                                  // 425
  var view = this;                                                                                                    // 426
  return [ Blaze.View(function() {                                                                                    // 427
    return Spacebars.mustache(Spacebars.dot(view.lookup("."), "foo"));                                                // 428
  }), Blaze.Unless(function() {                                                                                       // 429
    return Spacebars.call(Spacebars.dot(view.lookup("."), "bar"));                                                    // 430
  }, function() {                                                                                                     // 431
    return "asdf";                                                                                                    // 432
  }) ];                                                                                                               // 433
}));                                                                                                                  // 434
                                                                                                                      // 435
Template.__define__("spacebars_template_test_textarea", (function() {                                                 // 436
  var view = this;                                                                                                    // 437
  return HTML.TEXTAREA({                                                                                              // 438
    value: function() {                                                                                               // 439
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 440
    }                                                                                                                 // 441
  });                                                                                                                 // 442
}));                                                                                                                  // 443
                                                                                                                      // 444
Template.__define__("spacebars_template_test_textarea2", (function() {                                                // 445
  var view = this;                                                                                                    // 446
  return HTML.TEXTAREA({                                                                                              // 447
    value: function() {                                                                                               // 448
      return Blaze.If(function() {                                                                                    // 449
        return Spacebars.call(view.lookup("foo"));                                                                    // 450
      }, function() {                                                                                                 // 451
        return "</not a tag>";                                                                                        // 452
      }, function() {                                                                                                 // 453
        return "<also not a tag>";                                                                                    // 454
      });                                                                                                             // 455
    }                                                                                                                 // 456
  });                                                                                                                 // 457
}));                                                                                                                  // 458
                                                                                                                      // 459
Template.__define__("spacebars_template_test_textarea3", (function() {                                                // 460
  var view = this;                                                                                                    // 461
  return HTML.TEXTAREA({                                                                                              // 462
    id: "myTextarea",                                                                                                 // 463
    value: function() {                                                                                               // 464
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 465
    }                                                                                                                 // 466
  });                                                                                                                 // 467
}));                                                                                                                  // 468
                                                                                                                      // 469
Template.__define__("spacebars_template_test_textarea_each", (function() {                                            // 470
  var view = this;                                                                                                    // 471
  return HTML.TEXTAREA({                                                                                              // 472
    value: function() {                                                                                               // 473
      return Blaze.Each(function() {                                                                                  // 474
        return Spacebars.call(view.lookup("foo"));                                                                    // 475
      }, function() {                                                                                                 // 476
        return [ "<not a tag ", Blaze.View(function() {                                                               // 477
          return Spacebars.mustache(view.lookup("."));                                                                // 478
        }), " " ];                                                                                                    // 479
      }, function() {                                                                                                 // 480
        return "<>";                                                                                                  // 481
      });                                                                                                             // 482
    }                                                                                                                 // 483
  });                                                                                                                 // 484
}));                                                                                                                  // 485
                                                                                                                      // 486
Template.__define__("spacebars_template_test_defer_in_rendered", (function() {                                        // 487
  var view = this;                                                                                                    // 488
  return Blaze.Each(function() {                                                                                      // 489
    return Spacebars.call(view.lookup("items"));                                                                      // 490
  }, function() {                                                                                                     // 491
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_template_test_defer_in_rendered_subtemplate")), "\n  " ];
  });                                                                                                                 // 493
}));                                                                                                                  // 494
                                                                                                                      // 495
Template.__define__("spacebars_template_test_defer_in_rendered_subtemplate", (function() {                            // 496
  var view = this;                                                                                                    // 497
  return "";                                                                                                          // 498
}));                                                                                                                  // 499
                                                                                                                      // 500
Template.__define__("spacebars_template_test_with_someData", (function() {                                            // 501
  var view = this;                                                                                                    // 502
  return Spacebars.With(function() {                                                                                  // 503
    return Spacebars.call(view.lookup("someData"));                                                                   // 504
  }, function() {                                                                                                     // 505
    return [ "\n    ", Blaze.View(function() {                                                                        // 506
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 507
    }), " ", Blaze.View(function() {                                                                                  // 508
      return Spacebars.mustache(view.lookup("bar"));                                                                  // 509
    }), "\n  " ];                                                                                                     // 510
  });                                                                                                                 // 511
}));                                                                                                                  // 512
                                                                                                                      // 513
Template.__define__("spacebars_template_test_each_stops", (function() {                                               // 514
  var view = this;                                                                                                    // 515
  return Blaze.Each(function() {                                                                                      // 516
    return Spacebars.call(view.lookup("items"));                                                                      // 517
  }, function() {                                                                                                     // 518
    return "\n    x\n  ";                                                                                             // 519
  });                                                                                                                 // 520
}));                                                                                                                  // 521
                                                                                                                      // 522
Template.__define__("spacebars_template_test_block_helpers_in_attribute", (function() {                               // 523
  var view = this;                                                                                                    // 524
  return HTML.DIV({                                                                                                   // 525
    "class": function() {                                                                                             // 526
      return Blaze.Each(function() {                                                                                  // 527
        return Spacebars.call(view.lookup("classes"));                                                                // 528
      }, function() {                                                                                                 // 529
        return Blaze.If(function() {                                                                                  // 530
          return Spacebars.dataMustache(view.lookup("startsLowerCase"), view.lookup("name"));                         // 531
        }, function() {                                                                                               // 532
          return [ Blaze.View(function() {                                                                            // 533
            return Spacebars.mustache(view.lookup("name"));                                                           // 534
          }), " " ];                                                                                                  // 535
        });                                                                                                           // 536
      }, function() {                                                                                                 // 537
        return "none";                                                                                                // 538
      });                                                                                                             // 539
    }                                                                                                                 // 540
  }, "Smurf");                                                                                                        // 541
}));                                                                                                                  // 542
                                                                                                                      // 543
Template.__define__("spacebars_template_test_block_helpers_in_attribute_2", (function() {                             // 544
  var view = this;                                                                                                    // 545
  return HTML.INPUT({                                                                                                 // 546
    value: function() {                                                                                               // 547
      return Blaze.If(function() {                                                                                    // 548
        return Spacebars.call(view.lookup("foo"));                                                                    // 549
      }, function() {                                                                                                 // 550
        return '"';                                                                                                   // 551
      }, function() {                                                                                                 // 552
        return [ "&", HTML.CharRef({                                                                                  // 553
          html: "&lt;",                                                                                               // 554
          str: "<"                                                                                                    // 555
        }), "></x>" ];                                                                                                // 556
      });                                                                                                             // 557
    }                                                                                                                 // 558
  });                                                                                                                 // 559
}));                                                                                                                  // 560
                                                                                                                      // 561
Template.__define__("spacebars_template_test_constant_each_argument", (function() {                                   // 562
  var view = this;                                                                                                    // 563
  return Spacebars.With(function() {                                                                                  // 564
    return Spacebars.call(view.lookup("someData"));                                                                   // 565
  }, function() {                                                                                                     // 566
    return [ "\n    ", Blaze.Each(function() {                                                                        // 567
      return Spacebars.call(view.lookup("anArray"));                                                                  // 568
    }, function() {                                                                                                   // 569
      return [ "\n      ", Blaze.View(function() {                                                                    // 570
        return Spacebars.mustache(view.lookup("justReturn"), view.lookup("."));                                       // 571
      }), "\n    " ];                                                                                                 // 572
    }), "\n    ", Blaze.View(function() {                                                                             // 573
      return Spacebars.mustache(view.lookup("."));                                                                    // 574
    }), "\n  " ];                                                                                                     // 575
  });                                                                                                                 // 576
}));                                                                                                                  // 577
                                                                                                                      // 578
Template.__define__("spacebars_template_test_markdown_basic", (function() {                                           // 579
  var view = this;                                                                                                    // 580
  return Spacebars.With(function() {                                                                                  // 581
    return Spacebars.call(view.lookup("obj"));                                                                        // 582
  }, function() {                                                                                                     // 583
    return [ "\n    ", Spacebars.include(view.lookupTemplate("markdown"), function() {                                // 584
      return [ "\n", Blaze.View(function() {                                                                          // 585
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 586
      }), "\n/each}}\n\n<b>", Blaze.View(function() {                                                                 // 587
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 588
      }), "</b>\n<b>/each}}</b>\n\n* ", Blaze.View(function() {                                                       // 589
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 590
      }), "\n* /each}}\n\n* <b>", Blaze.View(function() {                                                             // 591
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 592
      }), "</b>\n* <b>/each}}</b>\n\nsome paragraph to fix showdown's four space parsing below.\n\n    ", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 594
      }), "\n    /each}}\n\n    <b>", Blaze.View(function() {                                                         // 595
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 596
      }), "</b>\n    <b>/each}}</b>\n\n&gt\n\n* &gt\n\n`&gt`\n\n    &gt\n\n&gt;\n\n* &gt;\n\n`&gt;`\n\n    &gt;\n\n`", Blaze.View(function() {
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 598
      }), "`\n`/each}}`\n\n`<b>", Blaze.View(function() {                                                             // 599
        return Spacebars.mustache(view.lookup("hi"));                                                                 // 600
      }), "</b>`\n`<b>/each}}`\n\n    " ];                                                                            // 601
    }), "\n  " ];                                                                                                     // 602
  });                                                                                                                 // 603
}));                                                                                                                  // 604
                                                                                                                      // 605
Template.__define__("spacebars_template_test_markdown_if", (function() {                                              // 606
  var view = this;                                                                                                    // 607
  return Spacebars.include(view.lookupTemplate("markdown"), function() {                                              // 608
    return [ "\n\n", Blaze.If(function() {                                                                            // 609
      return Spacebars.call(view.lookup("cond"));                                                                     // 610
    }, function() {                                                                                                   // 611
      return "true";                                                                                                  // 612
    }, function() {                                                                                                   // 613
      return "false";                                                                                                 // 614
    }), "\n\n<b>", Blaze.If(function() {                                                                              // 615
      return Spacebars.call(view.lookup("cond"));                                                                     // 616
    }, function() {                                                                                                   // 617
      return "true";                                                                                                  // 618
    }, function() {                                                                                                   // 619
      return "false";                                                                                                 // 620
    }), "</b>\n\n* ", Blaze.If(function() {                                                                           // 621
      return Spacebars.call(view.lookup("cond"));                                                                     // 622
    }, function() {                                                                                                   // 623
      return "true";                                                                                                  // 624
    }, function() {                                                                                                   // 625
      return "false";                                                                                                 // 626
    }), "\n\n* <b>", Blaze.If(function() {                                                                            // 627
      return Spacebars.call(view.lookup("cond"));                                                                     // 628
    }, function() {                                                                                                   // 629
      return "true";                                                                                                  // 630
    }, function() {                                                                                                   // 631
      return "false";                                                                                                 // 632
    }), "</b>\n\nsome paragraph to fix showdown's four space parsing below.\n\n    ", Blaze.If(function() {           // 633
      return Spacebars.call(view.lookup("cond"));                                                                     // 634
    }, function() {                                                                                                   // 635
      return "true";                                                                                                  // 636
    }, function() {                                                                                                   // 637
      return "false";                                                                                                 // 638
    }), "\n\n    <b>", Blaze.If(function() {                                                                          // 639
      return Spacebars.call(view.lookup("cond"));                                                                     // 640
    }, function() {                                                                                                   // 641
      return "true";                                                                                                  // 642
    }, function() {                                                                                                   // 643
      return "false";                                                                                                 // 644
    }), "</b>\n\n`", Blaze.If(function() {                                                                            // 645
      return Spacebars.call(view.lookup("cond"));                                                                     // 646
    }, function() {                                                                                                   // 647
      return "true";                                                                                                  // 648
    }, function() {                                                                                                   // 649
      return "false";                                                                                                 // 650
    }), "`\n\n`<b>", Blaze.If(function() {                                                                            // 651
      return Spacebars.call(view.lookup("cond"));                                                                     // 652
    }, function() {                                                                                                   // 653
      return "true";                                                                                                  // 654
    }, function() {                                                                                                   // 655
      return "false";                                                                                                 // 656
    }), "</b>`\n\n  " ];                                                                                              // 657
  });                                                                                                                 // 658
}));                                                                                                                  // 659
                                                                                                                      // 660
Template.__define__("spacebars_template_test_markdown_each", (function() {                                            // 661
  var view = this;                                                                                                    // 662
  return Spacebars.include(view.lookupTemplate("markdown"), function() {                                              // 663
    return [ "\n\n", Blaze.Each(function() {                                                                          // 664
      return Spacebars.call(view.lookup("seq"));                                                                      // 665
    }, function() {                                                                                                   // 666
      return Blaze.View(function() {                                                                                  // 667
        return Spacebars.mustache(view.lookup("."));                                                                  // 668
      });                                                                                                             // 669
    }), "\n\n<b>", Blaze.Each(function() {                                                                            // 670
      return Spacebars.call(view.lookup("seq"));                                                                      // 671
    }, function() {                                                                                                   // 672
      return Blaze.View(function() {                                                                                  // 673
        return Spacebars.mustache(view.lookup("."));                                                                  // 674
      });                                                                                                             // 675
    }), "</b>\n\n* ", Blaze.Each(function() {                                                                         // 676
      return Spacebars.call(view.lookup("seq"));                                                                      // 677
    }, function() {                                                                                                   // 678
      return Blaze.View(function() {                                                                                  // 679
        return Spacebars.mustache(view.lookup("."));                                                                  // 680
      });                                                                                                             // 681
    }), "\n\n* <b>", Blaze.Each(function() {                                                                          // 682
      return Spacebars.call(view.lookup("seq"));                                                                      // 683
    }, function() {                                                                                                   // 684
      return Blaze.View(function() {                                                                                  // 685
        return Spacebars.mustache(view.lookup("."));                                                                  // 686
      });                                                                                                             // 687
    }), "</b>\n\nsome paragraph to fix showdown's four space parsing below.\n\n    ", Blaze.Each(function() {         // 688
      return Spacebars.call(view.lookup("seq"));                                                                      // 689
    }, function() {                                                                                                   // 690
      return Blaze.View(function() {                                                                                  // 691
        return Spacebars.mustache(view.lookup("."));                                                                  // 692
      });                                                                                                             // 693
    }), "\n\n    <b>", Blaze.Each(function() {                                                                        // 694
      return Spacebars.call(view.lookup("seq"));                                                                      // 695
    }, function() {                                                                                                   // 696
      return Blaze.View(function() {                                                                                  // 697
        return Spacebars.mustache(view.lookup("."));                                                                  // 698
      });                                                                                                             // 699
    }), "</b>\n\n`", Blaze.Each(function() {                                                                          // 700
      return Spacebars.call(view.lookup("seq"));                                                                      // 701
    }, function() {                                                                                                   // 702
      return Blaze.View(function() {                                                                                  // 703
        return Spacebars.mustache(view.lookup("."));                                                                  // 704
      });                                                                                                             // 705
    }), "`\n\n`<b>", Blaze.Each(function() {                                                                          // 706
      return Spacebars.call(view.lookup("seq"));                                                                      // 707
    }, function() {                                                                                                   // 708
      return Blaze.View(function() {                                                                                  // 709
        return Spacebars.mustache(view.lookup("."));                                                                  // 710
      });                                                                                                             // 711
    }), "</b>`\n\n  " ];                                                                                              // 712
  });                                                                                                                 // 713
}));                                                                                                                  // 714
                                                                                                                      // 715
Template.__define__("spacebars_template_test_markdown_inclusion", (function() {                                       // 716
  var view = this;                                                                                                    // 717
  return Spacebars.include(view.lookupTemplate("markdown"), function() {                                              // 718
    return [ "\n", Spacebars.include(view.lookupTemplate("spacebars_template_test_markdown_inclusion_subtmpl")), "\n  " ];
  });                                                                                                                 // 720
}));                                                                                                                  // 721
                                                                                                                      // 722
Template.__define__("spacebars_template_test_markdown_inclusion_subtmpl", (function() {                               // 723
  var view = this;                                                                                                    // 724
  return HTML.SPAN(Blaze.If(function() {                                                                              // 725
    return Spacebars.call(view.lookup("foo"));                                                                        // 726
  }, function() {                                                                                                     // 727
    return [ "Foo is ", Blaze.View(function() {                                                                       // 728
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 729
    }), "." ];                                                                                                        // 730
  }));                                                                                                                // 731
}));                                                                                                                  // 732
                                                                                                                      // 733
Template.__define__("spacebars_template_test_markdown_block_helpers", (function() {                                   // 734
  var view = this;                                                                                                    // 735
  return Spacebars.include(view.lookupTemplate("markdown"), function() {                                              // 736
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_template_test_just_content"), function() {    // 737
      return "\nHi there!\n    ";                                                                                     // 738
    }), "\n  " ];                                                                                                     // 739
  });                                                                                                                 // 740
}));                                                                                                                  // 741
                                                                                                                      // 742
Template.__define__("spacebars_template_test_just_content", (function() {                                             // 743
  var view = this;                                                                                                    // 744
  return Blaze.InOuterTemplateScope(view, function() {                                                                // 745
    return Spacebars.include(function() {                                                                             // 746
      return Spacebars.call(view.templateContentBlock);                                                               // 747
    });                                                                                                               // 748
  });                                                                                                                 // 749
}));                                                                                                                  // 750
                                                                                                                      // 751
Template.__define__("spacebars_template_test_simple_helpers_are_isolated", (function() {                              // 752
  var view = this;                                                                                                    // 753
  return Blaze.View(function() {                                                                                      // 754
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 755
  });                                                                                                                 // 756
}));                                                                                                                  // 757
                                                                                                                      // 758
Template.__define__("spacebars_template_test_attr_helpers_are_isolated", (function() {                                // 759
  var view = this;                                                                                                    // 760
  return HTML.P({                                                                                                     // 761
    attr: function() {                                                                                                // 762
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 763
    }                                                                                                                 // 764
  });                                                                                                                 // 765
}));                                                                                                                  // 766
                                                                                                                      // 767
Template.__define__("spacebars_template_test_attr_object_helpers_are_isolated", (function() {                         // 768
  var view = this;                                                                                                    // 769
  return HTML.P(HTML.Attrs(function() {                                                                               // 770
    return Spacebars.attrMustache(view.lookup("attrs"));                                                              // 771
  }));                                                                                                                // 772
}));                                                                                                                  // 773
                                                                                                                      // 774
Template.__define__("spacebars_template_test_inclusion_helpers_are_isolated", (function() {                           // 775
  var view = this;                                                                                                    // 776
  return Spacebars.include(view.lookupTemplate("foo"));                                                               // 777
}));                                                                                                                  // 778
                                                                                                                      // 779
Template.__define__("spacebars_template_test_inclusion_helpers_are_isolated_subtemplate", (function() {               // 780
  var view = this;                                                                                                    // 781
  return "";                                                                                                          // 782
}));                                                                                                                  // 783
                                                                                                                      // 784
Template.__define__("spacebars_template_test_nully_attributes0", (function() {                                        // 785
  var view = this;                                                                                                    // 786
  return HTML.Raw('<input type="checkbox" checked="" stuff="">');                                                     // 787
}));                                                                                                                  // 788
                                                                                                                      // 789
Template.__define__("spacebars_template_test_nully_attributes1", (function() {                                        // 790
  var view = this;                                                                                                    // 791
  return HTML.INPUT({                                                                                                 // 792
    type: "checkbox",                                                                                                 // 793
    checked: function() {                                                                                             // 794
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 795
    },                                                                                                                // 796
    stuff: function() {                                                                                               // 797
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 798
    }                                                                                                                 // 799
  });                                                                                                                 // 800
}));                                                                                                                  // 801
                                                                                                                      // 802
Template.__define__("spacebars_template_test_nully_attributes2", (function() {                                        // 803
  var view = this;                                                                                                    // 804
  return HTML.INPUT({                                                                                                 // 805
    type: "checkbox",                                                                                                 // 806
    checked: function() {                                                                                             // 807
      return [ Spacebars.mustache(view.lookup("foo")), Spacebars.mustache(view.lookup("bar")) ];                      // 808
    },                                                                                                                // 809
    stuff: function() {                                                                                               // 810
      return [ Spacebars.mustache(view.lookup("foo")), Spacebars.mustache(view.lookup("bar")) ];                      // 811
    }                                                                                                                 // 812
  });                                                                                                                 // 813
}));                                                                                                                  // 814
                                                                                                                      // 815
Template.__define__("spacebars_template_test_nully_attributes3", (function() {                                        // 816
  var view = this;                                                                                                    // 817
  return HTML.INPUT({                                                                                                 // 818
    type: "checkbox",                                                                                                 // 819
    checked: function() {                                                                                             // 820
      return Blaze.If(function() {                                                                                    // 821
        return Spacebars.call(view.lookup("foo"));                                                                    // 822
      }, function() {                                                                                                 // 823
        return null;                                                                                                  // 824
      });                                                                                                             // 825
    },                                                                                                                // 826
    stuff: function() {                                                                                               // 827
      return Blaze.If(function() {                                                                                    // 828
        return Spacebars.call(view.lookup("foo"));                                                                    // 829
      }, function() {                                                                                                 // 830
        return null;                                                                                                  // 831
      });                                                                                                             // 832
    }                                                                                                                 // 833
  });                                                                                                                 // 834
}));                                                                                                                  // 835
                                                                                                                      // 836
Template.__define__("spacebars_template_test_double", (function() {                                                   // 837
  var view = this;                                                                                                    // 838
  return Blaze.View(function() {                                                                                      // 839
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 840
  });                                                                                                                 // 841
}));                                                                                                                  // 842
                                                                                                                      // 843
Template.__define__("spacebars_template_test_inclusion_lookup", (function() {                                         // 844
  var view = this;                                                                                                    // 845
  return [ Spacebars.include(view.lookupTemplate("spacebars_template_test_inclusion_lookup_subtmpl")), "\n  ", Spacebars.include(view.lookupTemplate("dataContextSubtmpl")) ];
}));                                                                                                                  // 847
                                                                                                                      // 848
Template.__define__("spacebars_template_test_inclusion_lookup_subtmpl", (function() {                                 // 849
  var view = this;                                                                                                    // 850
  return "This is the template.";                                                                                     // 851
}));                                                                                                                  // 852
                                                                                                                      // 853
Template.__define__("spacebars_template_test_inclusion_lookup_subtmpl2", (function() {                                // 854
  var view = this;                                                                                                    // 855
  return "This is generated by a helper with the same name.";                                                         // 856
}));                                                                                                                  // 857
                                                                                                                      // 858
Template.__define__("spacebars_template_test_inclusion_lookup_subtmpl3", (function() {                                // 859
  var view = this;                                                                                                    // 860
  return "This is a template passed in the data context.";                                                            // 861
}));                                                                                                                  // 862
                                                                                                                      // 863
Template.__define__("spacebars_template_test_content_context", (function() {                                          // 864
  var view = this;                                                                                                    // 865
  return Spacebars.With(function() {                                                                                  // 866
    return Spacebars.call(view.lookup("foo"));                                                                        // 867
  }, function() {                                                                                                     // 868
    return [ "\n    ", Spacebars.With(function() {                                                                    // 869
      return Spacebars.call(view.lookup("bar"));                                                                      // 870
    }, function() {                                                                                                   // 871
      return [ "\n      ", Spacebars.TemplateWith(function() {                                                        // 872
        return {                                                                                                      // 873
          condition: Spacebars.call(view.lookup("cond"))                                                              // 874
        };                                                                                                            // 875
      }, function() {                                                                                                 // 876
        return Spacebars.include(view.lookupTemplate("spacebars_template_test_iftemplate"), function() {              // 877
          return [ "\n        ", Blaze.View(function() {                                                              // 878
            return Spacebars.mustache(view.lookup("firstLetter"));                                                    // 879
          }), Blaze.View(function() {                                                                                 // 880
            return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "secondLetter"));                              // 881
          }), "\n      " ];                                                                                           // 882
        }, function() {                                                                                               // 883
          return [ "\n        ", Blaze.View(function() {                                                              // 884
            return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "firstLetter"));                               // 885
          }), Blaze.View(function() {                                                                                 // 886
            return Spacebars.mustache(view.lookup("secondLetter"));                                                   // 887
          }), "\n      " ];                                                                                           // 888
        });                                                                                                           // 889
      }), "\n    " ];                                                                                                 // 890
    }), "\n  " ];                                                                                                     // 891
  });                                                                                                                 // 892
}));                                                                                                                  // 893
                                                                                                                      // 894
Template.__define__("spacebars_test_control_input", (function() {                                                     // 895
  var view = this;                                                                                                    // 896
  return HTML.INPUT({                                                                                                 // 897
    type: function() {                                                                                                // 898
      return Spacebars.mustache(view.lookup("type"));                                                                 // 899
    },                                                                                                                // 900
    value: function() {                                                                                               // 901
      return Spacebars.mustache(view.lookup("value"));                                                                // 902
    }                                                                                                                 // 903
  });                                                                                                                 // 904
}));                                                                                                                  // 905
                                                                                                                      // 906
Template.__define__("spacebars_test_control_textarea", (function() {                                                  // 907
  var view = this;                                                                                                    // 908
  return HTML.TEXTAREA({                                                                                              // 909
    value: function() {                                                                                               // 910
      return Spacebars.mustache(view.lookup("value"));                                                                // 911
    }                                                                                                                 // 912
  });                                                                                                                 // 913
}));                                                                                                                  // 914
                                                                                                                      // 915
Template.__define__("spacebars_test_control_select", (function() {                                                    // 916
  var view = this;                                                                                                    // 917
  return HTML.SELECT("\n    ", Blaze.Each(function() {                                                                // 918
    return Spacebars.call(view.lookup("options"));                                                                    // 919
  }, function() {                                                                                                     // 920
    return [ "\n      ", HTML.OPTION({                                                                                // 921
      selected: function() {                                                                                          // 922
        return Spacebars.mustache(view.lookup("selected"));                                                           // 923
      }                                                                                                               // 924
    }, Blaze.View(function() {                                                                                        // 925
      return Spacebars.mustache(view.lookup("."));                                                                    // 926
    })), "\n    " ];                                                                                                  // 927
  }), "\n  ");                                                                                                        // 928
}));                                                                                                                  // 929
                                                                                                                      // 930
Template.__define__("spacebars_test_control_radio", (function() {                                                     // 931
  var view = this;                                                                                                    // 932
  return [ "Band:\n\n  ", Blaze.Each(function() {                                                                     // 933
    return Spacebars.call(view.lookup("bands"));                                                                      // 934
  }, function() {                                                                                                     // 935
    return [ "\n    ", HTML.INPUT({                                                                                   // 936
      name: "bands",                                                                                                  // 937
      type: "radio",                                                                                                  // 938
      value: function() {                                                                                             // 939
        return Spacebars.mustache(view.lookup("."));                                                                  // 940
      },                                                                                                              // 941
      checked: function() {                                                                                           // 942
        return Spacebars.mustache(view.lookup("isChecked"));                                                          // 943
      }                                                                                                               // 944
    }), "\n  " ];                                                                                                     // 945
  }), "\n\n  ", Blaze.View(function() {                                                                               // 946
    return Spacebars.mustache(view.lookup("band"));                                                                   // 947
  }) ];                                                                                                               // 948
}));                                                                                                                  // 949
                                                                                                                      // 950
Template.__define__("spacebars_test_control_checkbox", (function() {                                                  // 951
  var view = this;                                                                                                    // 952
  return Blaze.Each(function() {                                                                                      // 953
    return Spacebars.call(view.lookup("labels"));                                                                     // 954
  }, function() {                                                                                                     // 955
    return [ "\n    ", HTML.INPUT({                                                                                   // 956
      type: "checkbox",                                                                                               // 957
      value: function() {                                                                                             // 958
        return Spacebars.mustache(view.lookup("."));                                                                  // 959
      },                                                                                                              // 960
      checked: function() {                                                                                           // 961
        return Spacebars.mustache(view.lookup("isChecked"));                                                          // 962
      }                                                                                                               // 963
    }), "\n  " ];                                                                                                     // 964
  });                                                                                                                 // 965
}));                                                                                                                  // 966
                                                                                                                      // 967
Template.__define__("spacebars_test_nonexistent_template", (function() {                                              // 968
  var view = this;                                                                                                    // 969
  return Spacebars.include(view.lookupTemplate("this_template_lives_in_outer_space"));                                // 970
}));                                                                                                                  // 971
                                                                                                                      // 972
Template.__define__("spacebars_test_if_helper", (function() {                                                         // 973
  var view = this;                                                                                                    // 974
  return Blaze.If(function() {                                                                                        // 975
    return Spacebars.call(view.lookup("foo"));                                                                        // 976
  }, function() {                                                                                                     // 977
    return "\n    true\n  ";                                                                                          // 978
  }, function() {                                                                                                     // 979
    return "\n    false\n  ";                                                                                         // 980
  });                                                                                                                 // 981
}));                                                                                                                  // 982
                                                                                                                      // 983
Template.__define__("spacebars_test_block_helper_function", (function() {                                             // 984
  var view = this;                                                                                                    // 985
  return Spacebars.include(view.lookupTemplate("foo"), function() {                                                   // 986
    return "\n  ";                                                                                                    // 987
  });                                                                                                                 // 988
}));                                                                                                                  // 989
                                                                                                                      // 990
Template.__define__("spacebars_test_helpers_stop_onetwo", (function() {                                               // 991
  var view = this;                                                                                                    // 992
  return Blaze.If(function() {                                                                                        // 993
    return Spacebars.call(view.lookup("showOne"));                                                                    // 994
  }, function() {                                                                                                     // 995
    return [ "\n    ", Spacebars.include(view.lookupTemplate("one")), "\n  " ];                                       // 996
  }, function() {                                                                                                     // 997
    return [ "\n    ", Spacebars.include(view.lookupTemplate("two")), "\n  " ];                                       // 998
  });                                                                                                                 // 999
}));                                                                                                                  // 1000
                                                                                                                      // 1001
Template.__define__("spacebars_test_helpers_stop_onetwo_attribute", (function() {                                     // 1002
  var view = this;                                                                                                    // 1003
  return HTML.BR({                                                                                                    // 1004
    "data-stuff": function() {                                                                                        // 1005
      return Blaze.If(function() {                                                                                    // 1006
        return Spacebars.call(view.lookup("showOne"));                                                                // 1007
      }, function() {                                                                                                 // 1008
        return [ "\n    ", Spacebars.include(view.lookupTemplate("one")), "\n  " ];                                   // 1009
      }, function() {                                                                                                 // 1010
        return [ "\n    ", Spacebars.include(view.lookupTemplate("two")), "\n  " ];                                   // 1011
      });                                                                                                             // 1012
    }                                                                                                                 // 1013
  });                                                                                                                 // 1014
}));                                                                                                                  // 1015
                                                                                                                      // 1016
Template.__define__("spacebars_test_helpers_stop_with1", (function() {                                                // 1017
  var view = this;                                                                                                    // 1018
  return Spacebars.With(function() {                                                                                  // 1019
    return Spacebars.call(view.lookup("options"));                                                                    // 1020
  }, function() {                                                                                                     // 1021
    return "\n    one\n  ";                                                                                           // 1022
  });                                                                                                                 // 1023
}));                                                                                                                  // 1024
                                                                                                                      // 1025
Template.__define__("spacebars_test_helpers_stop_with2", (function() {                                                // 1026
  var view = this;                                                                                                    // 1027
  return Spacebars.With(function() {                                                                                  // 1028
    return Spacebars.call(view.lookup("options"));                                                                    // 1029
  }, function() {                                                                                                     // 1030
    return "\n    two\n  ";                                                                                           // 1031
  });                                                                                                                 // 1032
}));                                                                                                                  // 1033
                                                                                                                      // 1034
Template.__define__("spacebars_test_helpers_stop_each1", (function() {                                                // 1035
  var view = this;                                                                                                    // 1036
  return Blaze.Each(function() {                                                                                      // 1037
    return Spacebars.call(view.lookup("options"));                                                                    // 1038
  }, function() {                                                                                                     // 1039
    return "\n    one\n  ";                                                                                           // 1040
  });                                                                                                                 // 1041
}));                                                                                                                  // 1042
                                                                                                                      // 1043
Template.__define__("spacebars_test_helpers_stop_each2", (function() {                                                // 1044
  var view = this;                                                                                                    // 1045
  return Blaze.Each(function() {                                                                                      // 1046
    return Spacebars.call(view.lookup("options"));                                                                    // 1047
  }, function() {                                                                                                     // 1048
    return "\n    two\n  ";                                                                                           // 1049
  });                                                                                                                 // 1050
}));                                                                                                                  // 1051
                                                                                                                      // 1052
Template.__define__("spacebars_test_helpers_stop_with_each1", (function() {                                           // 1053
  var view = this;                                                                                                    // 1054
  return Spacebars.With(function() {                                                                                  // 1055
    return Spacebars.call(view.lookup("options"));                                                                    // 1056
  }, function() {                                                                                                     // 1057
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_helpers_stop_with_each3")), "\n  " ];    // 1058
  });                                                                                                                 // 1059
}));                                                                                                                  // 1060
                                                                                                                      // 1061
Template.__define__("spacebars_test_helpers_stop_with_each2", (function() {                                           // 1062
  var view = this;                                                                                                    // 1063
  return Spacebars.With(function() {                                                                                  // 1064
    return Spacebars.call(view.lookup("options"));                                                                    // 1065
  }, function() {                                                                                                     // 1066
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_helpers_stop_with_each3")), "\n  " ];    // 1067
  });                                                                                                                 // 1068
}));                                                                                                                  // 1069
                                                                                                                      // 1070
Template.__define__("spacebars_test_helpers_stop_with_each3", (function() {                                           // 1071
  var view = this;                                                                                                    // 1072
  return Blaze.Each(function() {                                                                                      // 1073
    return Spacebars.call(view.lookup("."));                                                                          // 1074
  }, function() {                                                                                                     // 1075
    return "\n  ";                                                                                                    // 1076
  });                                                                                                                 // 1077
}));                                                                                                                  // 1078
                                                                                                                      // 1079
Template.__define__("spacebars_test_helpers_stop_if1", (function() {                                                  // 1080
  var view = this;                                                                                                    // 1081
  return Blaze.If(function() {                                                                                        // 1082
    return Spacebars.call(view.lookup("options"));                                                                    // 1083
  }, function() {                                                                                                     // 1084
    return "\n    one\n  ";                                                                                           // 1085
  });                                                                                                                 // 1086
}));                                                                                                                  // 1087
                                                                                                                      // 1088
Template.__define__("spacebars_test_helpers_stop_if2", (function() {                                                  // 1089
  var view = this;                                                                                                    // 1090
  return Blaze.If(function() {                                                                                        // 1091
    return Spacebars.call(view.lookup("options"));                                                                    // 1092
  }, function() {                                                                                                     // 1093
    return "\n    two\n  ";                                                                                           // 1094
  });                                                                                                                 // 1095
}));                                                                                                                  // 1096
                                                                                                                      // 1097
Template.__define__("spacebars_test_helpers_stop_inclusion1", (function() {                                           // 1098
  var view = this;                                                                                                    // 1099
  return Spacebars.include(view.lookupTemplate("options"));                                                           // 1100
}));                                                                                                                  // 1101
                                                                                                                      // 1102
Template.__define__("spacebars_test_helpers_stop_inclusion2", (function() {                                           // 1103
  var view = this;                                                                                                    // 1104
  return Spacebars.include(view.lookupTemplate("options"));                                                           // 1105
}));                                                                                                                  // 1106
                                                                                                                      // 1107
Template.__define__("spacebars_test_helpers_stop_inclusion3", (function() {                                           // 1108
  var view = this;                                                                                                    // 1109
  return "blah";                                                                                                      // 1110
}));                                                                                                                  // 1111
                                                                                                                      // 1112
Template.__define__("spacebars_test_helpers_stop_with_callbacks1", (function() {                                      // 1113
  var view = this;                                                                                                    // 1114
  return Spacebars.With(function() {                                                                                  // 1115
    return Spacebars.call(view.lookup("options"));                                                                    // 1116
  }, function() {                                                                                                     // 1117
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_helpers_stop_with_callbacks3")), "\n  " ];
  });                                                                                                                 // 1119
}));                                                                                                                  // 1120
                                                                                                                      // 1121
Template.__define__("spacebars_test_helpers_stop_with_callbacks2", (function() {                                      // 1122
  var view = this;                                                                                                    // 1123
  return Spacebars.With(function() {                                                                                  // 1124
    return Spacebars.call(view.lookup("options"));                                                                    // 1125
  }, function() {                                                                                                     // 1126
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_helpers_stop_with_callbacks3")), "\n  " ];
  });                                                                                                                 // 1128
}));                                                                                                                  // 1129
                                                                                                                      // 1130
Template.__define__("spacebars_test_helpers_stop_with_callbacks3", (function() {                                      // 1131
  var view = this;                                                                                                    // 1132
  return "blah";                                                                                                      // 1133
}));                                                                                                                  // 1134
                                                                                                                      // 1135
Template.__define__("spacebars_test_helpers_stop_unless1", (function() {                                              // 1136
  var view = this;                                                                                                    // 1137
  return Blaze.Unless(function() {                                                                                    // 1138
    return Spacebars.call(view.lookup("options"));                                                                    // 1139
  }, function() {                                                                                                     // 1140
    return "\n    one\n  ";                                                                                           // 1141
  });                                                                                                                 // 1142
}));                                                                                                                  // 1143
                                                                                                                      // 1144
Template.__define__("spacebars_test_helpers_stop_unless2", (function() {                                              // 1145
  var view = this;                                                                                                    // 1146
  return Blaze.Unless(function() {                                                                                    // 1147
    return Spacebars.call(view.lookup("options"));                                                                    // 1148
  }, function() {                                                                                                     // 1149
    return "\n    two\n  ";                                                                                           // 1150
  });                                                                                                                 // 1151
}));                                                                                                                  // 1152
                                                                                                                      // 1153
Template.__define__("spacebars_test_no_data_context", (function() {                                                   // 1154
  var view = this;                                                                                                    // 1155
  return [ HTML.Raw("<button></button>\n  "), Blaze.View(function() {                                                 // 1156
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 1157
  }) ];                                                                                                               // 1158
}));                                                                                                                  // 1159
                                                                                                                      // 1160
Template.__define__("spacebars_test_falsy_with", (function() {                                                        // 1161
  var view = this;                                                                                                    // 1162
  return Spacebars.With(function() {                                                                                  // 1163
    return Spacebars.call(view.lookup("obj"));                                                                        // 1164
  }, function() {                                                                                                     // 1165
    return [ "\n    ", Blaze.View(function() {                                                                        // 1166
      return Spacebars.mustache(view.lookup("greekLetter"));                                                          // 1167
    }), "\n  " ];                                                                                                     // 1168
  });                                                                                                                 // 1169
}));                                                                                                                  // 1170
                                                                                                                      // 1171
Template.__define__("spacebars_test_helpers_dont_leak", (function() {                                                 // 1172
  var view = this;                                                                                                    // 1173
  return Spacebars.TemplateWith(function() {                                                                          // 1174
    return {                                                                                                          // 1175
      foo: Spacebars.call("correct")                                                                                  // 1176
    };                                                                                                                // 1177
  }, function() {                                                                                                     // 1178
    return Spacebars.include(view.lookupTemplate("spacebars_test_helpers_dont_leak2"));                               // 1179
  });                                                                                                                 // 1180
}));                                                                                                                  // 1181
                                                                                                                      // 1182
Template.__define__("spacebars_test_helpers_dont_leak2", (function() {                                                // 1183
  var view = this;                                                                                                    // 1184
  return [ Blaze.View(function() {                                                                                    // 1185
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 1186
  }), Blaze.View(function() {                                                                                         // 1187
    return Spacebars.mustache(view.lookup("bar"));                                                                    // 1188
  }), " ", Spacebars.include(view.lookupTemplate("spacebars_template_test_content"), function() {                     // 1189
    return Blaze.View(function() {                                                                                    // 1190
      return Spacebars.mustache(view.lookup("bonus"));                                                                // 1191
    });                                                                                                               // 1192
  }) ];                                                                                                               // 1193
}));                                                                                                                  // 1194
                                                                                                                      // 1195
Template.__define__("spacebars_test_event_returns_false", (function() {                                               // 1196
  var view = this;                                                                                                    // 1197
  return HTML.Raw('<a href="#bad-url" id="spacebars_test_event_returns_false_link">click me</a>');                    // 1198
}));                                                                                                                  // 1199
                                                                                                                      // 1200
Template.__define__("spacebars_test_event_selectors1", (function() {                                                  // 1201
  var view = this;                                                                                                    // 1202
  return HTML.DIV(Spacebars.include(view.lookupTemplate("spacebars_test_event_selectors2")));                         // 1203
}));                                                                                                                  // 1204
                                                                                                                      // 1205
Template.__define__("spacebars_test_event_selectors2", (function() {                                                  // 1206
  var view = this;                                                                                                    // 1207
  return HTML.Raw('<p class="p1">Not it</p>\n  <div><p class="p2">It</p></div>');                                     // 1208
}));                                                                                                                  // 1209
                                                                                                                      // 1210
Template.__define__("spacebars_test_event_selectors_capturing1", (function() {                                        // 1211
  var view = this;                                                                                                    // 1212
  return HTML.DIV(Spacebars.include(view.lookupTemplate("spacebars_test_event_selectors_capturing2")));               // 1213
}));                                                                                                                  // 1214
                                                                                                                      // 1215
Template.__define__("spacebars_test_event_selectors_capturing2", (function() {                                        // 1216
  var view = this;                                                                                                    // 1217
  return HTML.Raw('<video class="video1">\n    <source id="mp4" src="http://media.w3.org/2010/05/sintel/trailer.mp4" type="video/mp4">\n  </video>\n  <div>\n    <video class="video2">\n      <source id="mp4" src="http://media.w3.org/2010/05/sintel/trailer.mp4" type="video/mp4">\n    </video>\n  </div>');
}));                                                                                                                  // 1219
                                                                                                                      // 1220
Template.__define__("spacebars_test_tables1", (function() {                                                           // 1221
  var view = this;                                                                                                    // 1222
  return HTML.TABLE(HTML.TR(HTML.TD("Foo")));                                                                         // 1223
}));                                                                                                                  // 1224
                                                                                                                      // 1225
Template.__define__("spacebars_test_tables2", (function() {                                                           // 1226
  var view = this;                                                                                                    // 1227
  return HTML.TABLE(HTML.TR(HTML.TD(Blaze.View(function() {                                                           // 1228
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 1229
  }))));                                                                                                              // 1230
}));                                                                                                                  // 1231
                                                                                                                      // 1232
Template.__define__("spacebars_test_jquery_events", (function() {                                                     // 1233
  var view = this;                                                                                                    // 1234
  return HTML.Raw('<button type="button">button</button>');                                                           // 1235
}));                                                                                                                  // 1236
                                                                                                                      // 1237
Template.__define__("spacebars_test_tohtml_basic", (function() {                                                      // 1238
  var view = this;                                                                                                    // 1239
  return Blaze.View(function() {                                                                                      // 1240
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 1241
  });                                                                                                                 // 1242
}));                                                                                                                  // 1243
                                                                                                                      // 1244
Template.__define__("spacebars_test_tohtml_if", (function() {                                                         // 1245
  var view = this;                                                                                                    // 1246
  return Blaze.If(function() {                                                                                        // 1247
    return true;                                                                                                      // 1248
  }, function() {                                                                                                     // 1249
    return [ "\n    ", Blaze.View(function() {                                                                        // 1250
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1251
    }), "\n  " ];                                                                                                     // 1252
  });                                                                                                                 // 1253
}));                                                                                                                  // 1254
                                                                                                                      // 1255
Template.__define__("spacebars_test_tohtml_with", (function() {                                                       // 1256
  var view = this;                                                                                                    // 1257
  return Spacebars.With(function() {                                                                                  // 1258
    return Spacebars.call(view.lookup("foo"));                                                                        // 1259
  }, function() {                                                                                                     // 1260
    return [ "\n    ", Blaze.View(function() {                                                                        // 1261
      return Spacebars.mustache(view.lookup("."));                                                                    // 1262
    }), "\n  " ];                                                                                                     // 1263
  });                                                                                                                 // 1264
}));                                                                                                                  // 1265
                                                                                                                      // 1266
Template.__define__("spacebars_test_tohtml_each", (function() {                                                       // 1267
  var view = this;                                                                                                    // 1268
  return Blaze.Each(function() {                                                                                      // 1269
    return Spacebars.call(view.lookup("foos"));                                                                       // 1270
  }, function() {                                                                                                     // 1271
    return [ "\n    ", Blaze.View(function() {                                                                        // 1272
      return Spacebars.mustache(view.lookup("."));                                                                    // 1273
    }), "\n  " ];                                                                                                     // 1274
  });                                                                                                                 // 1275
}));                                                                                                                  // 1276
                                                                                                                      // 1277
Template.__define__("spacebars_test_tohtml_include_with", (function() {                                               // 1278
  var view = this;                                                                                                    // 1279
  return Spacebars.include(view.lookupTemplate("spacebars_test_tohtml_with"));                                        // 1280
}));                                                                                                                  // 1281
                                                                                                                      // 1282
Template.__define__("spacebars_test_tohtml_include_each", (function() {                                               // 1283
  var view = this;                                                                                                    // 1284
  return Spacebars.include(view.lookupTemplate("spacebars_test_tohtml_each"));                                        // 1285
}));                                                                                                                  // 1286
                                                                                                                      // 1287
Template.__define__("spacebars_test_block_comment", (function() {                                                     // 1288
  var view = this;                                                                                                    // 1289
  return "\n  ";                                                                                                      // 1290
}));                                                                                                                  // 1291
                                                                                                                      // 1292
Template.__define__("spacebars_test_with_mutated_data_context", (function() {                                         // 1293
  var view = this;                                                                                                    // 1294
  return Spacebars.With(function() {                                                                                  // 1295
    return Spacebars.call(view.lookup("foo"));                                                                        // 1296
  }, function() {                                                                                                     // 1297
    return [ "\n    ", Blaze.View(function() {                                                                        // 1298
      return Spacebars.mustache(view.lookup("value"));                                                                // 1299
    }), "\n  " ];                                                                                                     // 1300
  });                                                                                                                 // 1301
}));                                                                                                                  // 1302
                                                                                                                      // 1303
Template.__define__("spacebars_test_url_attribute", (function() {                                                     // 1304
  var view = this;                                                                                                    // 1305
  return [ HTML.A({                                                                                                   // 1306
    href: function() {                                                                                                // 1307
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1308
    }                                                                                                                 // 1309
  }), "\n  ", HTML.A({                                                                                                // 1310
    href: function() {                                                                                                // 1311
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1312
    }                                                                                                                 // 1313
  }), "\n  ", HTML.FORM({                                                                                             // 1314
    action: function() {                                                                                              // 1315
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1316
    }                                                                                                                 // 1317
  }), "\n  ", HTML.IMG({                                                                                              // 1318
    src: function() {                                                                                                 // 1319
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1320
    }                                                                                                                 // 1321
  }), "\n  ", HTML.INPUT({                                                                                            // 1322
    value: function() {                                                                                               // 1323
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1324
    }                                                                                                                 // 1325
  }) ];                                                                                                               // 1326
}));                                                                                                                  // 1327
                                                                                                                      // 1328
Template.__define__("spacebars_test_event_handler_cleanup", (function() {                                             // 1329
  var view = this;                                                                                                    // 1330
  return Blaze.If(function() {                                                                                        // 1331
    return Spacebars.call(view.lookup("foo"));                                                                        // 1332
  }, function() {                                                                                                     // 1333
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_event_handler_cleanup_sub")), "\n  " ];  // 1334
  });                                                                                                                 // 1335
}));                                                                                                                  // 1336
                                                                                                                      // 1337
Template.__define__("spacebars_test_event_handler_cleanup_sub", (function() {                                         // 1338
  var view = this;                                                                                                    // 1339
  return HTML.Raw("<div></div>");                                                                                     // 1340
}));                                                                                                                  // 1341
                                                                                                                      // 1342
Template.__define__("spacebars_test_data_context_for_event_handler_in_if", (function() {                              // 1343
  var view = this;                                                                                                    // 1344
  return Spacebars.With(function() {                                                                                  // 1345
    return {                                                                                                          // 1346
      foo: Spacebars.call("bar")                                                                                      // 1347
    };                                                                                                                // 1348
  }, function() {                                                                                                     // 1349
    return [ "\n    ", Blaze.If(function() {                                                                          // 1350
      return true;                                                                                                    // 1351
    }, function() {                                                                                                   // 1352
      return [ "\n      ", HTML.SPAN("Click me!"), "\n    " ];                                                        // 1353
    }), "\n  " ];                                                                                                     // 1354
  });                                                                                                                 // 1355
}));                                                                                                                  // 1356
                                                                                                                      // 1357
Template.__define__("spacebars_test_each_with_autorun_insert", (function() {                                          // 1358
  var view = this;                                                                                                    // 1359
  return Blaze.Each(function() {                                                                                      // 1360
    return Spacebars.call(view.lookup("items"));                                                                      // 1361
  }, function() {                                                                                                     // 1362
    return [ "\n    ", Blaze.View(function() {                                                                        // 1363
      return Spacebars.mustache(view.lookup("name"));                                                                 // 1364
    }), "\n  " ];                                                                                                     // 1365
  });                                                                                                                 // 1366
}));                                                                                                                  // 1367
                                                                                                                      // 1368
Template.__define__("spacebars_test_ui_hooks", (function() {                                                          // 1369
  var view = this;                                                                                                    // 1370
  return HTML.DIV({                                                                                                   // 1371
    "class": "test-ui-hooks"                                                                                          // 1372
  }, "\n    ", Blaze.Each(function() {                                                                                // 1373
    return Spacebars.call(view.lookup("items"));                                                                      // 1374
  }, function() {                                                                                                     // 1375
    return [ "\n      ", HTML.DIV({                                                                                   // 1376
      "class": "item"                                                                                                 // 1377
    }, Blaze.View(function() {                                                                                        // 1378
      return Spacebars.mustache(view.lookup("_id"));                                                                  // 1379
    })), "\n    " ];                                                                                                  // 1380
  }), "\n  ");                                                                                                        // 1381
}));                                                                                                                  // 1382
                                                                                                                      // 1383
Template.__define__("spacebars_test_ui_hooks_nested", (function() {                                                   // 1384
  var view = this;                                                                                                    // 1385
  return Blaze.If(function() {                                                                                        // 1386
    return Spacebars.call(view.lookup("foo"));                                                                        // 1387
  }, function() {                                                                                                     // 1388
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_ui_hooks_nested_sub")), "\n  " ];        // 1389
  });                                                                                                                 // 1390
}));                                                                                                                  // 1391
                                                                                                                      // 1392
Template.__define__("spacebars_test_ui_hooks_nested_sub", (function() {                                               // 1393
  var view = this;                                                                                                    // 1394
  return HTML.DIV("\n    ", Spacebars.With(function() {                                                               // 1395
    return true;                                                                                                      // 1396
  }, function() {                                                                                                     // 1397
    return [ "\n      ", HTML.P("hello"), "\n    " ];                                                                 // 1398
  }), "\n  ");                                                                                                        // 1399
}));                                                                                                                  // 1400
                                                                                                                      // 1401
Template.__define__("spacebars_test_template_instance_helper", (function() {                                          // 1402
  var view = this;                                                                                                    // 1403
  return Spacebars.With(function() {                                                                                  // 1404
    return true;                                                                                                      // 1405
  }, function() {                                                                                                     // 1406
    return Blaze.View(function() {                                                                                    // 1407
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 1408
    });                                                                                                               // 1409
  });                                                                                                                 // 1410
}));                                                                                                                  // 1411
                                                                                                                      // 1412
Template.__define__("spacebars_test_with_cleanup", (function() {                                                      // 1413
  var view = this;                                                                                                    // 1414
  return HTML.DIV({                                                                                                   // 1415
    "class": "test-with-cleanup"                                                                                      // 1416
  }, "\n    ", Spacebars.With(function() {                                                                            // 1417
    return Spacebars.call(view.lookup("foo"));                                                                        // 1418
  }, function() {                                                                                                     // 1419
    return [ "\n      ", Blaze.View(function() {                                                                      // 1420
      return Spacebars.mustache(view.lookup("."));                                                                    // 1421
    }), "\n    " ];                                                                                                   // 1422
  }), "\n  ");                                                                                                        // 1423
}));                                                                                                                  // 1424
                                                                                                                      // 1425
Template.__define__("spacebars_test_template_parent_data_helper", (function() {                                       // 1426
  var view = this;                                                                                                    // 1427
  return Spacebars.With(function() {                                                                                  // 1428
    return "parent";                                                                                                  // 1429
  }, function() {                                                                                                     // 1430
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_template_parent_data_helper_child")), "\n  " ];
  });                                                                                                                 // 1432
}));                                                                                                                  // 1433
                                                                                                                      // 1434
Template.__define__("spacebars_test_template_parent_data_helper_child", (function() {                                 // 1435
  var view = this;                                                                                                    // 1436
  return Blaze.Each(function() {                                                                                      // 1437
    return Spacebars.call(view.lookup("a"));                                                                          // 1438
  }, function() {                                                                                                     // 1439
    return [ "\n    ", Spacebars.With(function() {                                                                    // 1440
      return Spacebars.call(view.lookup("b"));                                                                        // 1441
    }, function() {                                                                                                   // 1442
      return [ "\n      ", Blaze.If(function() {                                                                      // 1443
        return Spacebars.call(view.lookup("c"));                                                                      // 1444
      }, function() {                                                                                                 // 1445
        return [ "\n        ", Spacebars.With(function() {                                                            // 1446
          return "d";                                                                                                 // 1447
        }, function() {                                                                                               // 1448
          return [ "\n          ", Blaze.View(function() {                                                            // 1449
            return Spacebars.mustache(view.lookup("foo"));                                                            // 1450
          }), "\n        " ];                                                                                         // 1451
        }), "\n      " ];                                                                                             // 1452
      }), "\n    " ];                                                                                                 // 1453
    }), "\n  " ];                                                                                                     // 1454
  });                                                                                                                 // 1455
}));                                                                                                                  // 1456
                                                                                                                      // 1457
Template.__define__("spacebars_test_svg_anchor", (function() {                                                        // 1458
  var view = this;                                                                                                    // 1459
  return HTML.SVG("\n    ", HTML.A({                                                                                  // 1460
    "xlink:href": "http://www.example.com"                                                                            // 1461
  }, "Foo"), "\n  ");                                                                                                 // 1462
}));                                                                                                                  // 1463
                                                                                                                      // 1464
Template.__define__("spacebars_test_template_created_rendered_destroyed_each", (function() {                          // 1465
  var view = this;                                                                                                    // 1466
  return Blaze.Each(function() {                                                                                      // 1467
    return Spacebars.call(view.lookup("items"));                                                                      // 1468
  }, function() {                                                                                                     // 1469
    return [ "\n    ", HTML.DIV(Spacebars.TemplateWith(function() {                                                   // 1470
      return Spacebars.call(view.lookup("_id"));                                                                      // 1471
    }, function() {                                                                                                   // 1472
      return Spacebars.include(view.lookupTemplate("spacebars_test_template_created_rendered_destroyed_each_sub"));   // 1473
    })), "\n  " ];                                                                                                    // 1474
  });                                                                                                                 // 1475
}));                                                                                                                  // 1476
                                                                                                                      // 1477
Template.__define__("spacebars_test_template_created_rendered_destroyed_each_sub", (function() {                      // 1478
  var view = this;                                                                                                    // 1479
  return Blaze.View(function() {                                                                                      // 1480
    return Spacebars.mustache(view.lookup("."));                                                                      // 1481
  });                                                                                                                 // 1482
}));                                                                                                                  // 1483
                                                                                                                      // 1484
Template.__define__("spacebars_test_ui_getElementData", (function() {                                                 // 1485
  var view = this;                                                                                                    // 1486
  return HTML.Raw("<span></span>");                                                                                   // 1487
}));                                                                                                                  // 1488
                                                                                                                      // 1489
Template.__define__("spacebars_test_ui_render", (function() {                                                         // 1490
  var view = this;                                                                                                    // 1491
  return HTML.SPAN(Blaze.View(function() {                                                                            // 1492
    return Spacebars.mustache(view.lookup("greeting"));                                                               // 1493
  }), " ", Blaze.View(function() {                                                                                    // 1494
    return Spacebars.mustache(view.lookup("r"));                                                                      // 1495
  }));                                                                                                                // 1496
}));                                                                                                                  // 1497
                                                                                                                      // 1498
Template.__define__("spacebars_test_parent_removal", (function() {                                                    // 1499
  var view = this;                                                                                                    // 1500
  return HTML.DIV({                                                                                                   // 1501
    "class": "a"                                                                                                      // 1502
  }, "\n    ", HTML.DIV({                                                                                             // 1503
    "class": "b"                                                                                                      // 1504
  }, "\n      ", HTML.DIV({                                                                                           // 1505
    "class": "toremove"                                                                                               // 1506
  }, "\n        ", HTML.DIV({                                                                                         // 1507
    "class": "c"                                                                                                      // 1508
  }, "\n          ", Blaze.View(function() {                                                                          // 1509
    return Spacebars.mustache(view.lookup("A"), 1);                                                                   // 1510
  }), "\n          ", Blaze.View(function() {                                                                         // 1511
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("A"), 2));                                                // 1512
  }), "\n          ", Spacebars.With(function() {                                                                     // 1513
    return Spacebars.dataMustache(view.lookup("A"), 3);                                                               // 1514
  }, function() {                                                                                                     // 1515
    return [ "\n            ", Blaze.View(function() {                                                                // 1516
      return Spacebars.mustache(view.lookup("A"), 4);                                                                 // 1517
    }), "\n            ", Spacebars.With(function() {                                                                 // 1518
      return Spacebars.dataMustache(view.lookup("A"), 5);                                                             // 1519
    }, function() {                                                                                                   // 1520
      return [ "\n              ", Blaze.View(function() {                                                            // 1521
        return Spacebars.mustache(view.lookup("A"), 6);                                                               // 1522
      }), "\n            " ];                                                                                         // 1523
    }), "\n          " ];                                                                                             // 1524
  }), "\n          ", Blaze.Each(function() {                                                                         // 1525
    return Spacebars.call(view.lookup("B"));                                                                          // 1526
  }, function() {                                                                                                     // 1527
    return [ "\n            ", Blaze.View(function() {                                                                // 1528
      return Spacebars.mustache(view.lookup("A"), 7);                                                                 // 1529
    }), "\n          " ];                                                                                             // 1530
  }), "\n          ", Blaze.If(function() {                                                                           // 1531
    return Spacebars.dataMustache(view.lookup("A"), 8);                                                               // 1532
  }, function() {                                                                                                     // 1533
    return [ "\n            ", Blaze.View(function() {                                                                // 1534
      return Spacebars.mustache(view.lookup("A"), 9);                                                                 // 1535
    }), "\n          " ];                                                                                             // 1536
  }, function() {                                                                                                     // 1537
    return [ "\n            ", Blaze.View(function() {                                                                // 1538
      return Spacebars.mustache(view.lookup("A"), "a");                                                               // 1539
    }), "\n          " ];                                                                                             // 1540
  }), "\n        "), "\n      "), "\n    "), "\n  ");                                                                 // 1541
}));                                                                                                                  // 1542
                                                                                                                      // 1543
Template.__define__("spacebars_test_focus_blur_outer", (function() {                                                  // 1544
  var view = this;                                                                                                    // 1545
  return Blaze.If(function() {                                                                                        // 1546
    return Spacebars.call(view.lookup("cond"));                                                                       // 1547
  }, function() {                                                                                                     // 1548
    return [ "\n    a ", Spacebars.include(view.lookupTemplate("spacebars_test_focus_blur_inner")), "\n  " ];         // 1549
  }, function() {                                                                                                     // 1550
    return [ "\n    b ", Spacebars.include(view.lookupTemplate("spacebars_test_focus_blur_inner")), "\n  " ];         // 1551
  });                                                                                                                 // 1552
}));                                                                                                                  // 1553
                                                                                                                      // 1554
Template.__define__("spacebars_test_focus_blur_inner", (function() {                                                  // 1555
  var view = this;                                                                                                    // 1556
  return HTML.Raw('<input type="text">');                                                                             // 1557
}));                                                                                                                  // 1558
                                                                                                                      // 1559
Template.__define__("spacebars_test_event_cleanup_on_destroyed_outer", (function() {                                  // 1560
  var view = this;                                                                                                    // 1561
  return Blaze.If(function() {                                                                                        // 1562
    return Spacebars.call(view.lookup("cond"));                                                                       // 1563
  }, function() {                                                                                                     // 1564
    return [ "\n    ", HTML.DIV("a ", Spacebars.include(view.lookupTemplate("spacebars_test_event_cleanup_on_destroyed_inner"))), "\n  " ];
  }, function() {                                                                                                     // 1566
    return [ "\n    ", HTML.DIV("b ", Spacebars.include(view.lookupTemplate("spacebars_test_event_cleanup_on_destroyed_inner"))), "\n  " ];
  });                                                                                                                 // 1568
}));                                                                                                                  // 1569
                                                                                                                      // 1570
Template.__define__("spacebars_test_event_cleanup_on_destroyed_inner", (function() {                                  // 1571
  var view = this;                                                                                                    // 1572
  return HTML.Raw("<span>foo</span>");                                                                                // 1573
}));                                                                                                                  // 1574
                                                                                                                      // 1575
Template.__define__("spacebars_test_isolated_lookup_inclusion", (function() {                                         // 1576
  var view = this;                                                                                                    // 1577
  return "x";                                                                                                         // 1578
}));                                                                                                                  // 1579
                                                                                                                      // 1580
Template.__define__("spacebars_test_isolated_lookup1", (function() {                                                  // 1581
  var view = this;                                                                                                    // 1582
  return [ Spacebars.include(view.lookupTemplate("foo")), "--", Spacebars.include(view.lookupTemplate("spacebars_test_isolated_lookup_inclusion")) ];
}));                                                                                                                  // 1584
                                                                                                                      // 1585
Template.__define__("spacebars_test_isolated_lookup2", (function() {                                                  // 1586
  var view = this;                                                                                                    // 1587
  return Spacebars.With(function() {                                                                                  // 1588
    return Spacebars.call(view.lookup("foo"));                                                                        // 1589
  }, function() {                                                                                                     // 1590
    return [ "\n    ", Spacebars.With(function() {                                                                    // 1591
      return {                                                                                                        // 1592
        z: Spacebars.call(1)                                                                                          // 1593
      };                                                                                                              // 1594
    }, function() {                                                                                                   // 1595
      return [ "\n      ", Spacebars.include(view.lookupTemplate("..")), "--", Spacebars.include(view.lookupTemplate("spacebars_test_isolated_lookup_inclusion")), "\n    " ];
    }), "\n  " ];                                                                                                     // 1597
  });                                                                                                                 // 1598
}));                                                                                                                  // 1599
                                                                                                                      // 1600
Template.__define__("spacebars_test_isolated_lookup3", (function() {                                                  // 1601
  var view = this;                                                                                                    // 1602
  return [ Spacebars.include(view.lookupTemplate("bar")), "--", Spacebars.include(view.lookupTemplate("spacebars_test_isolated_lookup_inclusion")) ];
}));                                                                                                                  // 1604
                                                                                                                      // 1605
Template.__define__("spacebars_test_current_view_in_event", (function() {                                             // 1606
  var view = this;                                                                                                    // 1607
  return HTML.SPAN(Blaze.View(function() {                                                                            // 1608
    return Spacebars.mustache(view.lookup("."));                                                                      // 1609
  }));                                                                                                                // 1610
}));                                                                                                                  // 1611
                                                                                                                      // 1612
Template.__define__("spacebars_test_textarea_attrs", (function() {                                                    // 1613
  var view = this;                                                                                                    // 1614
  return HTML.TEXTAREA(HTML.Attrs(function() {                                                                        // 1615
    return Spacebars.attrMustache(view.lookup("attrs"));                                                              // 1616
  }));                                                                                                                // 1617
}));                                                                                                                  // 1618
                                                                                                                      // 1619
Template.__define__("spacebars_test_textarea_attrs_contents", (function() {                                           // 1620
  var view = this;                                                                                                    // 1621
  return HTML.TEXTAREA(HTML.Attrs(function() {                                                                        // 1622
    return Spacebars.attrMustache(view.lookup("attrs"));                                                              // 1623
  }, {                                                                                                                // 1624
    value: function() {                                                                                               // 1625
      return [ "Hello ", Spacebars.mustache(view.lookup("name")) ];                                                   // 1626
    }                                                                                                                 // 1627
  }));                                                                                                                // 1628
}));                                                                                                                  // 1629
                                                                                                                      // 1630
Template.__define__("spacebars_test_textarea_attrs_array_contents", (function() {                                     // 1631
  var view = this;                                                                                                    // 1632
  return HTML.TEXTAREA(HTML.Attrs({                                                                                   // 1633
    "class": "bar"                                                                                                    // 1634
  }, function() {                                                                                                     // 1635
    return Spacebars.attrMustache(view.lookup("attrs"));                                                              // 1636
  }, {                                                                                                                // 1637
    value: function() {                                                                                               // 1638
      return [ "Hello ", Spacebars.mustache(view.lookup("name")) ];                                                   // 1639
    }                                                                                                                 // 1640
  }));                                                                                                                // 1641
}));                                                                                                                  // 1642
                                                                                                                      // 1643
Template.__define__("spacebars_test_autorun", (function() {                                                           // 1644
  var view = this;                                                                                                    // 1645
  return Blaze.If(function() {                                                                                        // 1646
    return Spacebars.call(view.lookup("show"));                                                                       // 1647
  }, function() {                                                                                                     // 1648
    return [ "\n    ", Spacebars.include(view.lookupTemplate("spacebars_test_autorun_inner")), "\n  " ];              // 1649
  });                                                                                                                 // 1650
}));                                                                                                                  // 1651
                                                                                                                      // 1652
Template.__define__("spacebars_test_autorun_inner", (function() {                                                     // 1653
  var view = this;                                                                                                    // 1654
  return "Hello";                                                                                                     // 1655
}));                                                                                                                  // 1656
                                                                                                                      // 1657
Template.__define__("spacebars_test_contentBlock_arg", (function() {                                                  // 1658
  var view = this;                                                                                                    // 1659
  return Spacebars.include(view.lookupTemplate("spacebars_test_contentBlock_arg_inner"), function() {                 // 1660
    return [ "\n    ", Blaze.View(function() {                                                                        // 1661
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "bar"));                                              // 1662
    }), "\n  " ];                                                                                                     // 1663
  });                                                                                                                 // 1664
}));                                                                                                                  // 1665
                                                                                                                      // 1666
Template.__define__("spacebars_test_contentBlock_arg_inner", (function() {                                            // 1667
  var view = this;                                                                                                    // 1668
  return Spacebars.With(function() {                                                                                  // 1669
    return {                                                                                                          // 1670
      foo: Spacebars.call("AAA"),                                                                                     // 1671
      bar: Spacebars.call("BBB")                                                                                      // 1672
    };                                                                                                                // 1673
  }, function() {                                                                                                     // 1674
    return [ "\n    ", Blaze.View(function() {                                                                        // 1675
      return Spacebars.mustache(Spacebars.dot(view.lookup("."), "foo"));                                              // 1676
    }), " ", Blaze.InOuterTemplateScope(view, function() {                                                            // 1677
      return Spacebars.TemplateWith(function() {                                                                      // 1678
        return Spacebars.call(view.lookup("."));                                                                      // 1679
      }, function() {                                                                                                 // 1680
        return Spacebars.include(function() {                                                                         // 1681
          return Spacebars.call(view.templateContentBlock);                                                           // 1682
        });                                                                                                           // 1683
      });                                                                                                             // 1684
    }), "\n  " ];                                                                                                     // 1685
  });                                                                                                                 // 1686
}));                                                                                                                  // 1687
                                                                                                                      // 1688
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/spacebars-tests/template_tests.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var divRendersTo = function (test, div, html) {                                                                       // 1
  Deps.flush({_throwFirstError: true});                                                                               // 2
  var actual = canonicalizeHtml(div.innerHTML);                                                                       // 3
  test.equal(actual, html);                                                                                           // 4
};                                                                                                                    // 5
                                                                                                                      // 6
var nodesToArray = function (array) {                                                                                 // 7
  // Starting in underscore 1.4, _.toArray does not work right on a node                                              // 8
  // list in IE8. This is a workaround to support IE8.                                                                // 9
  return _.map(array, _.identity);                                                                                    // 10
};                                                                                                                    // 11
                                                                                                                      // 12
var clickIt = function (elem) {                                                                                       // 13
  // jQuery's bubbling change event polyfill for IE 8 seems                                                           // 14
  // to require that the element in question have focus when                                                          // 15
  // it receives a simulated click.                                                                                   // 16
  if (elem.focus)                                                                                                     // 17
    elem.focus();                                                                                                     // 18
  clickElement(elem);                                                                                                 // 19
};                                                                                                                    // 20
                                                                                                                      // 21
Tinytest.add("spacebars-tests - template_tests - simple helper", function (test) {                                    // 22
  var tmpl = Template.spacebars_template_test_simple_helper;                                                          // 23
  var R = ReactiveVar(1);                                                                                             // 24
  tmpl.foo = function (x) {                                                                                           // 25
    return x + R.get();                                                                                               // 26
  };                                                                                                                  // 27
  tmpl.bar = function () {                                                                                            // 28
    return 123;                                                                                                       // 29
  };                                                                                                                  // 30
  var div = renderToDiv(tmpl);                                                                                        // 31
                                                                                                                      // 32
  test.equal(canonicalizeHtml(div.innerHTML), "124");                                                                 // 33
  R.set(2);                                                                                                           // 34
  Deps.flush();                                                                                                       // 35
  test.equal(canonicalizeHtml(div.innerHTML), "125");                                                                 // 36
                                                                                                                      // 37
  // Test that `{{foo bar}}` throws if `foo` is missing or not a function.                                            // 38
  tmpl.foo = 3;                                                                                                       // 39
  test.throws(function () {                                                                                           // 40
    renderToDiv(tmpl);                                                                                                // 41
  }, /Can't call non-function/);                                                                                      // 42
                                                                                                                      // 43
  delete tmpl.foo;                                                                                                    // 44
  test.throws(function () {                                                                                           // 45
    renderToDiv(tmpl);                                                                                                // 46
  }, /No such function/);                                                                                             // 47
                                                                                                                      // 48
  tmpl.foo = function () {};                                                                                          // 49
  // doesn't throw                                                                                                    // 50
  div = renderToDiv(tmpl);                                                                                            // 51
  test.equal(canonicalizeHtml(div.innerHTML), '');                                                                    // 52
                                                                                                                      // 53
  // now "foo" is a function in the data context                                                                      // 54
  delete tmpl.foo;                                                                                                    // 55
                                                                                                                      // 56
  R = ReactiveVar(1);                                                                                                 // 57
  div = renderToDiv(tmpl, { foo: function (x) {                                                                       // 58
    return x + R.get();                                                                                               // 59
  } });                                                                                                               // 60
  test.equal(canonicalizeHtml(div.innerHTML), "124");                                                                 // 61
  R.set(2);                                                                                                           // 62
  Deps.flush();                                                                                                       // 63
  test.equal(canonicalizeHtml(div.innerHTML), "125");                                                                 // 64
                                                                                                                      // 65
  test.throws(function () {                                                                                           // 66
    renderToDiv(tmpl, {foo: 3});                                                                                      // 67
  }, /Can't call non-function/);                                                                                      // 68
                                                                                                                      // 69
  test.throws(function () {                                                                                           // 70
    renderToDiv(tmpl, {foo: null});                                                                                   // 71
  }, /No such function/);                                                                                             // 72
                                                                                                                      // 73
  test.throws(function () {                                                                                           // 74
    renderToDiv(tmpl, {});                                                                                            // 75
  }, /No such function/);                                                                                             // 76
});                                                                                                                   // 77
                                                                                                                      // 78
Tinytest.add("spacebars-tests - template_tests - dynamic template", function (test) {                                 // 79
  var tmpl = Template.spacebars_template_test_dynamic_template;                                                       // 80
  var aaa = Template.spacebars_template_test_aaa;                                                                     // 81
  var bbb = Template.spacebars_template_test_bbb;                                                                     // 82
  var R = ReactiveVar("aaa");                                                                                         // 83
  tmpl.foo = function () {                                                                                            // 84
    return R.get() === 'aaa' ? aaa : bbb;                                                                             // 85
  };                                                                                                                  // 86
  var div = renderToDiv(tmpl);                                                                                        // 87
  test.equal(canonicalizeHtml(div.innerHTML), "aaa");                                                                 // 88
                                                                                                                      // 89
  R.set('bbb');                                                                                                       // 90
  Deps.flush();                                                                                                       // 91
                                                                                                                      // 92
  test.equal(canonicalizeHtml(div.innerHTML), "bbb");                                                                 // 93
});                                                                                                                   // 94
                                                                                                                      // 95
Tinytest.add("spacebars-tests - template_tests - interpolate attribute", function (test) {                            // 96
  var tmpl = Template.spacebars_template_test_interpolate_attribute;                                                  // 97
  tmpl.foo = function (x) {                                                                                           // 98
    return x+1;                                                                                                       // 99
  };                                                                                                                  // 100
  tmpl.bar = function () {                                                                                            // 101
    return 123;                                                                                                       // 102
  };                                                                                                                  // 103
  var div = renderToDiv(tmpl);                                                                                        // 104
                                                                                                                      // 105
  test.equal($(div).find('div')[0].className, "aaa124zzz");                                                           // 106
});                                                                                                                   // 107
                                                                                                                      // 108
Tinytest.add("spacebars-tests - template_tests - dynamic attrs", function (test) {                                    // 109
  var tmpl = Template.spacebars_template_test_dynamic_attrs;                                                          // 110
                                                                                                                      // 111
  var R2 = ReactiveVar({x: "X"});                                                                                     // 112
  var R3 = ReactiveVar('selected');                                                                                   // 113
  tmpl.attrsObj = function () { return R2.get(); };                                                                   // 114
  tmpl.singleAttr = function () { return R3.get(); };                                                                 // 115
                                                                                                                      // 116
  var div = renderToDiv(tmpl);                                                                                        // 117
  var span = $(div).find('span')[0];                                                                                  // 118
  test.equal(span.innerHTML, 'hi');                                                                                   // 119
  test.isTrue(span.hasAttribute('selected'));                                                                         // 120
  test.equal(span.getAttribute('x'), 'X');                                                                            // 121
                                                                                                                      // 122
  R2.set({y: "Y", z: "Z"});                                                                                           // 123
  R3.set('');                                                                                                         // 124
  Deps.flush();                                                                                                       // 125
  test.equal(canonicalizeHtml(span.innerHTML), 'hi');                                                                 // 126
  test.isFalse(span.hasAttribute('selected'));                                                                        // 127
  test.isFalse(span.hasAttribute('x'));                                                                               // 128
  test.equal(span.getAttribute('y'), 'Y');                                                                            // 129
  test.equal(span.getAttribute('z'), 'Z');                                                                            // 130
});                                                                                                                   // 131
                                                                                                                      // 132
Tinytest.add("spacebars-tests - template_tests - triple", function (test) {                                           // 133
  var tmpl = Template.spacebars_template_test_triple;                                                                 // 134
                                                                                                                      // 135
  var R = ReactiveVar('<span class="hi">blah</span>');                                                                // 136
  tmpl.html = function () { return R.get(); };                                                                        // 137
                                                                                                                      // 138
  var div = renderToDiv(tmpl);                                                                                        // 139
  var elems = $(div).find("> *");                                                                                     // 140
  test.equal(elems.length, 1);                                                                                        // 141
  test.equal(elems[0].nodeName, 'SPAN');                                                                              // 142
  var span = elems[0];                                                                                                // 143
  test.equal(span.className, 'hi');                                                                                   // 144
  test.equal(span.innerHTML, 'blah');                                                                                 // 145
                                                                                                                      // 146
  R.set('asdf');                                                                                                      // 147
  Deps.flush();                                                                                                       // 148
  elems = $(div).find("> *");                                                                                         // 149
  test.equal(elems.length, 0);                                                                                        // 150
  test.equal(canonicalizeHtml(div.innerHTML), 'asdf');                                                                // 151
                                                                                                                      // 152
  R.set('<span class="hi">blah</span>');                                                                              // 153
  Deps.flush();                                                                                                       // 154
  elems = $(div).find("> *");                                                                                         // 155
  test.equal(elems.length, 1);                                                                                        // 156
  test.equal(elems[0].nodeName, 'SPAN');                                                                              // 157
  span = elems[0];                                                                                                    // 158
  test.equal(span.className, 'hi');                                                                                   // 159
  test.equal(canonicalizeHtml(span.innerHTML), 'blah');                                                               // 160
                                                                                                                      // 161
  var tmpl = Template.spacebars_template_test_triple2;                                                                // 162
  tmpl.html = function () {};                                                                                         // 163
  tmpl.html2 = function () { return null; };                                                                          // 164
  // no tmpl.html3                                                                                                    // 165
  div = renderToDiv(tmpl);                                                                                            // 166
  test.equal(canonicalizeHtml(div.innerHTML), 'xy');                                                                  // 167
});                                                                                                                   // 168
                                                                                                                      // 169
Tinytest.add("spacebars-tests - template_tests - inclusion args", function (test) {                                   // 170
  var tmpl = Template.spacebars_template_test_inclusion_args;                                                         // 171
                                                                                                                      // 172
  var R = ReactiveVar(Template.spacebars_template_test_aaa);                                                          // 173
  tmpl.foo = function () { return R.get(); };                                                                         // 174
                                                                                                                      // 175
  var div = renderToDiv(tmpl);                                                                                        // 176
  // `{{> foo bar}}`, with `foo` resolving to Template.aaa,                                                           // 177
  // which consists of "aaa"                                                                                          // 178
  test.equal(canonicalizeHtml(div.innerHTML), 'aaa');                                                                 // 179
  R.set(Template.spacebars_template_test_bbb);                                                                        // 180
  Deps.flush();                                                                                                       // 181
  test.equal(canonicalizeHtml(div.innerHTML), 'bbb');                                                                 // 182
                                                                                                                      // 183
  ////// Ok, now `foo` *is* Template.aaa                                                                              // 184
  tmpl.foo = Template.spacebars_template_test_aaa;                                                                    // 185
  div = renderToDiv(tmpl);                                                                                            // 186
  test.equal(canonicalizeHtml(div.innerHTML), 'aaa');                                                                 // 187
                                                                                                                      // 188
  ////// Ok, now `foo` is a template that takes an argument; bar is a string.                                         // 189
  tmpl.foo = Template.spacebars_template_test_bracketed_this;                                                         // 190
  tmpl.bar = 'david';                                                                                                 // 191
  div = renderToDiv(tmpl);                                                                                            // 192
  test.equal(canonicalizeHtml(div.innerHTML), '[david]');                                                             // 193
                                                                                                                      // 194
  ////// Now `foo` is a template that takes an arg; bar is a function.                                                // 195
  tmpl.foo = Template.spacebars_template_test_span_this;                                                              // 196
  R = ReactiveVar('david');                                                                                           // 197
  tmpl.bar = function () { return R.get(); };                                                                         // 198
  div = renderToDiv(tmpl);                                                                                            // 199
  test.equal(canonicalizeHtml(div.innerHTML), '<span>david</span>');                                                  // 200
  var span1 = div.querySelector('span');                                                                              // 201
  R.set('avi');                                                                                                       // 202
  Deps.flush();                                                                                                       // 203
  test.equal(canonicalizeHtml(div.innerHTML), '<span>avi</span>');                                                    // 204
  var span2 = div.querySelector('span');                                                                              // 205
  test.isTrue(span1 === span2);                                                                                       // 206
});                                                                                                                   // 207
                                                                                                                      // 208
Tinytest.add("spacebars-tests - template_tests - inclusion args 2", function (test) {                                 // 209
  // `{{> foo bar q=baz}}`                                                                                            // 210
  var tmpl = Template.spacebars_template_test_inclusion_args2;                                                        // 211
                                                                                                                      // 212
  tmpl.foo = Template.spacebars_template_test_span_this;                                                              // 213
  tmpl.bar = function (options) {                                                                                     // 214
    return options.hash.q;                                                                                            // 215
  };                                                                                                                  // 216
                                                                                                                      // 217
  var R = ReactiveVar('david!');                                                                                      // 218
  tmpl.baz = function () { return R.get().slice(0,5); };                                                              // 219
  var div = renderToDiv(tmpl);                                                                                        // 220
  test.equal(canonicalizeHtml(div.innerHTML), '<span>david</span>');                                                  // 221
  var span1 = div.querySelector('span');                                                                              // 222
  R.set('brillo');                                                                                                    // 223
  Deps.flush();                                                                                                       // 224
  test.equal(canonicalizeHtml(div.innerHTML), '<span>brill</span>');                                                  // 225
  var span2 = div.querySelector('span');                                                                              // 226
  test.isTrue(span1 === span2);                                                                                       // 227
});                                                                                                                   // 228
                                                                                                                      // 229
// maybe use created callback on the template instead of this?                                                        // 230
var extendTemplateWithInit = function (template, initFunc) {                                                          // 231
  return Template.__create__(                                                                                         // 232
    template.__viewName+'-extended',                                                                                  // 233
    template.__render,                                                                                                // 234
    initFunc);                                                                                                        // 235
};                                                                                                                    // 236
                                                                                                                      // 237
Tinytest.add("spacebars-tests - template_tests - inclusion dotted args", function (test) {                            // 238
  // `{{> foo bar.baz}}`                                                                                              // 239
  var tmpl = Template.spacebars_template_test_inclusion_dotted_args;                                                  // 240
                                                                                                                      // 241
  var initCount = 0;                                                                                                  // 242
  tmpl.foo = extendTemplateWithInit(                                                                                  // 243
    Template.spacebars_template_test_bracketed_this,                                                                  // 244
    function () { initCount++; });                                                                                    // 245
                                                                                                                      // 246
  var R = ReactiveVar('david');                                                                                       // 247
  tmpl.bar = function () {                                                                                            // 248
    // make sure `this` is bound correctly                                                                            // 249
    return { baz: this.symbol + R.get() };                                                                            // 250
  };                                                                                                                  // 251
                                                                                                                      // 252
  var div = renderToDiv(tmpl, {symbol:'%'});                                                                          // 253
  test.equal(initCount, 1);                                                                                           // 254
  test.equal(canonicalizeHtml(div.innerHTML), '[%david]');                                                            // 255
                                                                                                                      // 256
  R.set('avi');                                                                                                       // 257
  Deps.flush();                                                                                                       // 258
  test.equal(canonicalizeHtml(div.innerHTML), '[%avi]');                                                              // 259
  // check that invalidating the argument to `foo` doesn't require                                                    // 260
  // creating a new `foo`.                                                                                            // 261
  test.equal(initCount, 1);                                                                                           // 262
});                                                                                                                   // 263
                                                                                                                      // 264
Tinytest.add("spacebars-tests - template_tests - inclusion slashed args", function (test) {                           // 265
  // `{{> foo bar/baz}}`                                                                                              // 266
  var tmpl = Template.spacebars_template_test_inclusion_dotted_args;                                                  // 267
                                                                                                                      // 268
  var initCount = 0;                                                                                                  // 269
  tmpl.foo = extendTemplateWithInit(                                                                                  // 270
    Template.spacebars_template_test_bracketed_this,                                                                  // 271
    function () { initCount++; });                                                                                    // 272
  var R = ReactiveVar('david');                                                                                       // 273
  tmpl.bar = function () {                                                                                            // 274
    // make sure `this` is bound correctly                                                                            // 275
    return { baz: this.symbol + R.get() };                                                                            // 276
  };                                                                                                                  // 277
                                                                                                                      // 278
  var div = renderToDiv(tmpl, {symbol:'%'});                                                                          // 279
  test.equal(initCount, 1);                                                                                           // 280
  test.equal(canonicalizeHtml(div.innerHTML), '[%david]');                                                            // 281
});                                                                                                                   // 282
                                                                                                                      // 283
Tinytest.add("spacebars-tests - template_tests - block helper", function (test) {                                     // 284
  // test the case where `foo` is a calculated template that changes                                                  // 285
  // reactively.                                                                                                      // 286
  // `{{#foo}}bar{{else}}baz{{/foo}}`                                                                                 // 287
  var tmpl = Template.spacebars_template_test_block_helper;                                                           // 288
  var R = ReactiveVar(Template.spacebars_template_test_content);                                                      // 289
  tmpl.foo = function () {                                                                                            // 290
    return R.get();                                                                                                   // 291
  };                                                                                                                  // 292
  var div = renderToDiv(tmpl);                                                                                        // 293
  test.equal(canonicalizeHtml(div.innerHTML), "bar");                                                                 // 294
                                                                                                                      // 295
  R.set(Template.spacebars_template_test_elsecontent);                                                                // 296
  Deps.flush();                                                                                                       // 297
  test.equal(canonicalizeHtml(div.innerHTML), "baz");                                                                 // 298
});                                                                                                                   // 299
                                                                                                                      // 300
Tinytest.add("spacebars-tests - template_tests - block helper function with one string arg", function (test) {        // 301
  // `{{#foo "bar"}}content{{/foo}}`                                                                                  // 302
  var tmpl = Template.spacebars_template_test_block_helper_function_one_string_arg;                                   // 303
  tmpl.foo = function () {                                                                                            // 304
    if (String(this) === "bar")                                                                                       // 305
      return Template.spacebars_template_test_content;                                                                // 306
    else                                                                                                              // 307
      return null;                                                                                                    // 308
  };                                                                                                                  // 309
  var div = renderToDiv(tmpl);                                                                                        // 310
  test.equal(canonicalizeHtml(div.innerHTML), "content");                                                             // 311
});                                                                                                                   // 312
                                                                                                                      // 313
Tinytest.add("spacebars-tests - template_tests - block helper function with one helper arg", function (test) {        // 314
  var tmpl = Template.spacebars_template_test_block_helper_function_one_helper_arg;                                   // 315
  var R = ReactiveVar("bar");                                                                                         // 316
  tmpl.bar = function () { return R.get(); };                                                                         // 317
  tmpl.foo = function () {                                                                                            // 318
    if (String(this) === "bar")                                                                                       // 319
      return Template.spacebars_template_test_content;                                                                // 320
    else                                                                                                              // 321
      return null;                                                                                                    // 322
  };                                                                                                                  // 323
  var div = renderToDiv(tmpl);                                                                                        // 324
  test.equal(canonicalizeHtml(div.innerHTML), "content");                                                             // 325
                                                                                                                      // 326
  R.set("baz");                                                                                                       // 327
  Deps.flush();                                                                                                       // 328
  test.equal(canonicalizeHtml(div.innerHTML), "");                                                                    // 329
});                                                                                                                   // 330
                                                                                                                      // 331
Tinytest.add("spacebars-tests - template_tests - block helper component with one helper arg", function (test) {       // 332
  var tmpl = Template.spacebars_template_test_block_helper_component_one_helper_arg;                                  // 333
  var R = ReactiveVar(true);                                                                                          // 334
  tmpl.bar = function () { return R.get(); };                                                                         // 335
  var div = renderToDiv(tmpl);                                                                                        // 336
  test.equal(canonicalizeHtml(div.innerHTML), "content");                                                             // 337
                                                                                                                      // 338
  R.set(false);                                                                                                       // 339
  Deps.flush();                                                                                                       // 340
  test.equal(canonicalizeHtml(div.innerHTML), "");                                                                    // 341
});                                                                                                                   // 342
                                                                                                                      // 343
Tinytest.add("spacebars-tests - template_tests - block helper component with three helper args", function (test) {    // 344
  var tmpl = Template.spacebars_template_test_block_helper_component_three_helper_args;                               // 345
  var R = ReactiveVar("bar");                                                                                         // 346
  tmpl.bar_or_baz = function () {                                                                                     // 347
    return R.get();                                                                                                   // 348
  };                                                                                                                  // 349
  tmpl.equals = function (x, y) {                                                                                     // 350
    return x === y;                                                                                                   // 351
  };                                                                                                                  // 352
  var div = renderToDiv(tmpl);                                                                                        // 353
  test.equal(canonicalizeHtml(div.innerHTML), "content");                                                             // 354
                                                                                                                      // 355
  R.set("baz");                                                                                                       // 356
  Deps.flush();                                                                                                       // 357
  test.equal(canonicalizeHtml(div.innerHTML), "");                                                                    // 358
});                                                                                                                   // 359
                                                                                                                      // 360
Tinytest.add("spacebars-tests - template_tests - block helper with dotted arg", function (test) {                     // 361
  var tmpl = Template.spacebars_template_test_block_helper_dotted_arg;                                                // 362
  var R1 = ReactiveVar(1);                                                                                            // 363
  var R2 = ReactiveVar(10);                                                                                           // 364
  var R3 = ReactiveVar(100);                                                                                          // 365
                                                                                                                      // 366
  var initCount = 0;                                                                                                  // 367
  tmpl.foo = extendTemplateWithInit(                                                                                  // 368
    Template.spacebars_template_test_bracketed_this,                                                                  // 369
    function () { initCount++; });                                                                                    // 370
  tmpl.bar = function () {                                                                                            // 371
    return {                                                                                                          // 372
      r1: R1.get(),                                                                                                   // 373
      baz: function (r3) {                                                                                            // 374
        return this.r1 + R2.get() + r3;                                                                               // 375
      }                                                                                                               // 376
    };                                                                                                                // 377
  };                                                                                                                  // 378
  tmpl.qux = function () { return R3.get(); };                                                                        // 379
                                                                                                                      // 380
  var div = renderToDiv(tmpl);                                                                                        // 381
  test.equal(canonicalizeHtml(div.innerHTML), "[111]");                                                               // 382
  test.equal(initCount, 1);                                                                                           // 383
                                                                                                                      // 384
  R1.set(2);                                                                                                          // 385
  Deps.flush();                                                                                                       // 386
  test.equal(canonicalizeHtml(div.innerHTML), "[112]");                                                               // 387
  test.equal(initCount, 1);                                                                                           // 388
                                                                                                                      // 389
  R2.set(20);                                                                                                         // 390
  Deps.flush();                                                                                                       // 391
  test.equal(canonicalizeHtml(div.innerHTML), "[122]");                                                               // 392
  test.equal(initCount, 1);                                                                                           // 393
                                                                                                                      // 394
  R3.set(200);                                                                                                        // 395
  Deps.flush();                                                                                                       // 396
  test.equal(canonicalizeHtml(div.innerHTML), "[222]");                                                               // 397
  test.equal(initCount, 1);                                                                                           // 398
                                                                                                                      // 399
  R2.set(30);                                                                                                         // 400
  Deps.flush();                                                                                                       // 401
  test.equal(canonicalizeHtml(div.innerHTML), "[232]");                                                               // 402
  test.equal(initCount, 1);                                                                                           // 403
                                                                                                                      // 404
  R1.set(3);                                                                                                          // 405
  Deps.flush();                                                                                                       // 406
  test.equal(canonicalizeHtml(div.innerHTML), "[233]");                                                               // 407
  test.equal(initCount, 1);                                                                                           // 408
                                                                                                                      // 409
  R3.set(300);                                                                                                        // 410
  Deps.flush();                                                                                                       // 411
  test.equal(canonicalizeHtml(div.innerHTML), "[333]");                                                               // 412
  test.equal(initCount, 1);                                                                                           // 413
});                                                                                                                   // 414
                                                                                                                      // 415
Tinytest.add("spacebars-tests - template_tests - nested content", function (test) {                                   // 416
  // Test that `{{> UI.contentBlock}}` in an `{{#if}}` works.                                                         // 417
                                                                                                                      // 418
  // ```                                                                                                              // 419
  // <template name="spacebars_template_test_iftemplate">                                                             // 420
  //   {{#if condition}}                                                                                              // 421
  //     {{> UI.contentBlock}}                                                                                        // 422
  //   {{else}}                                                                                                       // 423
  //     {{> UI.elseBlock}}                                                                                           // 424
  //   {{/if}}                                                                                                        // 425
  // </template>                                                                                                      // 426
  // ```                                                                                                              // 427
                                                                                                                      // 428
  // ```                                                                                                              // 429
  //  {{#spacebars_template_test_iftemplate flag}}                                                                    // 430
  //    hello                                                                                                         // 431
  //  {{else}}                                                                                                        // 432
  //    world                                                                                                         // 433
  //  {{/spacebars_template_test_iftemplate}}                                                                         // 434
  // ```                                                                                                              // 435
                                                                                                                      // 436
  var tmpl = Template.spacebars_template_test_nested_content;                                                         // 437
  var R = ReactiveVar(true);                                                                                          // 438
  tmpl.flag = function () {                                                                                           // 439
    return R.get();                                                                                                   // 440
  };                                                                                                                  // 441
  var div = renderToDiv(tmpl);                                                                                        // 442
  test.equal(canonicalizeHtml(div.innerHTML), 'hello');                                                               // 443
  R.set(false);                                                                                                       // 444
  Deps.flush();                                                                                                       // 445
  test.equal(canonicalizeHtml(div.innerHTML), 'world');                                                               // 446
  R.set(true);                                                                                                        // 447
  Deps.flush();                                                                                                       // 448
  test.equal(canonicalizeHtml(div.innerHTML), 'hello');                                                               // 449
                                                                                                                      // 450
  // Also test that `{{> UI.contentBlock}}` in a custom block helper works.                                           // 451
  tmpl = Template.spacebars_template_test_nested_content2;                                                            // 452
  R = ReactiveVar(true);                                                                                              // 453
  tmpl.x = function () {                                                                                              // 454
    return R.get();                                                                                                   // 455
  };                                                                                                                  // 456
  div = renderToDiv(tmpl);                                                                                            // 457
  test.equal(canonicalizeHtml(div.innerHTML), 'hello');                                                               // 458
  R.set(false);                                                                                                       // 459
  Deps.flush();                                                                                                       // 460
  test.equal(canonicalizeHtml(div.innerHTML), 'world');                                                               // 461
  R.set(true);                                                                                                        // 462
  Deps.flush();                                                                                                       // 463
  test.equal(canonicalizeHtml(div.innerHTML), 'hello');                                                               // 464
});                                                                                                                   // 465
                                                                                                                      // 466
Tinytest.add("spacebars-tests - template_tests - if", function (test) {                                               // 467
  var tmpl = Template.spacebars_template_test_if;                                                                     // 468
  var R = ReactiveVar(true);                                                                                          // 469
  tmpl.foo = function () {                                                                                            // 470
    return R.get();                                                                                                   // 471
  };                                                                                                                  // 472
  tmpl.bar = 1;                                                                                                       // 473
  tmpl.baz = 2;                                                                                                       // 474
                                                                                                                      // 475
  var div = renderToDiv(tmpl);                                                                                        // 476
  var rendersTo = function (html) { divRendersTo(test, div, html); };                                                 // 477
                                                                                                                      // 478
  rendersTo("1");                                                                                                     // 479
  R.set(false);                                                                                                       // 480
  rendersTo("2");                                                                                                     // 481
});                                                                                                                   // 482
                                                                                                                      // 483
Tinytest.add("spacebars-tests - template_tests - if in with", function (test) {                                       // 484
  var tmpl = Template.spacebars_template_test_if_in_with;                                                             // 485
  tmpl.foo = {bar: "bar"};                                                                                            // 486
                                                                                                                      // 487
  var div = renderToDiv(tmpl);                                                                                        // 488
  divRendersTo(test, div, "bar bar");                                                                                 // 489
});                                                                                                                   // 490
                                                                                                                      // 491
Tinytest.add("spacebars-tests - template_tests - each on cursor", function (test) {                                   // 492
  var tmpl = Template.spacebars_template_test_each;                                                                   // 493
  var coll = new Meteor.Collection(null);                                                                             // 494
  tmpl.items = function () {                                                                                          // 495
    return coll.find({}, {sort: {pos: 1}});                                                                           // 496
  };                                                                                                                  // 497
                                                                                                                      // 498
  var div = renderToDiv(tmpl);                                                                                        // 499
  var rendersTo = function (html) { divRendersTo(test, div, html); };                                                 // 500
                                                                                                                      // 501
  rendersTo("else-clause");                                                                                           // 502
  coll.insert({text: "one", pos: 1});                                                                                 // 503
  rendersTo("one");                                                                                                   // 504
  coll.insert({text: "two", pos: 2});                                                                                 // 505
  rendersTo("one two");                                                                                               // 506
  coll.update({text: "two"}, {$set: {text: "three"}});                                                                // 507
  rendersTo("one three");                                                                                             // 508
  coll.update({text: "three"}, {$set: {pos: 0}});                                                                     // 509
  rendersTo("three one");                                                                                             // 510
  coll.remove({});                                                                                                    // 511
  rendersTo("else-clause");                                                                                           // 512
});                                                                                                                   // 513
                                                                                                                      // 514
Tinytest.add("spacebars-tests - template_tests - each on array", function (test) {                                    // 515
  var tmpl = Template.spacebars_template_test_each;                                                                   // 516
  var R = new ReactiveVar([]);                                                                                        // 517
  tmpl.items = function () {                                                                                          // 518
    return R.get();                                                                                                   // 519
  };                                                                                                                  // 520
  tmpl.text = function () {                                                                                           // 521
    return this;                                                                                                      // 522
  };                                                                                                                  // 523
                                                                                                                      // 524
  var div = renderToDiv(tmpl);                                                                                        // 525
  var rendersTo = function (html) { divRendersTo(test, div, html); };                                                 // 526
                                                                                                                      // 527
  rendersTo("else-clause");                                                                                           // 528
  R.set([""]);                                                                                                        // 529
  rendersTo("");                                                                                                      // 530
  R.set(["x", "", "toString"]);                                                                                       // 531
  rendersTo("x toString");                                                                                            // 532
  R.set(["toString"]);                                                                                                // 533
  rendersTo("toString");                                                                                              // 534
  R.set([]);                                                                                                          // 535
  rendersTo("else-clause");                                                                                           // 536
  R.set([0, 1, 2]);                                                                                                   // 537
  rendersTo("0 1 2");                                                                                                 // 538
  R.set([]);                                                                                                          // 539
  rendersTo("else-clause");                                                                                           // 540
});                                                                                                                   // 541
                                                                                                                      // 542
Tinytest.add("spacebars-tests - template_tests - ..", function (test) {                                               // 543
  var tmpl = Template.spacebars_template_test_dots;                                                                   // 544
  Template.spacebars_template_test_dots_subtemplate.getTitle = function (from) {                                      // 545
    return from.title;                                                                                                // 546
  };                                                                                                                  // 547
                                                                                                                      // 548
  tmpl.foo = {title: "foo"};                                                                                          // 549
  tmpl.foo.bar = {title: "bar"};                                                                                      // 550
  tmpl.foo.bar.items = [{title: "item"}];                                                                             // 551
  var div = renderToDiv(tmpl);                                                                                        // 552
                                                                                                                      // 553
  test.equal(canonicalizeHtml(div.innerHTML), [                                                                       // 554
    "A", "B", "C", "D",                                                                                               // 555
    // {{> spacebars_template_test_dots_subtemplate}}                                                                 // 556
    "TITLE", "1item", "2item", "3bar", "4foo", "GETTITLE", "5item", "6bar", "7foo",                                   // 557
    // {{> spacebars_template_test_dots_subtemplate ..}}                                                              // 558
    "TITLE", "1bar", "2bar", "3item", "4bar", "GETTITLE", "5bar", "6item", "7bar"].join(" "));                        // 559
});                                                                                                                   // 560
                                                                                                                      // 561
Tinytest.add("spacebars-tests - template_tests - select tags", function (test) {                                      // 562
  var tmpl = Template.spacebars_template_test_select_tag;                                                             // 563
                                                                                                                      // 564
  // {label: (string)}                                                                                                // 565
  var optgroups = new Meteor.Collection(null);                                                                        // 566
                                                                                                                      // 567
  // {optgroup: (id), value: (string), selected: (boolean), label: (string)}                                          // 568
  var options = new Meteor.Collection(null);                                                                          // 569
                                                                                                                      // 570
  tmpl.optgroups = function () { return optgroups.find(); };                                                          // 571
  tmpl.options = function () { return options.find({optgroup: this._id}); };                                          // 572
  tmpl.selectedAttr = function () { return this.selected ? {selected: true} : {}; };                                  // 573
                                                                                                                      // 574
  var div = renderToDiv(tmpl);                                                                                        // 575
  var selectEl = $(div).find('select')[0];                                                                            // 576
                                                                                                                      // 577
  // returns canonicalized contents of `div` in the form eg                                                           // 578
  // ["<select>", "</select>"]. strip out selected attributes -- we                                                   // 579
  // verify correctness by observing the `selected` property                                                          // 580
  var divContent = function () {                                                                                      // 581
    return canonicalizeHtml(                                                                                          // 582
      div.innerHTML.replace(/selected="[^"]*"/g, '').replace(/selected/g, ''))                                        // 583
          .replace(/\>\s*\</g, '>\n<')                                                                                // 584
          .split('\n');                                                                                               // 585
  };                                                                                                                  // 586
                                                                                                                      // 587
  test.equal(divContent(), ["<select>", "</select>"]);                                                                // 588
                                                                                                                      // 589
  var optgroup1 = optgroups.insert({label: "one"});                                                                   // 590
  var optgroup2 = optgroups.insert({label: "two"});                                                                   // 591
  test.equal(divContent(), [                                                                                          // 592
    '<select>',                                                                                                       // 593
    '<optgroup label="one">',                                                                                         // 594
    '</optgroup>',                                                                                                    // 595
    '<optgroup label="two">',                                                                                         // 596
    '</optgroup>',                                                                                                    // 597
    '</select>'                                                                                                       // 598
  ]);                                                                                                                 // 599
                                                                                                                      // 600
  options.insert({optgroup: optgroup1, value: "value1", selected: false, label: "label1"});                           // 601
  options.insert({optgroup: optgroup1, value: "value2", selected: true, label: "label2"});                            // 602
  test.equal(divContent(), [                                                                                          // 603
    '<select>',                                                                                                       // 604
    '<optgroup label="one">',                                                                                         // 605
    '<option value="value1">label1</option>',                                                                         // 606
    '<option value="value2">label2</option>',                                                                         // 607
    '</optgroup>',                                                                                                    // 608
    '<optgroup label="two">',                                                                                         // 609
    '</optgroup>',                                                                                                    // 610
    '</select>'                                                                                                       // 611
  ]);                                                                                                                 // 612
  test.equal(selectEl.value, "value2");                                                                               // 613
  test.equal($(selectEl).find('option')[0].selected, false);                                                          // 614
  test.equal($(selectEl).find('option')[1].selected, true);                                                           // 615
                                                                                                                      // 616
  // swap selection                                                                                                   // 617
  options.update({value: "value1"}, {$set: {selected: true}});                                                        // 618
  options.update({value: "value2"}, {$set: {selected: false}});                                                       // 619
  Deps.flush();                                                                                                       // 620
                                                                                                                      // 621
  test.equal(divContent(), [                                                                                          // 622
    '<select>',                                                                                                       // 623
    '<optgroup label="one">',                                                                                         // 624
    '<option value="value1">label1</option>',                                                                         // 625
    '<option value="value2">label2</option>',                                                                         // 626
    '</optgroup>',                                                                                                    // 627
    '<optgroup label="two">',                                                                                         // 628
    '</optgroup>',                                                                                                    // 629
    '</select>'                                                                                                       // 630
  ]);                                                                                                                 // 631
  test.equal(selectEl.value, "value1");                                                                               // 632
  test.equal($(selectEl).find('option')[0].selected, true);                                                           // 633
  test.equal($(selectEl).find('option')[1].selected, false);                                                          // 634
                                                                                                                      // 635
  // change value and label                                                                                           // 636
  options.update({value: "value1"}, {$set: {value: "value1.0"}});                                                     // 637
  options.update({value: "value2"}, {$set: {label: "label2.0"}});                                                     // 638
  Deps.flush();                                                                                                       // 639
                                                                                                                      // 640
  test.equal(divContent(), [                                                                                          // 641
    '<select>',                                                                                                       // 642
    '<optgroup label="one">',                                                                                         // 643
    '<option value="value1.0">label1</option>',                                                                       // 644
    '<option value="value2">label2.0</option>',                                                                       // 645
    '</optgroup>',                                                                                                    // 646
    '<optgroup label="two">',                                                                                         // 647
    '</optgroup>',                                                                                                    // 648
    '</select>'                                                                                                       // 649
  ]);                                                                                                                 // 650
  test.equal(selectEl.value, "value1.0");                                                                             // 651
  test.equal($(selectEl).find('option')[0].selected, true);                                                           // 652
  test.equal($(selectEl).find('option')[1].selected, false);                                                          // 653
                                                                                                                      // 654
  // unselect and then select both options. normally, the second is                                                   // 655
  // selected (since it got selected later). then switch to <select                                                   // 656
  // multiple="">. both should be selected.                                                                           // 657
  options.update({}, {$set: {selected: false}}, {multi: true});                                                       // 658
  Deps.flush();                                                                                                       // 659
  options.update({}, {$set: {selected: true}}, {multi: true});                                                        // 660
  Deps.flush();                                                                                                       // 661
  test.equal($(selectEl).find('option')[0].selected, false);                                                          // 662
  test.equal($(selectEl).find('option')[1].selected, true);                                                           // 663
                                                                                                                      // 664
  selectEl.multiple = true; // allow multiple selection                                                               // 665
  options.update({}, {$set: {selected: false}}, {multi: true});                                                       // 666
  Deps.flush();                                                                                                       // 667
  options.update({}, {$set: {selected: true}}, {multi: true});                                                        // 668
  window.avital = true;                                                                                               // 669
  Deps.flush();                                                                                                       // 670
  test.equal($(selectEl).find('option')[0].selected, true);                                                           // 671
  test.equal($(selectEl).find('option')[1].selected, true);                                                           // 672
});                                                                                                                   // 673
                                                                                                                      // 674
Tinytest.add('spacebars-tests - template_tests - {{#with}} falsy; issue #770', function (test) {                      // 675
  Template.test_template_issue770.value1 = function () { return "abc"; };                                             // 676
  Template.test_template_issue770.value2 = function () { return false; };                                             // 677
  var div = renderToDiv(Template.test_template_issue770);                                                             // 678
  test.equal(canonicalizeHtml(div.innerHTML),                                                                         // 679
             "abc xxx abc");                                                                                          // 680
});                                                                                                                   // 681
                                                                                                                      // 682
Tinytest.add("spacebars-tests - template_tests - tricky attrs", function (test) {                                     // 683
  var tmpl = Template.spacebars_template_test_tricky_attrs;                                                           // 684
  tmpl.theType = function () { return 'text'; };                                                                      // 685
  var R = ReactiveVar('foo');                                                                                         // 686
  tmpl.theClass = function () { return R.get(); };                                                                    // 687
                                                                                                                      // 688
  var div = renderToDiv(tmpl);                                                                                        // 689
  test.equal(canonicalizeHtml(div.innerHTML).slice(0, 30),                                                            // 690
             '<input type="text"><input class="foo" type="checkbox">'.slice(0, 30));                                  // 691
                                                                                                                      // 692
  R.set('bar');                                                                                                       // 693
  Deps.flush();                                                                                                       // 694
  test.equal(canonicalizeHtml(div.innerHTML),                                                                         // 695
             '<input type="text"><input class="bar" type="checkbox">');                                               // 696
                                                                                                                      // 697
});                                                                                                                   // 698
                                                                                                                      // 699
Tinytest.add('spacebars-tests - template_tests - no data context', function (test) {                                  // 700
  var tmpl = Template.spacebars_template_test_no_data;                                                                // 701
                                                                                                                      // 702
  // failure is if an exception is thrown here                                                                        // 703
  var div = renderToDiv(tmpl);                                                                                        // 704
  test.equal(canonicalizeHtml(div.innerHTML), 'asdf');                                                                // 705
});                                                                                                                   // 706
                                                                                                                      // 707
Tinytest.add('spacebars-tests - template_tests - textarea', function (test) {                                         // 708
  var tmpl = Template.spacebars_template_test_textarea;                                                               // 709
                                                                                                                      // 710
  var R = ReactiveVar('hello');                                                                                       // 711
                                                                                                                      // 712
  tmpl.foo = function () {                                                                                            // 713
    return R.get();                                                                                                   // 714
  };                                                                                                                  // 715
                                                                                                                      // 716
  var div = renderToDiv(tmpl);                                                                                        // 717
  var textarea = div.querySelector('textarea');                                                                       // 718
  test.equal(textarea.value, 'hello');                                                                                // 719
                                                                                                                      // 720
  R.set('world');                                                                                                     // 721
  Deps.flush();                                                                                                       // 722
  test.equal(textarea.value, 'world');                                                                                // 723
                                                                                                                      // 724
});                                                                                                                   // 725
                                                                                                                      // 726
Tinytest.add('spacebars-tests - template_tests - textarea 2', function (test) {                                       // 727
  var tmpl = Template.spacebars_template_test_textarea2;                                                              // 728
                                                                                                                      // 729
  var R = ReactiveVar(true);                                                                                          // 730
                                                                                                                      // 731
  tmpl.foo = function () {                                                                                            // 732
    return R.get();                                                                                                   // 733
  };                                                                                                                  // 734
                                                                                                                      // 735
  var div = renderToDiv(tmpl);                                                                                        // 736
  var textarea = div.querySelector('textarea');                                                                       // 737
  test.equal(textarea.value, '</not a tag>');                                                                         // 738
                                                                                                                      // 739
  R.set(false);                                                                                                       // 740
  Deps.flush();                                                                                                       // 741
  test.equal(textarea.value, '<also not a tag>');                                                                     // 742
                                                                                                                      // 743
  R.set(true);                                                                                                        // 744
  Deps.flush();                                                                                                       // 745
  test.equal(textarea.value, '</not a tag>');                                                                         // 746
                                                                                                                      // 747
});                                                                                                                   // 748
                                                                                                                      // 749
Tinytest.add('spacebars-tests - template_tests - textarea 3', function (test) {                                       // 750
  var tmpl = Template.spacebars_template_test_textarea3;                                                              // 751
                                                                                                                      // 752
  var R = ReactiveVar('hello');                                                                                       // 753
                                                                                                                      // 754
  tmpl.foo = function () {                                                                                            // 755
    return R.get();                                                                                                   // 756
  };                                                                                                                  // 757
                                                                                                                      // 758
  var div = renderToDiv(tmpl);                                                                                        // 759
  var textarea = div.querySelector('textarea');                                                                       // 760
  test.equal(textarea.id, 'myTextarea');                                                                              // 761
  test.equal(textarea.value, 'hello');                                                                                // 762
                                                                                                                      // 763
  R.set('world');                                                                                                     // 764
  Deps.flush();                                                                                                       // 765
  test.equal(textarea.value, 'world');                                                                                // 766
                                                                                                                      // 767
});                                                                                                                   // 768
                                                                                                                      // 769
Tinytest.add('spacebars-tests - template_tests - textarea each', function (test) {                                    // 770
  var tmpl = Template.spacebars_template_test_textarea_each;                                                          // 771
                                                                                                                      // 772
  var R = ReactiveVar(['APPLE', 'BANANA']);                                                                           // 773
                                                                                                                      // 774
  tmpl.foo = function () {                                                                                            // 775
    return R.get();                                                                                                   // 776
  };                                                                                                                  // 777
                                                                                                                      // 778
  var div = renderToDiv(tmpl);                                                                                        // 779
  var textarea = div.querySelector('textarea');                                                                       // 780
  test.equal(textarea.value, '<not a tag APPLE <not a tag BANANA ');                                                  // 781
                                                                                                                      // 782
  R.set([]);                                                                                                          // 783
  Deps.flush();                                                                                                       // 784
  test.equal(textarea.value, '<>');                                                                                   // 785
                                                                                                                      // 786
  R.set(['CUCUMBER']);                                                                                                // 787
  Deps.flush();                                                                                                       // 788
  test.equal(textarea.value, '<not a tag CUCUMBER ');                                                                 // 789
                                                                                                                      // 790
});                                                                                                                   // 791
                                                                                                                      // 792
// Ensure that one can call `Meteor.defer` within a rendered callback                                                 // 793
// triggered by a document insertion that happend in a method stub.                                                   // 794
//                                                                                                                    // 795
// Why do we have this test? Because you generally can't call                                                         // 796
// `Meteor.defer` inside a method stub (see                                                                           // 797
// packages/meteor/timers.js).  This test verifies that rendered                                                      // 798
// callbacks don't fire synchronously as part of a method stub.                                                       // 799
testAsyncMulti('spacebars-tests - template_tests - defer in rendered callbacks', [function (test, expect) {           // 800
  var tmpl = Template.spacebars_template_test_defer_in_rendered;                                                      // 801
  var coll = new Meteor.Collection(null);                                                                             // 802
                                                                                                                      // 803
  Meteor.methods({                                                                                                    // 804
    spacebarsTestInsertEmptyObject: function () {                                                                     // 805
      // cause a new instance of `subtmpl` to be placed in the                                                        // 806
      // DOM. verify that it's not fired directly within a method                                                     // 807
      // stub, in which `Meteor.defer` is not allowed.                                                                // 808
      coll.insert({});                                                                                                // 809
    }                                                                                                                 // 810
  });                                                                                                                 // 811
                                                                                                                      // 812
  tmpl.items = function () {                                                                                          // 813
    return coll.find();                                                                                               // 814
  };                                                                                                                  // 815
                                                                                                                      // 816
  var subtmpl = Template.spacebars_template_test_defer_in_rendered_subtemplate;                                       // 817
                                                                                                                      // 818
  subtmpl.rendered = expect(function () {                                                                             // 819
    // will throw if called in a method stub                                                                          // 820
    Meteor.defer(function () {});                                                                                     // 821
  });                                                                                                                 // 822
                                                                                                                      // 823
  var div = renderToDiv(tmpl);                                                                                        // 824
                                                                                                                      // 825
  // not defined on the server, but it's fine since the stub does                                                     // 826
  // the relevant work                                                                                                // 827
  Meteor._suppress_log(1);                                                                                            // 828
  Meteor.call("spacebarsTestInsertEmptyObject");                                                                      // 829
}]);                                                                                                                  // 830
                                                                                                                      // 831
testAsyncMulti('spacebars-tests - template_tests - rendered template is DOM in rendered callbacks', [                 // 832
  function (test, expect) {                                                                                           // 833
    var tmpl = Template.spacebars_template_test_aaa;                                                                  // 834
    tmpl.rendered = expect(function () {                                                                              // 835
      test.equal(canonicalizeHtml(div.innerHTML), "aaa");                                                             // 836
    });                                                                                                               // 837
    var div = renderToDiv(tmpl);                                                                                      // 838
    Deps.flush();                                                                                                     // 839
  }                                                                                                                   // 840
]);                                                                                                                   // 841
                                                                                                                      // 842
// Test that in:                                                                                                      // 843
//                                                                                                                    // 844
// ```                                                                                                                // 845
// {{#with someData}}                                                                                                 // 846
//   {{foo}} {{bar}}                                                                                                  // 847
// {{/with}}                                                                                                          // 848
// ```                                                                                                                // 849
//                                                                                                                    // 850
// ... we run `someData` once even if `foo` re-renders.                                                               // 851
Tinytest.add('spacebars-tests - template_tests - with someData', function (test) {                                    // 852
  var tmpl = Template.spacebars_template_test_with_someData;                                                          // 853
                                                                                                                      // 854
  var foo = ReactiveVar('AAA');                                                                                       // 855
  var someDataRuns = 0;                                                                                               // 856
                                                                                                                      // 857
  tmpl.someData = function () {                                                                                       // 858
    someDataRuns++;                                                                                                   // 859
    return {};                                                                                                        // 860
  };                                                                                                                  // 861
  tmpl.foo = function () {                                                                                            // 862
    return foo.get();                                                                                                 // 863
  };                                                                                                                  // 864
  tmpl.bar = function () {                                                                                            // 865
    return 'YO';                                                                                                      // 866
  };                                                                                                                  // 867
                                                                                                                      // 868
  var div = renderToDiv(tmpl);                                                                                        // 869
                                                                                                                      // 870
  test.equal(someDataRuns, 1);                                                                                        // 871
  test.equal(canonicalizeHtml(div.innerHTML), 'AAA YO');                                                              // 872
                                                                                                                      // 873
  foo.set('BBB');                                                                                                     // 874
  Deps.flush();                                                                                                       // 875
  test.equal(someDataRuns, 1);                                                                                        // 876
  test.equal(canonicalizeHtml(div.innerHTML), 'BBB YO');                                                              // 877
                                                                                                                      // 878
  foo.set('CCC');                                                                                                     // 879
  Deps.flush();                                                                                                       // 880
  test.equal(someDataRuns, 1);                                                                                        // 881
  test.equal(canonicalizeHtml(div.innerHTML), 'CCC YO');                                                              // 882
});                                                                                                                   // 883
                                                                                                                      // 884
Tinytest.add('spacebars-tests - template_tests - #each stops when rendered element is removed', function (test) {     // 885
  var tmpl = Template.spacebars_template_test_each_stops;                                                             // 886
  var coll = new Meteor.Collection(null);                                                                             // 887
  coll.insert({});                                                                                                    // 888
  tmpl.items = function () { return coll.find(); };                                                                   // 889
                                                                                                                      // 890
  var div = renderToDiv(tmpl);                                                                                        // 891
  divRendersTo(test, div, 'x');                                                                                       // 892
                                                                                                                      // 893
  // trigger #each component destroyed                                                                                // 894
  $(div).remove();                                                                                                    // 895
                                                                                                                      // 896
  // insert another document. cursor should no longer be observed so                                                  // 897
  // should have no effect.                                                                                           // 898
  coll.insert({});                                                                                                    // 899
  divRendersTo(test, div, 'x');                                                                                       // 900
});                                                                                                                   // 901
                                                                                                                      // 902
Tinytest.add('spacebars-tests - template_tests - block helpers in attribute', function (test) {                       // 903
  var tmpl = Template.spacebars_template_test_block_helpers_in_attribute;                                             // 904
                                                                                                                      // 905
  var coll = new Meteor.Collection(null);                                                                             // 906
  tmpl.classes = function () {                                                                                        // 907
    return coll.find({}, {sort: {name: 1}});                                                                          // 908
  };                                                                                                                  // 909
  tmpl.startsLowerCase = function (name) {                                                                            // 910
    return /^[a-z]/.test(name);                                                                                       // 911
  };                                                                                                                  // 912
  coll.insert({name: 'David'});                                                                                       // 913
  coll.insert({name: 'noodle'});                                                                                      // 914
  coll.insert({name: 'donut'});                                                                                       // 915
  coll.insert({name: 'frankfurter'});                                                                                 // 916
  coll.insert({name: 'Steve'});                                                                                       // 917
                                                                                                                      // 918
  var containerDiv = renderToDiv(tmpl);                                                                               // 919
  var div = containerDiv.querySelector('div');                                                                        // 920
                                                                                                                      // 921
  var shouldBe = function (className) {                                                                               // 922
    Deps.flush();                                                                                                     // 923
    test.equal(div.innerHTML, "Smurf");                                                                               // 924
    test.equal(div.className, className);                                                                             // 925
    var result = canonicalizeHtml(containerDiv.innerHTML);                                                            // 926
    if (result === '<div>Smurf</div>')                                                                                // 927
      result = '<div class="">Smurf</div>'; // e.g. IE 9 and 10                                                       // 928
    test.equal(result, '<div class="' + className + '">Smurf</div>');                                                 // 929
  };                                                                                                                  // 930
                                                                                                                      // 931
  shouldBe('donut frankfurter noodle');                                                                               // 932
  coll.remove({name: 'frankfurter'}); // (it was kind of a mouthful)                                                  // 933
  shouldBe('donut noodle');                                                                                           // 934
  coll.remove({name: 'donut'});                                                                                       // 935
  shouldBe('noodle');                                                                                                 // 936
  coll.remove({name: 'noodle'});                                                                                      // 937
  shouldBe(''); // 'David' and 'Steve' appear in the #each but fail the #if                                           // 938
  coll.remove({});                                                                                                    // 939
  shouldBe('none'); // now the `{{else}}` case kicks in                                                               // 940
  coll.insert({name: 'bubblegum'});                                                                                   // 941
  shouldBe('bubblegum');                                                                                              // 942
});                                                                                                                   // 943
                                                                                                                      // 944
Tinytest.add('spacebars-tests - template_tests - block helpers in attribute 2', function (test) {                     // 945
  var tmpl = Template.spacebars_template_test_block_helpers_in_attribute_2;                                           // 946
                                                                                                                      // 947
  var R = ReactiveVar(true);                                                                                          // 948
                                                                                                                      // 949
  tmpl.foo = function () { return R.get(); };                                                                         // 950
                                                                                                                      // 951
  var div = renderToDiv(tmpl);                                                                                        // 952
  var input = div.querySelector('input');                                                                             // 953
                                                                                                                      // 954
  test.equal(input.value, '"');                                                                                       // 955
  R.set(false);                                                                                                       // 956
  Deps.flush();                                                                                                       // 957
  test.equal(input.value, '&<></x>');                                                                                 // 958
});                                                                                                                   // 959
                                                                                                                      // 960
                                                                                                                      // 961
// Test that if the argument to #each is a constant, it doesn't establish a                                           // 962
// dependency on the data context, so when the context changes, items of                                              // 963
// the #each are not "changed" and helpers do not rerun.                                                              // 964
Tinytest.add('spacebars-tests - template_tests - constant #each argument', function (test) {                          // 965
  var tmpl = Template.spacebars_template_test_constant_each_argument;                                                 // 966
                                                                                                                      // 967
  var justReturnRuns = 0; // how many times `justReturn` is called                                                    // 968
  var R = ReactiveVar(1);                                                                                             // 969
                                                                                                                      // 970
  tmpl.someData = function () {                                                                                       // 971
    return R.get();                                                                                                   // 972
  };                                                                                                                  // 973
  tmpl.anArray = ['foo', 'bar'];                                                                                      // 974
  tmpl.justReturn = function (x) {                                                                                    // 975
    justReturnRuns++;                                                                                                 // 976
    return String(x);                                                                                                 // 977
  };                                                                                                                  // 978
                                                                                                                      // 979
  var div = renderToDiv(tmpl);                                                                                        // 980
                                                                                                                      // 981
  test.equal(justReturnRuns, 2);                                                                                      // 982
  test.equal(canonicalizeHtml(div.innerHTML).replace(/\s+/g, ' '),                                                    // 983
             'foo bar 1');                                                                                            // 984
                                                                                                                      // 985
  R.set(2);                                                                                                           // 986
  Deps.flush();                                                                                                       // 987
                                                                                                                      // 988
  test.equal(justReturnRuns, 2); // still 2, no new runs!                                                             // 989
  test.equal(canonicalizeHtml(div.innerHTML).replace(/\s+/g, ' '),                                                    // 990
             'foo bar 2');                                                                                            // 991
});                                                                                                                   // 992
                                                                                                                      // 993
Tinytest.addAsync('spacebars-tests - template_tests - #markdown - basic', function (test, onComplete) {               // 994
  var tmpl = Template.spacebars_template_test_markdown_basic;                                                         // 995
  tmpl.obj = {snippet: "<i>hi</i>"};                                                                                  // 996
  tmpl.hi = function () {                                                                                             // 997
    return this.snippet;                                                                                              // 998
  };                                                                                                                  // 999
  var div = renderToDiv(tmpl);                                                                                        // 1000
                                                                                                                      // 1001
  Meteor.call("getAsset", "markdown_basic.html", function (err, html) {                                               // 1002
    test.isFalse(err);                                                                                                // 1003
    test.equal(canonicalizeHtml(div.innerHTML),                                                                       // 1004
               canonicalizeHtml(html));                                                                               // 1005
    onComplete();                                                                                                     // 1006
  });                                                                                                                 // 1007
});                                                                                                                   // 1008
                                                                                                                      // 1009
testAsyncMulti('spacebars-tests - template_tests - #markdown - if', [                                                 // 1010
  function (test, expect) {                                                                                           // 1011
    var self = this;                                                                                                  // 1012
    Meteor.call("getAsset", "markdown_if1.html", expect(function (err, html) {                                        // 1013
      test.isFalse(err);                                                                                              // 1014
      self.html1 = html;                                                                                              // 1015
    }));                                                                                                              // 1016
    Meteor.call("getAsset", "markdown_if2.html", expect(function (err, html) {                                        // 1017
      test.isFalse(err);                                                                                              // 1018
      self.html2 = html;                                                                                              // 1019
    }));                                                                                                              // 1020
  },                                                                                                                  // 1021
                                                                                                                      // 1022
  function (test, expect) {                                                                                           // 1023
    var self = this;                                                                                                  // 1024
    var tmpl = Template.spacebars_template_test_markdown_if;                                                          // 1025
    var R = new ReactiveVar(false);                                                                                   // 1026
    tmpl.cond = function () { return R.get(); };                                                                      // 1027
                                                                                                                      // 1028
    var div = renderToDiv(tmpl);                                                                                      // 1029
    test.equal(canonicalizeHtml(div.innerHTML), canonicalizeHtml(self.html1));                                        // 1030
    R.set(true);                                                                                                      // 1031
    Deps.flush();                                                                                                     // 1032
    test.equal(canonicalizeHtml(div.innerHTML), canonicalizeHtml(self.html2));                                        // 1033
  }                                                                                                                   // 1034
]);                                                                                                                   // 1035
                                                                                                                      // 1036
testAsyncMulti('spacebars-tests - template_tests - #markdown - each', [                                               // 1037
  function (test, expect) {                                                                                           // 1038
    var self = this;                                                                                                  // 1039
    Meteor.call("getAsset", "markdown_each1.html", expect(function (err, html) {                                      // 1040
      test.isFalse(err);                                                                                              // 1041
      self.html1 = html;                                                                                              // 1042
    }));                                                                                                              // 1043
    Meteor.call("getAsset", "markdown_each2.html", expect(function (err, html) {                                      // 1044
      test.isFalse(err);                                                                                              // 1045
      self.html2 = html;                                                                                              // 1046
    }));                                                                                                              // 1047
  },                                                                                                                  // 1048
                                                                                                                      // 1049
  function (test, expect) {                                                                                           // 1050
    var self = this;                                                                                                  // 1051
    var tmpl = Template.spacebars_template_test_markdown_each;                                                        // 1052
    var R = new ReactiveVar([]);                                                                                      // 1053
    tmpl.seq = function () { return R.get(); };                                                                       // 1054
                                                                                                                      // 1055
    var div = renderToDiv(tmpl);                                                                                      // 1056
    test.equal(canonicalizeHtml(div.innerHTML), canonicalizeHtml(self.html1));                                        // 1057
                                                                                                                      // 1058
    R.set(["item"]);                                                                                                  // 1059
    Deps.flush();                                                                                                     // 1060
    test.equal(canonicalizeHtml(div.innerHTML), canonicalizeHtml(self.html2));                                        // 1061
  }                                                                                                                   // 1062
]);                                                                                                                   // 1063
                                                                                                                      // 1064
Tinytest.add('spacebars-tests - template_tests - #markdown - inclusion', function (test) {                            // 1065
  var tmpl = Template.spacebars_template_test_markdown_inclusion;                                                     // 1066
  var subtmpl = Template.spacebars_template_test_markdown_inclusion_subtmpl;                                          // 1067
  subtmpl.foo = "bar";                                                                                                // 1068
  var div = renderToDiv(tmpl);                                                                                        // 1069
  test.equal(canonicalizeHtml(div.innerHTML), "<p><span>Foo is bar.</span></p>");                                     // 1070
});                                                                                                                   // 1071
                                                                                                                      // 1072
Tinytest.add('spacebars-tests - template_tests - #markdown - block helpers', function (test) {                        // 1073
  var tmpl = Template.spacebars_template_test_markdown_block_helpers;                                                 // 1074
  var div = renderToDiv(tmpl);                                                                                        // 1075
  test.equal(canonicalizeHtml(div.innerHTML), "<p>Hi there!</p>");                                                    // 1076
});                                                                                                                   // 1077
                                                                                                                      // 1078
// Test that when a simple helper re-runs due to a dependency changing                                                // 1079
// but the return value is the same, the DOM text node is not                                                         // 1080
// re-rendered.                                                                                                       // 1081
Tinytest.add('spacebars-tests - template_tests - simple helpers are isolated', function (test) {                      // 1082
  var runs = [{                                                                                                       // 1083
    helper: function () { return "foo"; },                                                                            // 1084
    nodeValue: "foo"                                                                                                  // 1085
  }, {                                                                                                                // 1086
    helper: function () { return new Spacebars.SafeString("bar"); },                                                  // 1087
    nodeValue: "bar"                                                                                                  // 1088
  }];                                                                                                                 // 1089
                                                                                                                      // 1090
  _.each(runs, function (run) {                                                                                       // 1091
    var tmpl = Template.spacebars_template_test_simple_helpers_are_isolated;                                          // 1092
    var dep = new Deps.Dependency;                                                                                    // 1093
    tmpl.foo = function () {                                                                                          // 1094
      dep.depend();                                                                                                   // 1095
      return run.helper();                                                                                            // 1096
    };                                                                                                                // 1097
    var div = renderToDiv(tmpl);                                                                                      // 1098
    var fooTextNode = _.find(div.childNodes, function (node) {                                                        // 1099
      return node.nodeValue === run.nodeValue;                                                                        // 1100
    });                                                                                                               // 1101
                                                                                                                      // 1102
    test.isTrue(fooTextNode);                                                                                         // 1103
                                                                                                                      // 1104
    dep.changed();                                                                                                    // 1105
    Deps.flush();                                                                                                     // 1106
    var newFooTextNode = _.find(div.childNodes, function (node) {                                                     // 1107
      return node.nodeValue === run.nodeValue;                                                                        // 1108
    });                                                                                                               // 1109
                                                                                                                      // 1110
    test.equal(fooTextNode, newFooTextNode);                                                                          // 1111
  });                                                                                                                 // 1112
});                                                                                                                   // 1113
                                                                                                                      // 1114
// Test that when a helper in an element attribute re-runs due to a                                                   // 1115
// dependency changing but the return value is the same, the attribute                                                // 1116
// value is not set.                                                                                                  // 1117
Tinytest.add('spacebars-tests - template_tests - attribute helpers are isolated', function (test) {                   // 1118
  var tmpl = Template.spacebars_template_test_attr_helpers_are_isolated;                                              // 1119
  var dep = new Deps.Dependency;                                                                                      // 1120
  tmpl.foo = function () {                                                                                            // 1121
    dep.depend();                                                                                                     // 1122
    return "foo";                                                                                                     // 1123
  };                                                                                                                  // 1124
  var div = renderToDiv(tmpl);                                                                                        // 1125
  var pElement = div.querySelector('p');                                                                              // 1126
                                                                                                                      // 1127
  test.equal(pElement.getAttribute('attr'), 'foo');                                                                   // 1128
                                                                                                                      // 1129
  // set the attribute to something else, afterwards check that it                                                    // 1130
  // hasn't been updated back to the correct value.                                                                   // 1131
  pElement.setAttribute('attr', 'not-foo');                                                                           // 1132
  dep.changed();                                                                                                      // 1133
  Deps.flush();                                                                                                       // 1134
  test.equal(pElement.getAttribute('attr'), 'not-foo');                                                               // 1135
});                                                                                                                   // 1136
                                                                                                                      // 1137
// A helper can return an object with a set of element attributes via                                                 // 1138
// `<p {{attrs}}>`. When it re-runs due to a dependency changing the                                                  // 1139
// value for a given attribute might stay the same. Test that the                                                     // 1140
// attribute is not set on the DOM element.                                                                           // 1141
Tinytest.add('spacebars-tests - template_tests - attribute object helpers are isolated', function (test) {            // 1142
  var tmpl = Template.spacebars_template_test_attr_object_helpers_are_isolated;                                       // 1143
  var dep = new Deps.Dependency;                                                                                      // 1144
  tmpl.attrs = function () {                                                                                          // 1145
    dep.depend();                                                                                                     // 1146
    return {foo: "bar"};                                                                                              // 1147
  };                                                                                                                  // 1148
  var div = renderToDiv(tmpl);                                                                                        // 1149
  var pElement = div.querySelector('p');                                                                              // 1150
                                                                                                                      // 1151
  test.equal(pElement.getAttribute('foo'), 'bar');                                                                    // 1152
                                                                                                                      // 1153
  // set the attribute to something else, afterwards check that it                                                    // 1154
  // hasn't been updated back to the correct value.                                                                   // 1155
  pElement.setAttribute('foo', 'not-bar');                                                                            // 1156
  dep.changed();                                                                                                      // 1157
  Deps.flush();                                                                                                       // 1158
  test.equal(pElement.getAttribute('foo'), 'not-bar');                                                                // 1159
});                                                                                                                   // 1160
                                                                                                                      // 1161
// Test that when a helper in an inclusion directive (`{{> foo }}`)                                                   // 1162
// re-runs due to a dependency changing but the return value is the                                                   // 1163
// same, the template is not re-rendered.                                                                             // 1164
//                                                                                                                    // 1165
// Also, verify that an error is thrown if the return value from such                                                 // 1166
// a helper is not a component.                                                                                       // 1167
Tinytest.add('spacebars-tests - template_tests - inclusion helpers are isolated', function (test) {                   // 1168
  var tmpl = Template.spacebars_template_test_inclusion_helpers_are_isolated;                                         // 1169
  var dep = new Deps.Dependency;                                                                                      // 1170
  var subtmpl = Template.spacebars_template_test_inclusion_helpers_are_isolated_subtemplate;                          // 1171
  // make a copy so we can set "rendered" without mutating the original                                               // 1172
  var subtmplCopy = Template.__create__(                                                                              // 1173
    subtmpl.__viewName,                                                                                               // 1174
    subtmpl.__render);                                                                                                // 1175
  var R = new ReactiveVar(subtmplCopy);                                                                               // 1176
  tmpl.foo = function () {                                                                                            // 1177
    dep.depend();                                                                                                     // 1178
    return R.get();                                                                                                   // 1179
  };                                                                                                                  // 1180
                                                                                                                      // 1181
  var div = renderToDiv(tmpl);                                                                                        // 1182
    subtmplCopy.rendered = function () {                                                                              // 1183
    test.fail("shouldn't re-render when same value returned from helper");                                            // 1184
  };                                                                                                                  // 1185
                                                                                                                      // 1186
  dep.changed();                                                                                                      // 1187
  Deps.flush({_throwFirstError: true}); // `subtmplCopy.rendered` not called                                          // 1188
                                                                                                                      // 1189
  R.set(null);                                                                                                        // 1190
  Deps.flush({_throwFirstError: true}); // no error thrown                                                            // 1191
                                                                                                                      // 1192
  R.set("neither a component nor null");                                                                              // 1193
                                                                                                                      // 1194
  test.throws(function () {                                                                                           // 1195
    Deps.flush({_throwFirstError: true});                                                                             // 1196
  }, /Expected template or null/);                                                                                    // 1197
});                                                                                                                   // 1198
                                                                                                                      // 1199
Tinytest.add('spacebars-tests - template_tests - nully attributes', function (test) {                                 // 1200
  var tmpls = {                                                                                                       // 1201
    0: Template.spacebars_template_test_nully_attributes0,                                                            // 1202
    1: Template.spacebars_template_test_nully_attributes1,                                                            // 1203
    2: Template.spacebars_template_test_nully_attributes2,                                                            // 1204
    3: Template.spacebars_template_test_nully_attributes3,                                                            // 1205
    4: Template.spacebars_template_test_nully_attributes4,                                                            // 1206
    5: Template.spacebars_template_test_nully_attributes5,                                                            // 1207
    6: Template.spacebars_template_test_nully_attributes6                                                             // 1208
  };                                                                                                                  // 1209
                                                                                                                      // 1210
  var run = function (whichTemplate, data, expectTrue) {                                                              // 1211
    var div = renderToDiv(tmpls[whichTemplate], data);                                                                // 1212
    var input = div.querySelector('input');                                                                           // 1213
    var descr = JSON.stringify([whichTemplate, data, expectTrue]);                                                    // 1214
    if (expectTrue) {                                                                                                 // 1215
      test.isTrue(input.checked, descr);                                                                              // 1216
      test.equal(typeof input.getAttribute('stuff'), 'string', descr);                                                // 1217
    } else {                                                                                                          // 1218
      test.isFalse(input.checked);                                                                                    // 1219
      test.equal(JSON.stringify(input.getAttribute('stuff')), 'null', descr);                                         // 1220
    }                                                                                                                 // 1221
                                                                                                                      // 1222
    var html = Blaze.toHTML(Blaze.With(data, function () {                                                            // 1223
      return tmpls[whichTemplate];                                                                                    // 1224
    }));                                                                                                              // 1225
                                                                                                                      // 1226
    test.equal(/ checked="[^"]*"/.test(html), !! expectTrue);                                                         // 1227
    test.equal(/ stuff="[^"]*"/.test(html), !! expectTrue);                                                           // 1228
  };                                                                                                                  // 1229
                                                                                                                      // 1230
  run(0, {}, true);                                                                                                   // 1231
                                                                                                                      // 1232
  var truthies = [true, ''];                                                                                          // 1233
  var falsies = [false, null, undefined];                                                                             // 1234
                                                                                                                      // 1235
  _.each(truthies, function (x) {                                                                                     // 1236
    run(1, {foo: x}, true);                                                                                           // 1237
  });                                                                                                                 // 1238
  _.each(falsies, function (x) {                                                                                      // 1239
    run(1, {foo: x}, false);                                                                                          // 1240
  });                                                                                                                 // 1241
                                                                                                                      // 1242
  _.each(truthies, function (x) {                                                                                     // 1243
    _.each(truthies, function (y) {                                                                                   // 1244
      run(2, {foo: x, bar: y}, true);                                                                                 // 1245
    });                                                                                                               // 1246
    _.each(falsies, function (y) {                                                                                    // 1247
      run(2, {foo: x, bar: y}, true);                                                                                 // 1248
    });                                                                                                               // 1249
  });                                                                                                                 // 1250
  _.each(falsies, function (x) {                                                                                      // 1251
    _.each(truthies, function (y) {                                                                                   // 1252
      run(2, {foo: x, bar: y}, true);                                                                                 // 1253
    });                                                                                                               // 1254
    _.each(falsies, function (y) {                                                                                    // 1255
      run(2, {foo: x, bar: y}, false);                                                                                // 1256
    });                                                                                                               // 1257
  });                                                                                                                 // 1258
                                                                                                                      // 1259
  run(3, {foo: true}, false);                                                                                         // 1260
  run(3, {foo: false}, false);                                                                                        // 1261
});                                                                                                                   // 1262
                                                                                                                      // 1263
Tinytest.add("spacebars-tests - template_tests - double", function (test) {                                           // 1264
  var tmpl = Template.spacebars_template_test_double;                                                                 // 1265
                                                                                                                      // 1266
  var run = function (foo, expectedResult) {                                                                          // 1267
    tmpl.foo = foo;                                                                                                   // 1268
    var div = renderToDiv(tmpl);                                                                                      // 1269
    test.equal(canonicalizeHtml(div.innerHTML), expectedResult);                                                      // 1270
  };                                                                                                                  // 1271
                                                                                                                      // 1272
  run('asdf', 'asdf');                                                                                                // 1273
  run(1.23, '1.23');                                                                                                  // 1274
  run(0, '0');                                                                                                        // 1275
  run(true, 'true');                                                                                                  // 1276
  run(false, '');                                                                                                     // 1277
  run(null, '');                                                                                                      // 1278
  run(undefined, '');                                                                                                 // 1279
});                                                                                                                   // 1280
                                                                                                                      // 1281
Tinytest.add("spacebars-tests - template_tests - inclusion lookup order", function (test) {                           // 1282
  // test that {{> foo}} looks for a helper named 'foo', then a                                                       // 1283
  // template named 'foo', then a 'foo' field in the data context.                                                    // 1284
  var tmpl = Template.spacebars_template_test_inclusion_lookup;                                                       // 1285
  var tmplData = function () {                                                                                        // 1286
    return {                                                                                                          // 1287
      // shouldn't have an effect since we define a helper with the                                                   // 1288
      // same name.                                                                                                   // 1289
      spacebars_template_test_inclusion_lookup_subtmpl: Template.                                                     // 1290
        spacebars_template_test_inclusion_lookup_subtmpl3,                                                            // 1291
      dataContextSubtmpl: Template.                                                                                   // 1292
        spacebars_template_test_inclusion_lookup_subtmpl3};                                                           // 1293
  };                                                                                                                  // 1294
                                                                                                                      // 1295
  tmpl.spacebars_template_test_inclusion_lookup_subtmpl =                                                             // 1296
    Template.spacebars_template_test_inclusion_lookup_subtmpl2;                                                       // 1297
                                                                                                                      // 1298
  test.equal(canonicalizeHtml(renderToDiv(tmpl, tmplData).innerHTML),                                                 // 1299
    ["This is generated by a helper with the same name.",                                                             // 1300
     "This is a template passed in the data context."].join(' '));                                                    // 1301
});                                                                                                                   // 1302
                                                                                                                      // 1303
Tinytest.add("spacebars-tests - template_tests - content context", function (test) {                                  // 1304
  var tmpl = Template.spacebars_template_test_content_context;                                                        // 1305
  var R = ReactiveVar(true);                                                                                          // 1306
  tmpl.foo = {                                                                                                        // 1307
    firstLetter: 'F',                                                                                                 // 1308
    secondLetter: 'O',                                                                                                // 1309
    bar: {                                                                                                            // 1310
      cond: function () { return R.get(); },                                                                          // 1311
      firstLetter: 'B',                                                                                               // 1312
      secondLetter: 'A'                                                                                               // 1313
    }                                                                                                                 // 1314
  };                                                                                                                  // 1315
                                                                                                                      // 1316
  var div = renderToDiv(tmpl);                                                                                        // 1317
  test.equal(canonicalizeHtml(div.innerHTML), 'BO');                                                                  // 1318
  R.set(false);                                                                                                       // 1319
  Deps.flush();                                                                                                       // 1320
  test.equal(canonicalizeHtml(div.innerHTML), 'FA');                                                                  // 1321
});                                                                                                                   // 1322
                                                                                                                      // 1323
_.each(['textarea', 'text', 'password', 'submit', 'button',                                                           // 1324
        'reset', 'select', 'hidden'], function (type) {                                                               // 1325
  Tinytest.add("spacebars-tests - template_tests - controls - " + type, function(test) {                              // 1326
    var R = ReactiveVar({x:"test"});                                                                                  // 1327
    var R2 = ReactiveVar("");                                                                                         // 1328
    var tmpl;                                                                                                         // 1329
                                                                                                                      // 1330
    if (type === 'select') {                                                                                          // 1331
      tmpl = Template.spacebars_test_control_select;                                                                  // 1332
      tmpl.options = ['This is a test', 'This is a fridge',                                                           // 1333
                      'This is a frog', 'This is a new frog', 'foobar',                                               // 1334
                      'This is a photograph', 'This is a monkey',                                                     // 1335
                      'This is a donkey'];                                                                            // 1336
      tmpl.selected = function () {                                                                                   // 1337
        R2.get();  // Re-render when R2 is changed, even though it                                                    // 1338
                   // doesn't affect HTML.                                                                            // 1339
        return ('This is a ' + R.get().x) === this.toString();                                                        // 1340
      };                                                                                                              // 1341
    } else if (type === 'textarea') {                                                                                 // 1342
      tmpl = Template.spacebars_test_control_textarea;                                                                // 1343
      tmpl.value = function () {                                                                                      // 1344
        R2.get();  // Re-render when R2 is changed, even though it                                                    // 1345
                   // doesn't affect HTML.                                                                            // 1346
        return 'This is a ' + R.get().x;                                                                              // 1347
      };                                                                                                              // 1348
    } else {                                                                                                          // 1349
      tmpl = Template.spacebars_test_control_input;                                                                   // 1350
      tmpl.value = function () {                                                                                      // 1351
        R2.get();  // Re-render when R2 is changed, even though it                                                    // 1352
                   // doesn't affect HTML.                                                                            // 1353
        return 'This is a ' + R.get().x;                                                                              // 1354
      };                                                                                                              // 1355
      tmpl.type = type;                                                                                               // 1356
    };                                                                                                                // 1357
                                                                                                                      // 1358
    var div = renderToDiv(tmpl);                                                                                      // 1359
    document.body.appendChild(div);                                                                                   // 1360
    var canFocus = (type !== 'hidden');                                                                               // 1361
                                                                                                                      // 1362
    // find first element child, ignoring any marker nodes                                                            // 1363
    var input = div.firstChild;                                                                                       // 1364
    while (input.nodeType !== 1)                                                                                      // 1365
      input = input.nextSibling;                                                                                      // 1366
                                                                                                                      // 1367
    if (type === 'textarea' || type === 'select') {                                                                   // 1368
      test.equal(input.nodeName, type.toUpperCase());                                                                 // 1369
    } else {                                                                                                          // 1370
      test.equal(input.nodeName, 'INPUT');                                                                            // 1371
      test.equal(input.type, type);                                                                                   // 1372
    }                                                                                                                 // 1373
    test.equal(DomUtils.getElementValue(input), "This is a test");                                                    // 1374
                                                                                                                      // 1375
    // value updates reactively                                                                                       // 1376
    R.set({x:"fridge"});                                                                                              // 1377
    Deps.flush();                                                                                                     // 1378
    test.equal(DomUtils.getElementValue(input), "This is a fridge");                                                  // 1379
                                                                                                                      // 1380
    if (canFocus) {                                                                                                   // 1381
      // ...if focused, it still updates but focus isn't lost.                                                        // 1382
      focusElement(input);                                                                                            // 1383
      DomUtils.setElementValue(input, "something else");                                                              // 1384
      R.set({x:"frog"});                                                                                              // 1385
                                                                                                                      // 1386
      Deps.flush();                                                                                                   // 1387
      test.equal(DomUtils.getElementValue(input), "This is a frog");                                                  // 1388
      test.equal(document.activeElement, input);                                                                      // 1389
    }                                                                                                                 // 1390
                                                                                                                      // 1391
    // Setting a value (similar to user typing) should prevent value from being                                       // 1392
    // reverted if the div is re-rendered but the rendered value (ie, R) does                                         // 1393
    // not change.                                                                                                    // 1394
    DomUtils.setElementValue(input, "foobar");                                                                        // 1395
    R2.set("change");                                                                                                 // 1396
    Deps.flush();                                                                                                     // 1397
    test.equal(DomUtils.getElementValue(input), "foobar");                                                            // 1398
                                                                                                                      // 1399
    // ... but if the actual rendered value changes, that should take effect.                                         // 1400
    R.set({x:"photograph"});                                                                                          // 1401
    Deps.flush();                                                                                                     // 1402
    test.equal(DomUtils.getElementValue(input), "This is a photograph");                                              // 1403
                                                                                                                      // 1404
    document.body.removeChild(div);                                                                                   // 1405
  });                                                                                                                 // 1406
});                                                                                                                   // 1407
                                                                                                                      // 1408
Tinytest.add("spacebars-tests - template_tests - radio", function(test) {                                             // 1409
  var R = ReactiveVar("");                                                                                            // 1410
  var R2 = ReactiveVar("");                                                                                           // 1411
  var change_buf = [];                                                                                                // 1412
  var tmpl = Template.spacebars_test_control_radio;                                                                   // 1413
  tmpl.bands = ["AM", "FM", "XM"];                                                                                    // 1414
  tmpl.isChecked = function () {                                                                                      // 1415
    return R.get() === this.toString();                                                                               // 1416
  };                                                                                                                  // 1417
  tmpl.band = function () {                                                                                           // 1418
    return R.get();                                                                                                   // 1419
  };                                                                                                                  // 1420
  tmpl.events({                                                                                                       // 1421
    'change input': function (event) {                                                                                // 1422
      var btn = event.target;                                                                                         // 1423
      var band = btn.value;                                                                                           // 1424
      change_buf.push(band);                                                                                          // 1425
      R.set(band);                                                                                                    // 1426
    }                                                                                                                 // 1427
  });                                                                                                                 // 1428
                                                                                                                      // 1429
  var div = renderToDiv(tmpl);                                                                                        // 1430
  document.body.appendChild(div);                                                                                     // 1431
                                                                                                                      // 1432
  // get the three buttons; they should not change identities!                                                        // 1433
  var btns = nodesToArray(div.getElementsByTagName("INPUT"));                                                         // 1434
  var text = function () {                                                                                            // 1435
    var text = div.innerText || div.textContent;                                                                      // 1436
    return text.replace(/[ \n\r]+/g, " ");                                                                            // 1437
  };                                                                                                                  // 1438
                                                                                                                      // 1439
  test.equal(_.pluck(btns, 'checked'), [false, false, false]);                                                        // 1440
  test.equal(text(), "Band: ");                                                                                       // 1441
                                                                                                                      // 1442
  clickIt(btns[0]);                                                                                                   // 1443
  test.equal(change_buf, ['AM']);                                                                                     // 1444
  change_buf.length = 0;                                                                                              // 1445
  Deps.flush();                                                                                                       // 1446
  test.equal(_.pluck(btns, 'checked'), [true, false, false]);                                                         // 1447
  test.equal(text(), "Band: AM");                                                                                     // 1448
                                                                                                                      // 1449
  R2.set("change");                                                                                                   // 1450
  Deps.flush();                                                                                                       // 1451
  test.length(change_buf, 0);                                                                                         // 1452
  test.equal(_.pluck(btns, 'checked'), [true, false, false]);                                                         // 1453
  test.equal(text(), "Band: AM");                                                                                     // 1454
                                                                                                                      // 1455
  clickIt(btns[1]);                                                                                                   // 1456
  test.equal(change_buf, ['FM']);                                                                                     // 1457
  change_buf.length = 0;                                                                                              // 1458
  Deps.flush();                                                                                                       // 1459
  test.equal(_.pluck(btns, 'checked'), [false, true, false]);                                                         // 1460
  test.equal(text(), "Band: FM");                                                                                     // 1461
                                                                                                                      // 1462
  clickIt(btns[2]);                                                                                                   // 1463
  test.equal(change_buf, ['XM']);                                                                                     // 1464
  change_buf.length = 0;                                                                                              // 1465
  Deps.flush();                                                                                                       // 1466
  test.equal(_.pluck(btns, 'checked'), [false, false, true]);                                                         // 1467
  test.equal(text(), "Band: XM");                                                                                     // 1468
                                                                                                                      // 1469
  clickIt(btns[1]);                                                                                                   // 1470
  test.equal(change_buf, ['FM']);                                                                                     // 1471
  change_buf.length = 0;                                                                                              // 1472
  Deps.flush();                                                                                                       // 1473
  test.equal(_.pluck(btns, 'checked'), [false, true, false]);                                                         // 1474
  test.equal(text(), "Band: FM");                                                                                     // 1475
                                                                                                                      // 1476
  document.body.removeChild(div);                                                                                     // 1477
});                                                                                                                   // 1478
                                                                                                                      // 1479
Tinytest.add("spacebars-tests - template_tests - checkbox", function(test) {                                          // 1480
  var tmpl = Template.spacebars_test_control_checkbox;                                                                // 1481
  tmpl.labels = ["Foo", "Bar", "Baz"];                                                                                // 1482
  var Rs = {};                                                                                                        // 1483
  _.each(tmpl.labels, function (label) {                                                                              // 1484
    Rs[label] = ReactiveVar(false);                                                                                   // 1485
  });                                                                                                                 // 1486
  tmpl.isChecked = function () {                                                                                      // 1487
    return Rs[this.toString()].get();                                                                                 // 1488
  };                                                                                                                  // 1489
  var changeBuf = [];                                                                                                 // 1490
                                                                                                                      // 1491
  var div = renderToDiv(tmpl);                                                                                        // 1492
  document.body.appendChild(div);                                                                                     // 1493
                                                                                                                      // 1494
  var boxes = nodesToArray(div.getElementsByTagName("INPUT"));                                                        // 1495
                                                                                                                      // 1496
  test.equal(_.pluck(boxes, 'checked'), [false, false, false]);                                                       // 1497
                                                                                                                      // 1498
  // Re-render with first one checked.                                                                                // 1499
  Rs.Foo.set(true);                                                                                                   // 1500
  Deps.flush();                                                                                                       // 1501
  test.equal(_.pluck(boxes, 'checked'), [true, false, false]);                                                        // 1502
                                                                                                                      // 1503
  // Re-render with first one unchecked again.                                                                        // 1504
  Rs.Foo.set(false);                                                                                                  // 1505
  Deps.flush();                                                                                                       // 1506
  test.equal(_.pluck(boxes, 'checked'), [false, false, false]);                                                       // 1507
                                                                                                                      // 1508
  // User clicks the second one.                                                                                      // 1509
  clickElement(boxes[1]);                                                                                             // 1510
  test.equal(_.pluck(boxes, 'checked'), [false, true, false]);                                                        // 1511
  Deps.flush();                                                                                                       // 1512
  test.equal(_.pluck(boxes, 'checked'), [false, true, false]);                                                        // 1513
                                                                                                                      // 1514
  // Re-render with third one checked. Second one should stay checked because                                         // 1515
  // it's a user update!                                                                                              // 1516
  Rs.Baz.set(true);                                                                                                   // 1517
  Deps.flush();                                                                                                       // 1518
  test.equal(_.pluck(boxes, 'checked'), [false, true, true]);                                                         // 1519
                                                                                                                      // 1520
  // User turns second and third off.                                                                                 // 1521
  clickElement(boxes[1]);                                                                                             // 1522
  clickElement(boxes[2]);                                                                                             // 1523
  test.equal(_.pluck(boxes, 'checked'), [false, false, false]);                                                       // 1524
  Deps.flush();                                                                                                       // 1525
  test.equal(_.pluck(boxes, 'checked'), [false, false, false]);                                                       // 1526
                                                                                                                      // 1527
  // Re-render with first one checked. Third should stay off because it's a user                                      // 1528
  // update!                                                                                                          // 1529
  Rs.Foo.set(true);                                                                                                   // 1530
  Deps.flush();                                                                                                       // 1531
  test.equal(_.pluck(boxes, 'checked'), [true, false, false]);                                                        // 1532
                                                                                                                      // 1533
  // Re-render with first one unchecked. Third should still stay off.                                                 // 1534
  Rs.Foo.set(false);                                                                                                  // 1535
  Deps.flush();                                                                                                       // 1536
  test.equal(_.pluck(boxes, 'checked'), [false, false, false]);                                                       // 1537
                                                                                                                      // 1538
  document.body.removeChild(div);                                                                                     // 1539
});                                                                                                                   // 1540
                                                                                                                      // 1541
Tinytest.add('spacebars-tests - template_tests - unfound template', function (test) {                                 // 1542
  test.throws(function () {                                                                                           // 1543
    renderToDiv(Template.spacebars_test_nonexistent_template);                                                        // 1544
  }, /No such template/);                                                                                             // 1545
});                                                                                                                   // 1546
                                                                                                                      // 1547
Tinytest.add('spacebars-tests - template_tests - helper passed to #if called exactly once when invalidated', function (test) {
  var tmpl = Template.spacebars_test_if_helper;                                                                       // 1549
                                                                                                                      // 1550
  var count = 0;                                                                                                      // 1551
  var d = new Deps.Dependency;                                                                                        // 1552
  tmpl.foo = function () {                                                                                            // 1553
    d.depend();                                                                                                       // 1554
    count++;                                                                                                          // 1555
    return foo;                                                                                                       // 1556
  };                                                                                                                  // 1557
                                                                                                                      // 1558
  foo = false;                                                                                                        // 1559
  var div = renderToDiv(tmpl);                                                                                        // 1560
  divRendersTo(test, div, "false");                                                                                   // 1561
  test.equal(count, 1);                                                                                               // 1562
                                                                                                                      // 1563
  foo = true;                                                                                                         // 1564
  d.changed();                                                                                                        // 1565
  divRendersTo(test, div, "true");                                                                                    // 1566
  test.equal(count, 2);                                                                                               // 1567
});                                                                                                                   // 1568
                                                                                                                      // 1569
Tinytest.add('spacebars-tests - template_tests - custom block helper functions called exactly once when invalidated', function (test) {
  var tmpl = Template.spacebars_test_block_helper_function;                                                           // 1571
                                                                                                                      // 1572
  var count = 0;                                                                                                      // 1573
  var d = new Deps.Dependency;                                                                                        // 1574
  tmpl.foo = function () {                                                                                            // 1575
    d.depend();                                                                                                       // 1576
    count++;                                                                                                          // 1577
    return Template.spacebars_template_test_aaa;                                                                      // 1578
  };                                                                                                                  // 1579
                                                                                                                      // 1580
  foo = false;                                                                                                        // 1581
  renderToDiv(tmpl);                                                                                                  // 1582
  Deps.flush();                                                                                                       // 1583
  test.equal(count, 1);                                                                                               // 1584
                                                                                                                      // 1585
  foo = true;                                                                                                         // 1586
  d.changed();                                                                                                        // 1587
  Deps.flush();                                                                                                       // 1588
  test.equal(count, 2);                                                                                               // 1589
});                                                                                                                   // 1590
                                                                                                                      // 1591
var runOneTwoTest = function (test, subTemplateName, optionsData) {                                                   // 1592
  _.each([Template.spacebars_test_helpers_stop_onetwo,                                                                // 1593
          Template.spacebars_test_helpers_stop_onetwo_attribute],                                                     // 1594
         function (tmpl) {                                                                                            // 1595
                                                                                                                      // 1596
           tmpl.one = Template[subTemplateName + '1'];                                                                // 1597
           tmpl.two = Template[subTemplateName + '2'];                                                                // 1598
                                                                                                                      // 1599
           var buf = '';                                                                                              // 1600
                                                                                                                      // 1601
           var showOne = ReactiveVar(true);                                                                           // 1602
           var dummy = ReactiveVar(0);                                                                                // 1603
                                                                                                                      // 1604
           tmpl.showOne = function () { return showOne.get(); };                                                      // 1605
           tmpl.one.options = function () {                                                                           // 1606
             var x = dummy.get();                                                                                     // 1607
             buf += '1';                                                                                              // 1608
             if (optionsData)                                                                                         // 1609
               return optionsData[x];                                                                                 // 1610
             else                                                                                                     // 1611
               return ['something'];                                                                                  // 1612
           };                                                                                                         // 1613
           tmpl.two.options = function () {                                                                           // 1614
             var x = dummy.get();                                                                                     // 1615
             buf += '2';                                                                                              // 1616
             if (optionsData)                                                                                         // 1617
               return optionsData[x];                                                                                 // 1618
             else                                                                                                     // 1619
               return ['something'];                                                                                  // 1620
           };                                                                                                         // 1621
                                                                                                                      // 1622
           var div = renderToDiv(tmpl);                                                                               // 1623
           Deps.flush();                                                                                              // 1624
           test.equal(buf, '1');                                                                                      // 1625
                                                                                                                      // 1626
           showOne.set(false);                                                                                        // 1627
           dummy.set(1);                                                                                              // 1628
           Deps.flush();                                                                                              // 1629
           test.equal(buf, '12');                                                                                     // 1630
                                                                                                                      // 1631
           showOne.set(true);                                                                                         // 1632
           dummy.set(2);                                                                                              // 1633
           Deps.flush();                                                                                              // 1634
           test.equal(buf, '121');                                                                                    // 1635
                                                                                                                      // 1636
           // clean up the div                                                                                        // 1637
           $(div).remove();                                                                                           // 1638
           test.equal(showOne.numListeners(), 0);                                                                     // 1639
           test.equal(dummy.numListeners(), 0);                                                                       // 1640
         });                                                                                                          // 1641
};                                                                                                                    // 1642
                                                                                                                      // 1643
Tinytest.add('spacebars-tests - template_tests - with stops without re-running helper', function (test) {             // 1644
  runOneTwoTest(test, 'spacebars_test_helpers_stop_with');                                                            // 1645
});                                                                                                                   // 1646
                                                                                                                      // 1647
Tinytest.add('spacebars-tests - template_tests - each stops without re-running helper', function (test) {             // 1648
  runOneTwoTest(test, 'spacebars_test_helpers_stop_each');                                                            // 1649
});                                                                                                                   // 1650
                                                                                                                      // 1651
Tinytest.add('spacebars-tests - template_tests - each inside with stops without re-running helper', function (test) { // 1652
  runOneTwoTest(test, 'spacebars_test_helpers_stop_with_each');                                                       // 1653
});                                                                                                                   // 1654
                                                                                                                      // 1655
Tinytest.add('spacebars-tests - template_tests - if stops without re-running helper', function (test) {               // 1656
  runOneTwoTest(test, 'spacebars_test_helpers_stop_if', ['a', 'b', 'a']);                                             // 1657
});                                                                                                                   // 1658
                                                                                                                      // 1659
Tinytest.add('spacebars-tests - template_tests - unless stops without re-running helper', function (test) {           // 1660
  runOneTwoTest(test, 'spacebars_test_helpers_stop_unless', ['a', 'b', 'a']);                                         // 1661
});                                                                                                                   // 1662
                                                                                                                      // 1663
Tinytest.add('spacebars-tests - template_tests - inclusion stops without re-running function', function (test) {      // 1664
  var t = Template.spacebars_test_helpers_stop_inclusion3;                                                            // 1665
  runOneTwoTest(test, 'spacebars_test_helpers_stop_inclusion', [t, t, t]);                                            // 1666
});                                                                                                                   // 1667
                                                                                                                      // 1668
Tinytest.add('spacebars-tests - template_tests - template with callbacks inside with stops without recalculating data', function (test) {
  var tmpl = Template.spacebars_test_helpers_stop_with_callbacks3;                                                    // 1670
  tmpl.created = function () {};                                                                                      // 1671
  tmpl.rendered = function () {};                                                                                     // 1672
  tmpl.destroyed = function () {};                                                                                    // 1673
  runOneTwoTest(test, 'spacebars_test_helpers_stop_with_callbacks');                                                  // 1674
});                                                                                                                   // 1675
                                                                                                                      // 1676
Tinytest.add('spacebars-tests - template_tests - no data context is seen as an empty object', function (test) {       // 1677
  var tmpl = Template.spacebars_test_no_data_context;                                                                 // 1678
                                                                                                                      // 1679
  var dataInHelper = 'UNSET';                                                                                         // 1680
  var dataInRendered = 'UNSET';                                                                                       // 1681
  var dataInCreated = 'UNSET';                                                                                        // 1682
  var dataInDestroyed = 'UNSET';                                                                                      // 1683
  var dataInEvent = 'UNSET';                                                                                          // 1684
                                                                                                                      // 1685
  tmpl.foo = function () {                                                                                            // 1686
    dataInHelper = this;                                                                                              // 1687
  };                                                                                                                  // 1688
  tmpl.created = function () {                                                                                        // 1689
    dataInCreated = this.data;                                                                                        // 1690
  };                                                                                                                  // 1691
  tmpl.rendered = function () {                                                                                       // 1692
    dataInRendered = this.data;                                                                                       // 1693
  };                                                                                                                  // 1694
  tmpl.destroyed = function () {                                                                                      // 1695
    dataInDestroyed = this.data;                                                                                      // 1696
  };                                                                                                                  // 1697
  tmpl.events({                                                                                                       // 1698
    'click': function () {                                                                                            // 1699
      dataInEvent = this;                                                                                             // 1700
    }                                                                                                                 // 1701
  });                                                                                                                 // 1702
                                                                                                                      // 1703
  var div = renderToDiv(tmpl);                                                                                        // 1704
  document.body.appendChild(div);                                                                                     // 1705
  clickElement(div.querySelector('button'));                                                                          // 1706
  Deps.flush(); // rendered gets called afterFlush                                                                    // 1707
  $(div).remove();                                                                                                    // 1708
                                                                                                                      // 1709
  test.isFalse(dataInHelper === window);                                                                              // 1710
  test.equal(dataInHelper, {});                                                                                       // 1711
  test.equal(dataInCreated, null);                                                                                    // 1712
  test.equal(dataInRendered, null);                                                                                   // 1713
  test.equal(dataInDestroyed, null);                                                                                  // 1714
  test.isFalse(dataInEvent === window);                                                                               // 1715
  test.equal(dataInEvent, {});                                                                                        // 1716
});                                                                                                                   // 1717
                                                                                                                      // 1718
Tinytest.add('spacebars-tests - template_tests - falsy with', function (test) {                                       // 1719
  var tmpl = Template.spacebars_test_falsy_with;                                                                      // 1720
  var R = ReactiveVar(null);                                                                                          // 1721
  tmpl.obj = function () { return R.get(); };                                                                         // 1722
                                                                                                                      // 1723
  var div = renderToDiv(tmpl);                                                                                        // 1724
  divRendersTo(test, div, "");                                                                                        // 1725
                                                                                                                      // 1726
  R.set({greekLetter: 'alpha'});                                                                                      // 1727
  divRendersTo(test, div, "alpha");                                                                                   // 1728
                                                                                                                      // 1729
  R.set(null);                                                                                                        // 1730
  divRendersTo(test, div, "");                                                                                        // 1731
                                                                                                                      // 1732
  R.set({greekLetter: 'alpha'});                                                                                      // 1733
  divRendersTo(test, div, "alpha");                                                                                   // 1734
});                                                                                                                   // 1735
                                                                                                                      // 1736
Tinytest.add("spacebars-tests - template_tests - helpers don't leak", function (test) {                               // 1737
  var tmpl = Template.spacebars_test_helpers_dont_leak;                                                               // 1738
  tmpl.foo = "wrong";                                                                                                 // 1739
  tmpl.bar = function () { return "WRONG"; };                                                                         // 1740
                                                                                                                      // 1741
  // Also test that custom block helpers (implemented as templates) do NOT                                            // 1742
  // interfere with helper lookup in the current template                                                             // 1743
  Template.spacebars_test_helpers_dont_leak2.bonus =                                                                  // 1744
    function () { return 'BONUS'; };                                                                                  // 1745
                                                                                                                      // 1746
  var div = renderToDiv(tmpl);                                                                                        // 1747
  divRendersTo(test, div, "correct BONUS");                                                                           // 1748
});                                                                                                                   // 1749
                                                                                                                      // 1750
Tinytest.add("spacebars-tests - template_tests - event handler returns false",                                        // 1751
  function (test) {                                                                                                   // 1752
    var tmpl = Template.spacebars_test_event_returns_false;                                                           // 1753
    var elemId = "spacebars_test_event_returns_false_link";                                                           // 1754
    tmpl.events({                                                                                                     // 1755
      'click a': function (evt) { return false; }                                                                     // 1756
    });                                                                                                               // 1757
                                                                                                                      // 1758
    var div = renderToDiv(tmpl);                                                                                      // 1759
    document.body.appendChild(div);                                                                                   // 1760
    clickIt(document.getElementById(elemId));                                                                         // 1761
    // NOTE: This failure can stick across test runs!  Try                                                            // 1762
    // removing '#bad-url' from the location bar and run                                                              // 1763
    // the tests again. :)                                                                                            // 1764
    test.isFalse(/#bad-url/.test(window.location.hash));                                                              // 1765
    document.body.removeChild(div);                                                                                   // 1766
  }                                                                                                                   // 1767
);                                                                                                                    // 1768
                                                                                                                      // 1769
// Make sure that if you bind an event on "div p", for example,                                                       // 1770
// both the div and the p need to be in the template.  jQuery's                                                       // 1771
// `$(elem).find(...)` works this way, but the browser's                                                              // 1772
// querySelector doesn't.                                                                                             // 1773
Tinytest.add(                                                                                                         // 1774
  "spacebars-tests - template_tests - event map selector scope",                                                      // 1775
  function (test) {                                                                                                   // 1776
    var tmpl = Template.spacebars_test_event_selectors1;                                                              // 1777
    var tmpl2 = Template.spacebars_test_event_selectors2;                                                             // 1778
    var buf = [];                                                                                                     // 1779
    tmpl2.events({                                                                                                    // 1780
      'click div p': function (evt) { buf.push(evt.currentTarget.className); }                                        // 1781
    });                                                                                                               // 1782
                                                                                                                      // 1783
    var div = renderToDiv(tmpl);                                                                                      // 1784
    document.body.appendChild(div);                                                                                   // 1785
    test.equal(buf.join(), '');                                                                                       // 1786
    clickIt(div.querySelector('.p1'));                                                                                // 1787
    test.equal(buf.join(), '');                                                                                       // 1788
    clickIt(div.querySelector('.p2'));                                                                                // 1789
    test.equal(buf.join(), 'p2');                                                                                     // 1790
    document.body.removeChild(div);                                                                                   // 1791
  }                                                                                                                   // 1792
);                                                                                                                    // 1793
                                                                                                                      // 1794
if (document.addEventListener) {                                                                                      // 1795
  // see note about non-bubbling events in the "capuring events"                                                      // 1796
  // templating test for why we use the VIDEO tag.  (It would be                                                      // 1797
  // nice to get rid of the network dependency, though.)                                                              // 1798
  // We skip this test in IE 8.                                                                                       // 1799
  Tinytest.add(                                                                                                       // 1800
    "spacebars-tests - template_tests - event map selector scope (capturing)",                                        // 1801
    function (test) {                                                                                                 // 1802
      var tmpl = Template.spacebars_test_event_selectors_capturing1;                                                  // 1803
      var tmpl2 = Template.spacebars_test_event_selectors_capturing2;                                                 // 1804
      var buf = [];                                                                                                   // 1805
      tmpl2.events({                                                                                                  // 1806
        'play div video': function (evt) { buf.push(evt.currentTarget.className); }                                   // 1807
      });                                                                                                             // 1808
                                                                                                                      // 1809
      var div = renderToDiv(tmpl);                                                                                    // 1810
      document.body.appendChild(div);                                                                                 // 1811
      test.equal(buf.join(), '');                                                                                     // 1812
      simulateEvent(div.querySelector(".video1"),                                                                     // 1813
                    "play", {}, {bubbles: false});                                                                    // 1814
      test.equal(buf.join(), '');                                                                                     // 1815
      simulateEvent(div.querySelector(".video2"),                                                                     // 1816
                    "play", {}, {bubbles: false});                                                                    // 1817
      test.equal(buf.join(), 'video2');                                                                               // 1818
      document.body.removeChild(div);                                                                                 // 1819
    }                                                                                                                 // 1820
  );                                                                                                                  // 1821
}                                                                                                                     // 1822
                                                                                                                      // 1823
Tinytest.add("spacebars-tests - template_tests - tables", function (test) {                                           // 1824
  var tmpl1 = Template.spacebars_test_tables1;                                                                        // 1825
                                                                                                                      // 1826
  var div = renderToDiv(tmpl1);                                                                                       // 1827
  test.equal(_.pluck(div.querySelectorAll('*'), 'tagName'),                                                           // 1828
             ['TABLE', 'TR', 'TD']);                                                                                  // 1829
  divRendersTo(test, div, '<table><tr><td>Foo</td></tr></table>');                                                    // 1830
                                                                                                                      // 1831
  var tmpl2 = Template.spacebars_test_tables2;                                                                        // 1832
  tmpl2.foo = 'Foo';                                                                                                  // 1833
  div = renderToDiv(tmpl2);                                                                                           // 1834
  test.equal(_.pluck(div.querySelectorAll('*'), 'tagName'),                                                           // 1835
             ['TABLE', 'TR', 'TD']);                                                                                  // 1836
  divRendersTo(test, div, '<table><tr><td>Foo</td></tr></table>');                                                    // 1837
});                                                                                                                   // 1838
                                                                                                                      // 1839
Tinytest.add("spacebars-tests - template_tests - jQuery.trigger extraParameters are passed to the event callback",    // 1840
  function (test) {                                                                                                   // 1841
    var tmpl = Template.spacebars_test_jquery_events;                                                                 // 1842
    var captured = false;                                                                                             // 1843
    var args = ["param1", "param2", {option: 1}, 1, 2, 3];                                                            // 1844
                                                                                                                      // 1845
    tmpl.events({                                                                                                     // 1846
      'someCustomEvent': function (event, template) {                                                                 // 1847
        var i;                                                                                                        // 1848
        for (i=0; i<args.length; i++) {                                                                               // 1849
          // expect the arguments to be just after template                                                           // 1850
          test.equal(arguments[i+2], args[i]);                                                                        // 1851
        }                                                                                                             // 1852
        captured = true;                                                                                              // 1853
      }                                                                                                               // 1854
    });                                                                                                               // 1855
                                                                                                                      // 1856
    tmpl.rendered = function () {                                                                                     // 1857
      $(this.find('button')).trigger('someCustomEvent', args);                                                        // 1858
    };                                                                                                                // 1859
                                                                                                                      // 1860
    renderToDiv(tmpl);                                                                                                // 1861
    Deps.flush();                                                                                                     // 1862
    test.equal(captured, true);                                                                                       // 1863
  }                                                                                                                   // 1864
);                                                                                                                    // 1865
                                                                                                                      // 1866
Tinytest.add("spacebars-tests - template_tests - toHTML", function (test) {                                           // 1867
  // run once, verifying that autoruns are stopped                                                                    // 1868
  var once = function (tmplToRender, tmplForHelper, helper, val) {                                                    // 1869
    var count = 0;                                                                                                    // 1870
    var R = new ReactiveVar;                                                                                          // 1871
    var getR = function () {                                                                                          // 1872
      count++;                                                                                                        // 1873
      return R.get();                                                                                                 // 1874
    };                                                                                                                // 1875
                                                                                                                      // 1876
    R.set(val);                                                                                                       // 1877
    tmplForHelper[helper] = getR;                                                                                     // 1878
    test.equal(canonicalizeHtml(Blaze.toHTML(tmplToRender)), "bar");                                                  // 1879
    test.equal(count, 1);                                                                                             // 1880
    R.set("");                                                                                                        // 1881
    Deps.flush();                                                                                                     // 1882
    test.equal(count, 1); // all autoruns stopped                                                                     // 1883
  };                                                                                                                  // 1884
                                                                                                                      // 1885
  once(Template.spacebars_test_tohtml_basic,                                                                          // 1886
       Template.spacebars_test_tohtml_basic, "foo", "bar");                                                           // 1887
  once(Template.spacebars_test_tohtml_if,                                                                             // 1888
       Template.spacebars_test_tohtml_if, "foo", "bar");                                                              // 1889
  once(Template.spacebars_test_tohtml_with,                                                                           // 1890
       Template.spacebars_test_tohtml_with, "foo", "bar");                                                            // 1891
  once(Template.spacebars_test_tohtml_each,                                                                           // 1892
       Template.spacebars_test_tohtml_each, "foos", ["bar"]);                                                         // 1893
                                                                                                                      // 1894
  once(Template.spacebars_test_tohtml_include_with,                                                                   // 1895
       Template.spacebars_test_tohtml_with, "foo", "bar");                                                            // 1896
  once(Template.spacebars_test_tohtml_include_each,                                                                   // 1897
       Template.spacebars_test_tohtml_each, "foos", ["bar"]);                                                         // 1898
});                                                                                                                   // 1899
                                                                                                                      // 1900
Tinytest.add("spacebars-tests - template_tests - block comments should not be displayed",                             // 1901
  function (test) {                                                                                                   // 1902
    var tmpl = Template.spacebars_test_block_comment;                                                                 // 1903
    var div = renderToDiv(tmpl);                                                                                      // 1904
    test.equal(canonicalizeHtml(div.innerHTML), '');                                                                  // 1905
  }                                                                                                                   // 1906
);                                                                                                                    // 1907
                                                                                                                      // 1908
// Originally reported at https://github.com/meteor/meteor/issues/2046                                                // 1909
Tinytest.add("spacebars-tests - template_tests - {{#with}} with mutated data context",                                // 1910
  function (test) {                                                                                                   // 1911
    var tmpl = Template.spacebars_test_with_mutated_data_context;                                                     // 1912
    var foo = {value: 0};                                                                                             // 1913
    var dep = new Deps.Dependency;                                                                                    // 1914
    tmpl.foo = function () {                                                                                          // 1915
      dep.depend();                                                                                                   // 1916
      return foo;                                                                                                     // 1917
    };                                                                                                                // 1918
                                                                                                                      // 1919
    var div = renderToDiv(tmpl);                                                                                      // 1920
    test.equal(canonicalizeHtml(div.innerHTML), '0');                                                                 // 1921
                                                                                                                      // 1922
    foo.value = 1;                                                                                                    // 1923
    dep.changed();                                                                                                    // 1924
    Deps.flush();                                                                                                     // 1925
    test.equal(canonicalizeHtml(div.innerHTML), '1');                                                                 // 1926
  });                                                                                                                 // 1927
                                                                                                                      // 1928
Tinytest.add("spacebars-tests - template_tests - javascript scheme urls",                                             // 1929
  function (test) {                                                                                                   // 1930
    var tmpl = Template.spacebars_test_url_attribute;                                                                 // 1931
    var sessionKey = "foo-" + Random.id();                                                                            // 1932
    tmpl.foo = function () {                                                                                          // 1933
      return Session.get(sessionKey);                                                                                 // 1934
    };                                                                                                                // 1935
                                                                                                                      // 1936
    var numUrlAttrs = 4;                                                                                              // 1937
    var div = renderToDiv(tmpl);                                                                                      // 1938
                                                                                                                      // 1939
    // [tag name, attr name, is a url attribute]                                                                      // 1940
    var attrsList = [["A", "href", true], ["FORM", "action", true],                                                   // 1941
                     ["IMG", "src", true], ["INPUT", "value", false]];                                                // 1942
                                                                                                                      // 1943
    var checkAttrs = function (url, isJavascriptProtocol) {                                                           // 1944
      if (isJavascriptProtocol) {                                                                                     // 1945
        Meteor._suppress_log(numUrlAttrs);                                                                            // 1946
      }                                                                                                               // 1947
      Session.set(sessionKey, url);                                                                                   // 1948
      Deps.flush();                                                                                                   // 1949
      _.each(                                                                                                         // 1950
        attrsList,                                                                                                    // 1951
        function (attrInfo) {                                                                                         // 1952
          var normalizedUrl;                                                                                          // 1953
          var elem = document.createElement(attrInfo[0]);                                                             // 1954
          try {                                                                                                       // 1955
            elem[attrInfo[1]] = url;                                                                                  // 1956
          } catch (err) {                                                                                             // 1957
            // IE throws an exception if you set an img src to a                                                      // 1958
            // javascript: URL. Blaze can't override this behavior;                                                   // 1959
            // whether you've called UI._javascriptUrlsAllowed() or not,                                              // 1960
            // you won't be able to set a javascript: URL in an img                                                   // 1961
            // src. So we only test img tags in other browsers.                                                       // 1962
            if (attrInfo[0] === "IMG") {                                                                              // 1963
              return;                                                                                                 // 1964
            }                                                                                                         // 1965
            throw err;                                                                                                // 1966
          }                                                                                                           // 1967
          document.body.appendChild(elem);                                                                            // 1968
          normalizedUrl = elem[attrInfo[1]];                                                                          // 1969
          document.body.removeChild(elem);                                                                            // 1970
                                                                                                                      // 1971
          _.each(                                                                                                     // 1972
            div.getElementsByTagName(attrInfo[0]),                                                                    // 1973
            function (elem) {                                                                                         // 1974
              test.equal(                                                                                             // 1975
                elem[attrInfo[1]],                                                                                    // 1976
                isJavascriptProtocol && attrInfo[2] ? "" : normalizedUrl                                              // 1977
              );                                                                                                      // 1978
            }                                                                                                         // 1979
          );                                                                                                          // 1980
        }                                                                                                             // 1981
      );                                                                                                              // 1982
    };                                                                                                                // 1983
                                                                                                                      // 1984
    test.equal(UI._javascriptUrlsAllowed(), false);                                                                   // 1985
    checkAttrs("http://www.meteor.com", false);                                                                       // 1986
    checkAttrs("javascript:alert(1)", true);                                                                          // 1987
    checkAttrs("jAvAsCrIpT:alert(1)", true);                                                                          // 1988
    checkAttrs("    javascript:alert(1)", true);                                                                      // 1989
    UI._allowJavascriptUrls();                                                                                        // 1990
    test.equal(UI._javascriptUrlsAllowed(), true);                                                                    // 1991
    checkAttrs("http://www.meteor.com", false);                                                                       // 1992
    checkAttrs("javascript:alert(1)", false);                                                                         // 1993
    checkAttrs("jAvAsCrIpT:alert(1)", false);                                                                         // 1994
    checkAttrs("    javascript:alert(1)", false);                                                                     // 1995
  }                                                                                                                   // 1996
);                                                                                                                    // 1997
                                                                                                                      // 1998
Tinytest.add("spacebars-tests - template_tests - event handlers get cleaned up when template is removed",             // 1999
  function (test) {                                                                                                   // 2000
    var tmpl = Template.spacebars_test_event_handler_cleanup;                                                         // 2001
    var subtmpl = Template.spacebars_test_event_handler_cleanup_sub;                                                  // 2002
                                                                                                                      // 2003
    var rv = new ReactiveVar(true);                                                                                   // 2004
    tmpl.foo = function () {                                                                                          // 2005
      return rv.get();                                                                                                // 2006
    };                                                                                                                // 2007
                                                                                                                      // 2008
    subtmpl.events({                                                                                                  // 2009
      "click/mouseover": function () { }                                                                              // 2010
    });                                                                                                               // 2011
                                                                                                                      // 2012
    var div = renderToDiv(tmpl);                                                                                      // 2013
                                                                                                                      // 2014
    test.equal(div.$blaze_events["click"].handlers.length, 1);                                                        // 2015
    test.equal(div.$blaze_events["mouseover"].handlers.length, 1);                                                    // 2016
                                                                                                                      // 2017
    rv.set(false);                                                                                                    // 2018
    Deps.flush();                                                                                                     // 2019
                                                                                                                      // 2020
    test.equal(div.$blaze_events["click"].handlers.length, 0);                                                        // 2021
    test.equal(div.$blaze_events["mouseover"].handlers.length, 0);                                                    // 2022
  }                                                                                                                   // 2023
);                                                                                                                    // 2024
                                                                                                                      // 2025
// This test makes sure that Blaze correctly finds the controller                                                     // 2026
// heirarchy surrounding an element that itself doesn't have a                                                        // 2027
// controller.                                                                                                        // 2028
Tinytest.add(                                                                                                         // 2029
  "spacebars-tests - template_tests - data context in event handlers on elements inside {{#if}}",                     // 2030
  function (test) {                                                                                                   // 2031
    var tmpl = Template.spacebars_test_data_context_for_event_handler_in_if;                                          // 2032
    var data = null;                                                                                                  // 2033
    tmpl.events({                                                                                                     // 2034
      'click span': function () {                                                                                     // 2035
        data = this;                                                                                                  // 2036
      }                                                                                                               // 2037
    });                                                                                                               // 2038
    var div = renderToDiv(tmpl);                                                                                      // 2039
    document.body.appendChild(div);                                                                                   // 2040
    clickIt(div.querySelector('span'));                                                                               // 2041
    test.equal(data, {foo: "bar"});                                                                                   // 2042
    document.body.removeChild(div);                                                                                   // 2043
  });                                                                                                                 // 2044
                                                                                                                      // 2045
// https://github.com/meteor/meteor/issues/2156                                                                       // 2046
Tinytest.add(                                                                                                         // 2047
  "spacebars-tests - template_tests - each with inserts inside autorun",                                              // 2048
  function (test) {                                                                                                   // 2049
    var tmpl = Template.spacebars_test_each_with_autorun_insert;                                                      // 2050
    var coll = new Meteor.Collection(null);                                                                           // 2051
    var rv = new ReactiveVar;                                                                                         // 2052
                                                                                                                      // 2053
    tmpl.items = function () {                                                                                        // 2054
      return coll.find();                                                                                             // 2055
    };                                                                                                                // 2056
                                                                                                                      // 2057
    var div = renderToDiv(tmpl);                                                                                      // 2058
                                                                                                                      // 2059
    Deps.autorun(function () {                                                                                        // 2060
      if (rv.get()) {                                                                                                 // 2061
        coll.insert({ name: rv.get() });                                                                              // 2062
      }                                                                                                               // 2063
    });                                                                                                               // 2064
                                                                                                                      // 2065
    rv.set("foo1");                                                                                                   // 2066
    Deps.flush();                                                                                                     // 2067
    var firstId = coll.findOne()._id;                                                                                 // 2068
                                                                                                                      // 2069
    rv.set("foo2");                                                                                                   // 2070
    Deps.flush();                                                                                                     // 2071
                                                                                                                      // 2072
    test.equal(canonicalizeHtml(div.innerHTML), "foo1 foo2");                                                         // 2073
                                                                                                                      // 2074
    coll.update(firstId, { $set: { name: "foo3" } });                                                                 // 2075
    Deps.flush();                                                                                                     // 2076
    test.equal(canonicalizeHtml(div.innerHTML), "foo3 foo2");                                                         // 2077
  }                                                                                                                   // 2078
);                                                                                                                    // 2079
                                                                                                                      // 2080
Tinytest.add(                                                                                                         // 2081
  "spacebars-tests - template_tests - ui hooks",                                                                      // 2082
  function (test) {                                                                                                   // 2083
    var tmpl = Template.spacebars_test_ui_hooks;                                                                      // 2084
    var rv = new ReactiveVar([]);                                                                                     // 2085
    tmpl.items = function () {                                                                                        // 2086
      return rv.get();                                                                                                // 2087
    };                                                                                                                // 2088
                                                                                                                      // 2089
    var div = renderToDiv(tmpl);                                                                                      // 2090
                                                                                                                      // 2091
    var hooks = [];                                                                                                   // 2092
    var container = div.querySelector(".test-ui-hooks");                                                              // 2093
                                                                                                                      // 2094
    // Before we attach the ui hooks, put two items in the DOM.                                                       // 2095
    var origVal = [{ _id: 'foo1' }, { _id: 'foo2' }];                                                                 // 2096
    rv.set(origVal);                                                                                                  // 2097
    Deps.flush();                                                                                                     // 2098
                                                                                                                      // 2099
    container._uihooks = {                                                                                            // 2100
      insertElement: function (n, next) {                                                                             // 2101
        hooks.push("insert");                                                                                         // 2102
                                                                                                                      // 2103
        // check that the element hasn't actually been added yet                                                      // 2104
        test.isTrue((! n.parentNode) ||                                                                               // 2105
                    n.parentNode.nodeType === 11 /*DOCUMENT_FRAGMENT_NODE*/);                                         // 2106
      },                                                                                                              // 2107
      removeElement: function (n) {                                                                                   // 2108
        hooks.push("remove");                                                                                         // 2109
        // check that the element hasn't actually been removed yet                                                    // 2110
        test.isTrue(n.parentNode === container);                                                                      // 2111
      },                                                                                                              // 2112
      moveElement: function (n, next) {                                                                               // 2113
        hooks.push("move");                                                                                           // 2114
        // check that the element hasn't actually been moved yet                                                      // 2115
        test.isFalse(n.nextNode === next);                                                                            // 2116
      }                                                                                                               // 2117
    };                                                                                                                // 2118
                                                                                                                      // 2119
    var testDomUnchanged = function () {                                                                              // 2120
      var items = div.querySelectorAll(".item");                                                                      // 2121
      test.equal(items.length, 2);                                                                                    // 2122
      test.equal(canonicalizeHtml(items[0].innerHTML), "foo1");                                                       // 2123
      test.equal(canonicalizeHtml(items[1].innerHTML), "foo2");                                                       // 2124
    };                                                                                                                // 2125
                                                                                                                      // 2126
    var newVal = _.clone(origVal);                                                                                    // 2127
    newVal.push({ _id: 'foo3' });                                                                                     // 2128
    rv.set(newVal);                                                                                                   // 2129
    Deps.flush();                                                                                                     // 2130
    test.equal(hooks, ['insert']);                                                                                    // 2131
    testDomUnchanged();                                                                                               // 2132
                                                                                                                      // 2133
    newVal.reverse();                                                                                                 // 2134
    rv.set(newVal);                                                                                                   // 2135
    Deps.flush();                                                                                                     // 2136
    test.equal(hooks, ['insert', 'move']);                                                                            // 2137
    testDomUnchanged();                                                                                               // 2138
                                                                                                                      // 2139
    newVal = [origVal[0]];                                                                                            // 2140
    rv.set(newVal);                                                                                                   // 2141
    Deps.flush();                                                                                                     // 2142
    test.equal(hooks, ['insert', 'move', 'remove']);                                                                  // 2143
    testDomUnchanged();                                                                                               // 2144
  }                                                                                                                   // 2145
);                                                                                                                    // 2146
                                                                                                                      // 2147
Tinytest.add(                                                                                                         // 2148
  "spacebars-tests - template_tests - ui hooks - nested domranges",                                                   // 2149
  function (test) {                                                                                                   // 2150
    var tmpl = Template.spacebars_test_ui_hooks_nested;                                                               // 2151
    var rv = new ReactiveVar(true);                                                                                   // 2152
                                                                                                                      // 2153
    tmpl.foo = function () {                                                                                          // 2154
      return rv.get();                                                                                                // 2155
    };                                                                                                                // 2156
                                                                                                                      // 2157
    var subtmpl = Template.spacebars_test_ui_hooks_nested_sub;                                                        // 2158
    var uiHookCalled = false;                                                                                         // 2159
    subtmpl.rendered = function () {                                                                                  // 2160
      this.firstNode.parentNode._uihooks = {                                                                          // 2161
        removeElement: function (node) {                                                                              // 2162
          uiHookCalled = true;                                                                                        // 2163
        }                                                                                                             // 2164
      };                                                                                                              // 2165
    };                                                                                                                // 2166
                                                                                                                      // 2167
    var div = renderToDiv(tmpl);                                                                                      // 2168
    document.body.appendChild(div);                                                                                   // 2169
    Deps.flush();                                                                                                     // 2170
                                                                                                                      // 2171
    var htmlBeforeRemove = canonicalizeHtml(div.innerHTML);                                                           // 2172
    rv.set(false);                                                                                                    // 2173
    Deps.flush();                                                                                                     // 2174
    test.isTrue(uiHookCalled);                                                                                        // 2175
    var htmlAfterRemove = canonicalizeHtml(div.innerHTML);                                                            // 2176
    test.equal(htmlBeforeRemove, htmlAfterRemove);                                                                    // 2177
    document.body.removeChild(div);                                                                                   // 2178
  }                                                                                                                   // 2179
);                                                                                                                    // 2180
                                                                                                                      // 2181
Tinytest.add(                                                                                                         // 2182
  "spacebars-tests - template_tests - UI._templateInstance from helper",                                              // 2183
  function (test) {                                                                                                   // 2184
    // Set a property on the template instance; check that it's still                                                 // 2185
    // there from a helper.                                                                                           // 2186
                                                                                                                      // 2187
    var tmpl = Template.spacebars_test_template_instance_helper;                                                      // 2188
    var value = Random.id();                                                                                          // 2189
    var instanceFromHelper;                                                                                           // 2190
                                                                                                                      // 2191
    tmpl.created = function () {                                                                                      // 2192
      this.value = value;                                                                                             // 2193
    };                                                                                                                // 2194
    tmpl.foo = function () {                                                                                          // 2195
      instanceFromHelper = UI._templateInstance();                                                                    // 2196
    };                                                                                                                // 2197
                                                                                                                      // 2198
    var div = renderToDiv(tmpl);                                                                                      // 2199
    test.equal(instanceFromHelper.value, value);                                                                      // 2200
  }                                                                                                                   // 2201
);                                                                                                                    // 2202
                                                                                                                      // 2203
Tinytest.add(                                                                                                         // 2204
  "spacebars-tests - template_tests - UI._templateInstance from helper, " +                                           // 2205
    "template instance is kept up-to-date",                                                                           // 2206
  function (test) {                                                                                                   // 2207
    var tmpl = Template.spacebars_test_template_instance_helper;                                                      // 2208
    var rv = new ReactiveVar("");                                                                                     // 2209
    var instanceFromHelper;                                                                                           // 2210
                                                                                                                      // 2211
    tmpl.foo = function () {                                                                                          // 2212
      return UI._templateInstance().data;                                                                             // 2213
    };                                                                                                                // 2214
                                                                                                                      // 2215
    var div = renderToDiv(tmpl, function () { return rv.get(); });                                                    // 2216
    rv.set("first");                                                                                                  // 2217
    divRendersTo(test, div, "first");                                                                                 // 2218
                                                                                                                      // 2219
    rv.set("second");                                                                                                 // 2220
    Deps.flush();                                                                                                     // 2221
    divRendersTo(test, div, "second");                                                                                // 2222
                                                                                                                      // 2223
    // UI._templateInstance() should throw when called from not within a                                              // 2224
    // helper.                                                                                                        // 2225
    test.throws(function () {                                                                                         // 2226
      UI._templateInstance();                                                                                         // 2227
    });                                                                                                               // 2228
  }                                                                                                                   // 2229
);                                                                                                                    // 2230
                                                                                                                      // 2231
Tinytest.add(                                                                                                         // 2232
  "spacebars-tests - template_tests - {{#with}} autorun is cleaned up",                                               // 2233
  function (test) {                                                                                                   // 2234
    var tmpl = Template.spacebars_test_with_cleanup;                                                                  // 2235
    var rv = new ReactiveVar("");                                                                                     // 2236
    var helperCalled = false;                                                                                         // 2237
    tmpl.foo = function () {                                                                                          // 2238
      helperCalled = true;                                                                                            // 2239
      return rv.get();                                                                                                // 2240
    };                                                                                                                // 2241
                                                                                                                      // 2242
    var div = renderToDiv(tmpl);                                                                                      // 2243
    rv.set("first");                                                                                                  // 2244
    Deps.flush();                                                                                                     // 2245
    test.equal(helperCalled, true);                                                                                   // 2246
                                                                                                                      // 2247
    helperCalled = false;                                                                                             // 2248
    $(div).find(".test-with-cleanup").remove();                                                                       // 2249
                                                                                                                      // 2250
    rv.set("second");                                                                                                 // 2251
    Deps.flush();                                                                                                     // 2252
    test.equal(helperCalled, false);                                                                                  // 2253
  }                                                                                                                   // 2254
);                                                                                                                    // 2255
                                                                                                                      // 2256
Tinytest.add(                                                                                                         // 2257
  "spacebars-tests - template_tests - UI._parentData from helpers",                                                   // 2258
  function (test) {                                                                                                   // 2259
    var childTmpl = Template.spacebars_test_template_parent_data_helper_child;                                        // 2260
    var parentTmpl = Template.spacebars_test_template_parent_data_helper;                                             // 2261
                                                                                                                      // 2262
    var height = new ReactiveVar(0);                                                                                  // 2263
    var bar = new ReactiveVar("bar");                                                                                 // 2264
                                                                                                                      // 2265
    childTmpl.a = ["a"];                                                                                              // 2266
    childTmpl.b = function () { return bar.get(); };                                                                  // 2267
    childTmpl.c = ["c"];                                                                                              // 2268
                                                                                                                      // 2269
    childTmpl.foo = function () {                                                                                     // 2270
      return UI._parentData(height.get());                                                                            // 2271
    };                                                                                                                // 2272
                                                                                                                      // 2273
    var div = renderToDiv(parentTmpl);                                                                                // 2274
    test.equal(canonicalizeHtml(div.innerHTML), "d");                                                                 // 2275
                                                                                                                      // 2276
    height.set(1);                                                                                                    // 2277
    Deps.flush();                                                                                                     // 2278
    test.equal(canonicalizeHtml(div.innerHTML), "bar");                                                               // 2279
                                                                                                                      // 2280
    // Test UI._parentData() reactivity                                                                               // 2281
                                                                                                                      // 2282
    bar.set("baz");                                                                                                   // 2283
    Deps.flush();                                                                                                     // 2284
    test.equal(canonicalizeHtml(div.innerHTML), "baz");                                                               // 2285
                                                                                                                      // 2286
    height.set(2);                                                                                                    // 2287
    Deps.flush();                                                                                                     // 2288
    test.equal(canonicalizeHtml(div.innerHTML), "a");                                                                 // 2289
                                                                                                                      // 2290
    height.set(3);                                                                                                    // 2291
    Deps.flush();                                                                                                     // 2292
    test.equal(canonicalizeHtml(div.innerHTML), "parent");                                                            // 2293
  }                                                                                                                   // 2294
);                                                                                                                    // 2295
                                                                                                                      // 2296
Tinytest.add(                                                                                                         // 2297
  "spacebars - SVG <a> elements",                                                                                     // 2298
  function (test) {                                                                                                   // 2299
    if (! document.createElementNS) {                                                                                 // 2300
      // IE 8                                                                                                         // 2301
      return;                                                                                                         // 2302
    }                                                                                                                 // 2303
                                                                                                                      // 2304
    var tmpl = Template.spacebars_test_svg_anchor;                                                                    // 2305
    var div = renderToDiv(tmpl);                                                                                      // 2306
                                                                                                                      // 2307
    var anchNamespace = $(div).find("a").get(0).namespaceURI;                                                         // 2308
    test.equal(anchNamespace, "http://www.w3.org/2000/svg");                                                          // 2309
  }                                                                                                                   // 2310
);                                                                                                                    // 2311
                                                                                                                      // 2312
Tinytest.add(                                                                                                         // 2313
  "spacebars-tests - template_tests - created/rendered/destroyed by each",                                            // 2314
  function (test) {                                                                                                   // 2315
    var outerTmpl =                                                                                                   // 2316
          Template.spacebars_test_template_created_rendered_destroyed_each;                                           // 2317
    var innerTmpl =                                                                                                   // 2318
          Template.spacebars_test_template_created_rendered_destroyed_each_sub;                                       // 2319
                                                                                                                      // 2320
    var buf = '';                                                                                                     // 2321
                                                                                                                      // 2322
    innerTmpl.created = function () { buf += 'C' + String(this.data).toLowerCase(); };                                // 2323
    innerTmpl.rendered = function () { buf += 'R' + String(this.data).toLowerCase(); };                               // 2324
    innerTmpl.destroyed = function () { buf += 'D' + String(this.data).toLowerCase(); };                              // 2325
                                                                                                                      // 2326
    var R = ReactiveVar([{_id: 'A'}]);                                                                                // 2327
                                                                                                                      // 2328
    outerTmpl.items = function () {                                                                                   // 2329
      return R.get();                                                                                                 // 2330
    };                                                                                                                // 2331
                                                                                                                      // 2332
    var div = renderToDiv(outerTmpl);                                                                                 // 2333
    divRendersTo(test, div, '<div>A</div>');                                                                          // 2334
    test.equal(buf, 'CaRa');                                                                                          // 2335
                                                                                                                      // 2336
    R.set([{_id: 'B'}]);                                                                                              // 2337
    divRendersTo(test, div, '<div>B</div>');                                                                          // 2338
    test.equal(buf, 'CaRaDaCbRb');                                                                                    // 2339
                                                                                                                      // 2340
    R.set([{_id: 'C'}]);                                                                                              // 2341
    divRendersTo(test, div, '<div>C</div>');                                                                          // 2342
    test.equal(buf, 'CaRaDaCbRbDbCcRc');                                                                              // 2343
                                                                                                                      // 2344
    $(div).remove();                                                                                                  // 2345
    test.equal(buf, 'CaRaDaCbRbDbCcRcDc');                                                                            // 2346
  });                                                                                                                 // 2347
                                                                                                                      // 2348
Tinytest.add(                                                                                                         // 2349
  "spacebars-tests - template_tests - UI.render/UI.insert/UI.remove",                                                 // 2350
  function (test) {                                                                                                   // 2351
    var div = document.createElement("DIV");                                                                          // 2352
    document.body.appendChild(div);                                                                                   // 2353
                                                                                                                      // 2354
    var created = false, rendered = false, destroyed = false;                                                         // 2355
    var R = ReactiveVar('aaa');                                                                                       // 2356
                                                                                                                      // 2357
    var tmpl = Template.spacebars_test_ui_render;                                                                     // 2358
    tmpl.greeting = function () { return this.greeting || 'Hello'; };                                                 // 2359
    tmpl.r = function () { return R.get(); };                                                                         // 2360
    tmpl.created = function () { created = true; };                                                                   // 2361
    tmpl.rendered = function () { rendered = true; };                                                                 // 2362
    tmpl.destroyed = function () { destroyed = true; };                                                               // 2363
                                                                                                                      // 2364
    test.equal([created, rendered, destroyed], [false, false, false]);                                                // 2365
                                                                                                                      // 2366
    var renderedTmpl = UI.render(tmpl);                                                                               // 2367
    test.equal([created, rendered, destroyed], [true, false, false]);                                                 // 2368
                                                                                                                      // 2369
    UI.insert(renderedTmpl, div);                                                                                     // 2370
    // Flush now. We fire the rendered callback in an afterFlush block,                                               // 2371
    // to ensure that the DOM is completely updated.                                                                  // 2372
    Deps.flush();                                                                                                     // 2373
    test.equal([created, rendered, destroyed], [true, true, false]);                                                  // 2374
                                                                                                                      // 2375
    var x = UI.render(tmpl); // can run a second time without throwing                                                // 2376
    // note: we'll have clean up `x` below                                                                            // 2377
                                                                                                                      // 2378
    var renderedTmpl2;                                                                                                // 2379
    UI.insert(renderedTmpl2 = UI.renderWithData(tmpl, {greeting: 'Bye'}),                                             // 2380
              div);                                                                                                   // 2381
    test.equal(canonicalizeHtml(div.innerHTML),                                                                       // 2382
               "<span>Hello aaa</span><span>Bye aaa</span>");                                                         // 2383
    R.set('bbb');                                                                                                     // 2384
    Deps.flush();                                                                                                     // 2385
    test.equal(canonicalizeHtml(div.innerHTML),                                                                       // 2386
               "<span>Hello bbb</span><span>Bye bbb</span>");                                                         // 2387
    test.equal([created, rendered, destroyed], [true, true, false]);                                                  // 2388
    test.equal(R.numListeners(), 3);                                                                                  // 2389
    UI.remove(renderedTmpl);                                                                                          // 2390
    UI.remove(renderedTmpl2);                                                                                         // 2391
    UI.remove(x);                                                                                                     // 2392
    test.equal([created, rendered, destroyed], [true, true, true]);                                                   // 2393
    test.equal(R.numListeners(), 0);                                                                                  // 2394
    test.equal(canonicalizeHtml(div.innerHTML), "");                                                                  // 2395
  });                                                                                                                 // 2396
                                                                                                                      // 2397
Tinytest.add(                                                                                                         // 2398
  "spacebars-tests - template_tests - UI.insert fails on jQuery objects",                                             // 2399
  function (test) {                                                                                                   // 2400
    var tmpl = Template.spacebars_test_ui_render;                                                                     // 2401
    test.throws(function () {                                                                                         // 2402
      UI.insert(UI.render(tmpl), $('body'));                                                                          // 2403
    }, /'parentElement' must be a DOM node/);                                                                         // 2404
    test.throws(function () {                                                                                         // 2405
      UI.insert(UI.render(tmpl), document.body, $('body'));                                                           // 2406
    }, /'nextNode' must be a DOM node/);                                                                              // 2407
  });                                                                                                                 // 2408
                                                                                                                      // 2409
Tinytest.add(                                                                                                         // 2410
  "spacebars-tests - template_tests - UI.getElementData",                                                             // 2411
  function (test) {                                                                                                   // 2412
    var div = document.createElement("DIV");                                                                          // 2413
    var tmpl = Template.spacebars_test_ui_getElementData;                                                             // 2414
    UI.insert(UI.renderWithData(tmpl, {foo: "bar"}), div);                                                            // 2415
                                                                                                                      // 2416
    var span = div.querySelector('SPAN');                                                                             // 2417
    test.isTrue(span);                                                                                                // 2418
    test.equal(UI.getElementData(span), {foo: "bar"});                                                                // 2419
  });                                                                                                                 // 2420
                                                                                                                      // 2421
Tinytest.add(                                                                                                         // 2422
  "spacebars-tests - template_tests - autorun cleanup",                                                               // 2423
  function (test) {                                                                                                   // 2424
    var tmpl = Template.spacebars_test_parent_removal;                                                                // 2425
                                                                                                                      // 2426
    var Acalls = '';                                                                                                  // 2427
    var A = ReactiveVar('hi');                                                                                        // 2428
    tmpl.A = function (chr) {                                                                                         // 2429
      Acalls += chr;                                                                                                  // 2430
      return A.get();                                                                                                 // 2431
    };                                                                                                                // 2432
    var Bcalls = 0;                                                                                                   // 2433
    var B = ReactiveVar(['one', 'two']);                                                                              // 2434
    tmpl.B = function () {                                                                                            // 2435
      Bcalls++;                                                                                                       // 2436
      return B.get();                                                                                                 // 2437
    };                                                                                                                // 2438
                                                                                                                      // 2439
    // Assert how many times A and B were accessed (since last time)                                                  // 2440
    // and how many autoruns are listening to them.                                                                   // 2441
    var assertCallsAndListeners =                                                                                     // 2442
          function (a_calls, b_calls, a_listeners, b_listeners) {                                                     // 2443
            test.equal('A calls: ' + Acalls.length,                                                                   // 2444
                       'A calls: ' + a_calls,                                                                         // 2445
                       Acalls);                                                                                       // 2446
            test.equal('B calls: ' + Bcalls,                                                                          // 2447
                       'B calls: ' + b_calls);                                                                        // 2448
            test.equal('A listeners: ' + A.numListeners(),                                                            // 2449
                       'A listeners: ' + a_listeners);                                                                // 2450
            test.equal('B listeners: ' + B.numListeners(),                                                            // 2451
                       'B listeners: ' + b_listeners);                                                                // 2452
            Acalls = '';                                                                                              // 2453
            Bcalls = 0;                                                                                               // 2454
          };                                                                                                          // 2455
                                                                                                                      // 2456
    var div = renderToDiv(tmpl);                                                                                      // 2457
    assertCallsAndListeners(10, 1, 10, 1);                                                                            // 2458
    A.set('');                                                                                                        // 2459
    Deps.flush();                                                                                                     // 2460
    // Confirm that #4, #5, #6, and #9 are not re-run.                                                                // 2461
    // #a is newly run, for a total of 10 - 4 + 1 = 7,                                                                // 2462
    assertCallsAndListeners(7, 0, 7, 1);                                                                              // 2463
    A.set('hi');                                                                                                      // 2464
    Deps.flush();                                                                                                     // 2465
    assertCallsAndListeners(10, 0, 10, 1);                                                                            // 2466
                                                                                                                      // 2467
    // Now see that removing the DOM with jQuery, below                                                               // 2468
    // the level of the entire template, stops everything.                                                            // 2469
    $(div.querySelector('.toremove')).remove();                                                                       // 2470
    assertCallsAndListeners(0, 0, 0, 0);                                                                              // 2471
  });                                                                                                                 // 2472
                                                                                                                      // 2473
Tinytest.add(                                                                                                         // 2474
  "spacebars-tests - template_tests - focus/blur with clean-up",                                                      // 2475
  function (test) {                                                                                                   // 2476
    var tmpl = Template.spacebars_test_focus_blur_outer;                                                              // 2477
    var cond = ReactiveVar(true);                                                                                     // 2478
    tmpl.cond = function () {                                                                                         // 2479
      return cond.get();                                                                                              // 2480
    };                                                                                                                // 2481
    var buf = [];                                                                                                     // 2482
    Template.spacebars_test_focus_blur_inner.events({                                                                 // 2483
      'focus input': function () {                                                                                    // 2484
        buf.push('FOCUS');                                                                                            // 2485
      },                                                                                                              // 2486
      'blur input': function () {                                                                                     // 2487
        buf.push('BLUR');                                                                                             // 2488
      }                                                                                                               // 2489
    });                                                                                                               // 2490
                                                                                                                      // 2491
    var div = renderToDiv(tmpl);                                                                                      // 2492
    document.body.appendChild(div);                                                                                   // 2493
                                                                                                                      // 2494
    // check basic focus and blur to make sure                                                                        // 2495
    // everything is sane                                                                                             // 2496
    test.equal(div.querySelectorAll('input').length, 1);                                                              // 2497
    var input;                                                                                                        // 2498
    focusElement(input = div.querySelector('input'));                                                                 // 2499
    // We don't get focus events when the Chrome Dev Tools are focused,                                               // 2500
    // unfortunately, as of Chrome 35.  I think this is a regression in                                               // 2501
    // Chrome 34.  So, the goal is to work whether or not focus is                                                    // 2502
    // "borken," where "working" means always failing if DOMBackend isn't                                             // 2503
    // correctly unbinding the old event handlers when we switch the IF,                                              // 2504
    // and always passing if it is.  To cause the problem in DOMBackend,                                              // 2505
    // delete the '**' argument to jQuery#off in                                                                      // 2506
    // DOMBackend.Events.undelegateEvents.  The only compromise we are                                                // 2507
    // making here is that if some unrelated bug in Blaze makes                                                       // 2508
    // focus/blur not work, the failure might be masked while the Dev                                                 // 2509
    // Tools are open.                                                                                                // 2510
    var borken = false;                                                                                               // 2511
    if (buf.length === 0 && document.activeElement === input) {                                                       // 2512
      test.ok({note:"You might need to defocus the Chrome Dev Tools to get a more accurate run of this test!"});      // 2513
      borken = true;                                                                                                  // 2514
      $(input).trigger('focus');                                                                                      // 2515
    }                                                                                                                 // 2516
    test.equal(buf.join(), 'FOCUS');                                                                                  // 2517
    blurElement(div.querySelector('input'));                                                                          // 2518
    if (buf.length === 1)                                                                                             // 2519
      $(input).trigger('blur');                                                                                       // 2520
    test.equal(buf.join(), 'FOCUS,BLUR');                                                                             // 2521
                                                                                                                      // 2522
    // now switch the IF and check again.  The failure mode                                                           // 2523
    // we observed was that DOMBackend would not correctly                                                            // 2524
    // unbind the old event listener at the jQuery level,                                                             // 2525
    // so the old event listener would fire and cause an                                                              // 2526
    // exception inside Blaze ("Must be attached" in                                                                  // 2527
    // DOMRange#containsElement), which would show up in                                                              // 2528
    // the console and cause our handler not to fire.                                                                 // 2529
    cond.set(false);                                                                                                  // 2530
    buf.length = 0;                                                                                                   // 2531
    Deps.flush();                                                                                                     // 2532
    test.equal(div.querySelectorAll('input').length, 1);                                                              // 2533
    focusElement(input = div.querySelector('input'));                                                                 // 2534
    if (borken)                                                                                                       // 2535
      $(input).trigger('focus');                                                                                      // 2536
    test.equal(buf.join(), 'FOCUS');                                                                                  // 2537
    blurElement(div.querySelector('input'));                                                                          // 2538
    if (! borken)                                                                                                     // 2539
      test.equal(buf.join(), 'FOCUS,BLUR');                                                                           // 2540
                                                                                                                      // 2541
    document.body.removeChild(div);                                                                                   // 2542
  });                                                                                                                 // 2543
                                                                                                                      // 2544
// We used to remove event handlers on DOMRange detached, but when                                                    // 2545
// tearing down a view, we don't "detach" all the DOMRanges recursively.                                              // 2546
// Mainly, we destroy the View.  Destroying a View should remove its                                                  // 2547
// event listeners.  (In practice, however, it's hard to think of                                                     // 2548
// consequences to not removing event handlers on removed DOM nodes,                                                  // 2549
// which will probably be GCed anyway.)                                                                               // 2550
Tinytest.add(                                                                                                         // 2551
  "spacebars-tests - template_tests - event cleanup on destroyed",                                                    // 2552
  function (test) {                                                                                                   // 2553
    var tmpl = Template.spacebars_test_event_cleanup_on_destroyed_outer;                                              // 2554
    var cond = ReactiveVar(true);                                                                                     // 2555
    tmpl.cond = function () {                                                                                         // 2556
      return cond.get();                                                                                              // 2557
    };                                                                                                                // 2558
                                                                                                                      // 2559
    Template.spacebars_test_event_cleanup_on_destroyed_inner.events({                                                 // 2560
      'click span': function () {}});                                                                                 // 2561
                                                                                                                      // 2562
    var div = renderToDiv(tmpl);                                                                                      // 2563
    document.body.appendChild(div);                                                                                   // 2564
                                                                                                                      // 2565
    var eventDiv = div.querySelector('div');                                                                          // 2566
    test.equal(eventDiv.$blaze_events.click.handlers.length, 1);                                                      // 2567
                                                                                                                      // 2568
    cond.set(false);                                                                                                  // 2569
    Deps.flush();                                                                                                     // 2570
    test.equal(eventDiv.$blaze_events.click.handlers.length, 0);                                                      // 2571
                                                                                                                      // 2572
    document.body.removeChild(div);                                                                                   // 2573
  });                                                                                                                 // 2574
                                                                                                                      // 2575
_.each([1, 2, 3], function (n) {                                                                                      // 2576
  Tinytest.add(                                                                                                       // 2577
    "spacebars-tests - template_tests - lookup is isolated " + n,                                                     // 2578
    function (test) {                                                                                                 // 2579
      var buf = "";                                                                                                   // 2580
      var inclusion = Template.spacebars_test_isolated_lookup_inclusion;                                              // 2581
      inclusion.created = function () { buf += 'C'; };                                                                // 2582
      inclusion.destroyed = function () { buf += 'D'; };                                                              // 2583
                                                                                                                      // 2584
      var tmpl = Template['spacebars_test_isolated_lookup' + n];                                                      // 2585
      var R = ReactiveVar(Template.spacebars_template_test_aaa);                                                      // 2586
                                                                                                                      // 2587
      tmpl.bar = function () {                                                                                        // 2588
        return R.get();                                                                                               // 2589
      };                                                                                                              // 2590
                                                                                                                      // 2591
      var div = renderToDiv(                                                                                          // 2592
        tmpl,                                                                                                         // 2593
        function () {                                                                                                 // 2594
          return { foo: R.get() };                                                                                    // 2595
        });                                                                                                           // 2596
                                                                                                                      // 2597
      test.equal(canonicalizeHtml(div.innerHTML), 'aaa--x');                                                          // 2598
      test.equal(buf, 'C');                                                                                           // 2599
      R.set(Template.spacebars_template_test_bbb);                                                                    // 2600
      Deps.flush();                                                                                                   // 2601
      test.equal(canonicalizeHtml(div.innerHTML), 'bbb--x');                                                          // 2602
      test.equal(buf, 'C');                                                                                           // 2603
    }                                                                                                                 // 2604
  );                                                                                                                  // 2605
});                                                                                                                   // 2606
                                                                                                                      // 2607
Tinytest.add('spacebars-tests - template_tests - current view in event handler', function (test) {                    // 2608
  var tmpl = Template.spacebars_test_current_view_in_event;                                                           // 2609
                                                                                                                      // 2610
  var currentView;                                                                                                    // 2611
  var currentData;                                                                                                    // 2612
                                                                                                                      // 2613
  tmpl.events({                                                                                                       // 2614
    'click span': function () {                                                                                       // 2615
      currentView = Blaze.getCurrentView();                                                                           // 2616
      currentData = Blaze.getCurrentData();                                                                           // 2617
    }                                                                                                                 // 2618
  });                                                                                                                 // 2619
                                                                                                                      // 2620
  var div = renderToDiv(tmpl, 'blah');                                                                                // 2621
  test.equal(canonicalizeHtml(div.innerHTML), '<span>blah</span>');                                                   // 2622
  document.body.appendChild(div);                                                                                     // 2623
  clickElement(div.querySelector('span'));                                                                            // 2624
  $(div).remove();                                                                                                    // 2625
                                                                                                                      // 2626
  test.isTrue(currentView);                                                                                           // 2627
  test.equal(currentData, 'blah');                                                                                    // 2628
});                                                                                                                   // 2629
                                                                                                                      // 2630
                                                                                                                      // 2631
Tinytest.add(                                                                                                         // 2632
  "spacebars-tests - template_tests - textarea attrs", function (test) {                                              // 2633
    var tmplNoContents = {                                                                                            // 2634
      tmpl: Template.spacebars_test_textarea_attrs,                                                                   // 2635
      hasTextAreaContents: false                                                                                      // 2636
    };                                                                                                                // 2637
    var tmplWithContents = {                                                                                          // 2638
      tmpl: Template.spacebars_test_textarea_attrs_contents,                                                          // 2639
      hasTextAreaContents: true                                                                                       // 2640
    };                                                                                                                // 2641
    var tmplWithContentsAndMoreAttrs = {                                                                              // 2642
      tmpl: Template.spacebars_test_textarea_attrs_array_contents,                                                    // 2643
      hasTextAreaContents: true                                                                                       // 2644
    };                                                                                                                // 2645
                                                                                                                      // 2646
    _.each(                                                                                                           // 2647
      [tmplNoContents, tmplWithContents,                                                                              // 2648
       tmplWithContentsAndMoreAttrs],                                                                                 // 2649
      function (tmplInfo) {                                                                                           // 2650
                                                                                                                      // 2651
        var id = new ReactiveVar("textarea-" + Random.id());                                                          // 2652
        var name = new ReactiveVar("one");                                                                            // 2653
        var attrs = new ReactiveVar({                                                                                 // 2654
          id: "textarea-" + Random.id()                                                                               // 2655
        });                                                                                                           // 2656
                                                                                                                      // 2657
        var div = renderToDiv(tmplInfo.tmpl, {                                                                        // 2658
          attrs: function () {                                                                                        // 2659
            return attrs.get();                                                                                       // 2660
          },                                                                                                          // 2661
          name: function () {                                                                                         // 2662
            return name.get();                                                                                        // 2663
          }                                                                                                           // 2664
        });                                                                                                           // 2665
                                                                                                                      // 2666
        // Check that the id and value attribute are as we expect.                                                    // 2667
        // We can't check div.innerHTML because Chrome at least doesn't                                               // 2668
        // appear to put textarea value attributes in innerHTML.                                                      // 2669
        var textarea = div.querySelector("textarea");                                                                 // 2670
        test.equal(textarea.id, attrs.get().id);                                                                      // 2671
        test.equal(                                                                                                   // 2672
          textarea.value, tmplInfo.hasTextAreaContents ? "Hello one" : "");                                           // 2673
        // One of the templates has a separate attribute in addition to                                               // 2674
        // an attributes dictionary.                                                                                  // 2675
        if (tmplInfo === tmplWithContentsAndMoreAttrs) {                                                              // 2676
          test.equal($(textarea).attr("class"), "bar");                                                               // 2677
        }                                                                                                             // 2678
                                                                                                                      // 2679
        // Change the id, check that the attribute updates reactively.                                                // 2680
        attrs.set({ id: "textarea-" + Random.id() });                                                                 // 2681
        Deps.flush();                                                                                                 // 2682
        test.equal(textarea.id, attrs.get().id);                                                                      // 2683
                                                                                                                      // 2684
        // Change the name variable, check that the textarea value                                                    // 2685
        // updates reactively.                                                                                        // 2686
        name.set("two");                                                                                              // 2687
        Deps.flush();                                                                                                 // 2688
        test.equal(                                                                                                   // 2689
          textarea.value, tmplInfo.hasTextAreaContents ? "Hello two" : "");                                           // 2690
                                                                                                                      // 2691
        if (tmplInfo === tmplWithContentsAndMoreAttrs) {                                                              // 2692
          test.equal($(textarea).attr("class"), "bar");                                                               // 2693
        }                                                                                                             // 2694
                                                                                                                      // 2695
      });                                                                                                             // 2696
                                                                                                                      // 2697
  });                                                                                                                 // 2698
                                                                                                                      // 2699
Tinytest.add(                                                                                                         // 2700
  "spacebars-tests - template_tests - this.autorun",                                                                  // 2701
  function (test) {                                                                                                   // 2702
    var tmpl = Template.spacebars_test_autorun;                                                                       // 2703
    var tmplInner = Template.spacebars_test_autorun_inner;                                                            // 2704
                                                                                                                      // 2705
    // Keep track of the value of `UI._templateInstance()` inside the                                                 // 2706
    // autorun each time it runs.                                                                                     // 2707
    var autorunTemplateInstances = [];                                                                                // 2708
    var actualTemplateInstance;                                                                                       // 2709
    var returnedComputation;                                                                                          // 2710
    var computationArg;                                                                                               // 2711
                                                                                                                      // 2712
    var show = new ReactiveVar(true);                                                                                 // 2713
    var rv = new ReactiveVar("foo");                                                                                  // 2714
                                                                                                                      // 2715
    tmplInner.created = function () {                                                                                 // 2716
      actualTemplateInstance = this;                                                                                  // 2717
      returnedComputation = this.autorun(function (c) {                                                               // 2718
        computationArg = c;                                                                                           // 2719
        rv.get();                                                                                                     // 2720
        autorunTemplateInstances.push(UI._templateInstance());                                                        // 2721
      });                                                                                                             // 2722
    };                                                                                                                // 2723
                                                                                                                      // 2724
    tmpl.helpers({                                                                                                    // 2725
      show: function () {                                                                                             // 2726
        return show.get();                                                                                            // 2727
      }                                                                                                               // 2728
    });                                                                                                               // 2729
                                                                                                                      // 2730
    var div = renderToDiv(tmpl);                                                                                      // 2731
    test.equal(autorunTemplateInstances.length, 1);                                                                   // 2732
    test.equal(autorunTemplateInstances[0], actualTemplateInstance);                                                  // 2733
                                                                                                                      // 2734
    // Test that the autorun returned a computation and received a                                                    // 2735
    // computation as an argument.                                                                                    // 2736
    test.isTrue(returnedComputation instanceof Deps.Computation);                                                     // 2737
    test.equal(returnedComputation, computationArg);                                                                  // 2738
                                                                                                                      // 2739
    // Make sure the autorun re-runs when `rv` changes, and that it has                                               // 2740
    // the correct current view.                                                                                      // 2741
    rv.set("bar");                                                                                                    // 2742
    Deps.flush();                                                                                                     // 2743
    test.equal(autorunTemplateInstances.length, 2);                                                                   // 2744
    test.equal(autorunTemplateInstances[1], actualTemplateInstance);                                                  // 2745
                                                                                                                      // 2746
    // If the inner template is destroyed, the autorun should be stopped.                                             // 2747
    show.set(false);                                                                                                  // 2748
    Deps.flush();                                                                                                     // 2749
    rv.set("baz");                                                                                                    // 2750
    Deps.flush();                                                                                                     // 2751
                                                                                                                      // 2752
    test.equal(autorunTemplateInstances.length, 2);                                                                   // 2753
    test.equal(rv.numListeners(), 0);                                                                                 // 2754
  }                                                                                                                   // 2755
);                                                                                                                    // 2756
                                                                                                                      // 2757
// Test that argument in {{> UI.contentBlock arg}} is evaluated in                                                    // 2758
// the proper data context.                                                                                           // 2759
Tinytest.add(                                                                                                         // 2760
  "spacebars-tests - template_tests - contentBlock argument",                                                         // 2761
  function (test) {                                                                                                   // 2762
    var tmpl = Template.spacebars_test_contentBlock_arg;                                                              // 2763
    var div = renderToDiv(tmpl);                                                                                      // 2764
    test.equal(canonicalizeHtml(div.innerHTML), 'AAA BBB');                                                           // 2765
  });                                                                                                                 // 2766
                                                                                                                      // 2767
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/spacebars-tests/template.templating_tests.js                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__define__("test_assembly_a0", (function() {                                                                 // 2
  var view = this;                                                                                                    // 3
  return Spacebars.include(view.lookupTemplate("test_assembly_a1"));                                                  // 4
}));                                                                                                                  // 5
                                                                                                                      // 6
Template.__define__("test_assembly_a1", (function() {                                                                 // 7
  var view = this;                                                                                                    // 8
  return Spacebars.include(view.lookupTemplate("test_assembly_a2"));                                                  // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__define__("test_assembly_a2", (function() {                                                                 // 12
  var view = this;                                                                                                    // 13
  return Spacebars.include(view.lookupTemplate("test_assembly_a3"));                                                  // 14
}));                                                                                                                  // 15
                                                                                                                      // 16
Template.__define__("test_assembly_a3", (function() {                                                                 // 17
  var view = this;                                                                                                    // 18
  return "Hi";                                                                                                        // 19
}));                                                                                                                  // 20
                                                                                                                      // 21
Template.__define__("test_assembly_b0", (function() {                                                                 // 22
  var view = this;                                                                                                    // 23
  return Spacebars.include(view.lookupTemplate("test_assembly_b1"));                                                  // 24
}));                                                                                                                  // 25
                                                                                                                      // 26
Template.__define__("test_assembly_b1", (function() {                                                                 // 27
  var view = this;                                                                                                    // 28
  return [ "x", Blaze.If(function() {                                                                                 // 29
    return Spacebars.call(view.lookup("stuff"));                                                                      // 30
  }, function() {                                                                                                     // 31
    return "y";                                                                                                       // 32
  }), Spacebars.include(view.lookupTemplate("test_assembly_b2")) ];                                                   // 33
}));                                                                                                                  // 34
                                                                                                                      // 35
Template.__define__("test_assembly_b2", (function() {                                                                 // 36
  var view = this;                                                                                                    // 37
  return "hi";                                                                                                        // 38
}));                                                                                                                  // 39
                                                                                                                      // 40
Template.__define__("test_table_b0", (function() {                                                                    // 41
  var view = this;                                                                                                    // 42
  return HTML.TABLE("\n    ", HTML.TBODY("\n      ", Spacebars.include(view.lookupTemplate("test_table_b1")), "\n      ", Spacebars.include(view.lookupTemplate("test_table_b1")), "\n      ", Spacebars.include(view.lookupTemplate("test_table_b1")), "\n    "), "\n  ");
}));                                                                                                                  // 44
                                                                                                                      // 45
Template.__define__("test_table_b1", (function() {                                                                    // 46
  var view = this;                                                                                                    // 47
  return HTML.TR("\n    ", Spacebars.include(view.lookupTemplate("test_table_b2")), "\n  ");                          // 48
}));                                                                                                                  // 49
                                                                                                                      // 50
Template.__define__("test_table_b2", (function() {                                                                    // 51
  var view = this;                                                                                                    // 52
  return HTML.TD("\n    ", Spacebars.include(view.lookupTemplate("test_table_b3")), "\n  ");                          // 53
}));                                                                                                                  // 54
                                                                                                                      // 55
Template.__define__("test_table_b3", (function() {                                                                    // 56
  var view = this;                                                                                                    // 57
  return "Foo.";                                                                                                      // 58
}));                                                                                                                  // 59
                                                                                                                      // 60
Template.__define__("test_table_each", (function() {                                                                  // 61
  var view = this;                                                                                                    // 62
  return HTML.TABLE("\n    ", HTML.TBODY("\n      ", Blaze.Each(function() {                                          // 63
    return Spacebars.call(view.lookup("foo"));                                                                        // 64
  }, function() {                                                                                                     // 65
    return [ "\n        ", HTML.TR(HTML.TD(Blaze.View(function() {                                                    // 66
      return Spacebars.mustache(view.lookup("bar"));                                                                  // 67
    }))), "\n      " ];                                                                                               // 68
  }), "\n    "), "\n  ");                                                                                             // 69
}));                                                                                                                  // 70
                                                                                                                      // 71
Template.__define__("test_event_data_with", (function() {                                                             // 72
  var view = this;                                                                                                    // 73
  return HTML.DIV("\n  xxx\n  ", Spacebars.With(function() {                                                          // 74
    return Spacebars.call(view.lookup("TWO"));                                                                        // 75
  }, function() {                                                                                                     // 76
    return [ "\n    ", HTML.DIV("\n      xxx\n      ", Spacebars.With(function() {                                    // 77
      return Spacebars.call(view.lookup("THREE"));                                                                    // 78
    }, function() {                                                                                                   // 79
      return [ "\n        ", HTML.DIV("\n          xxx\n        "), "\n      " ];                                     // 80
    }), "\n    "), "\n  " ];                                                                                          // 81
  }), "\n");                                                                                                          // 82
}));                                                                                                                  // 83
                                                                                                                      // 84
Template.__define__("test_capture_events", (function() {                                                              // 85
  var view = this;                                                                                                    // 86
  return HTML.Raw('<video class="video1">\n    <source id="mp4" src="http://media.w3.org/2010/05/sintel/trailer.mp4" type="video/mp4">\n  </video>\n  <video class="video2">\n    <source id="mp4" src="http://media.w3.org/2010/05/sintel/trailer.mp4" type="video/mp4">\n  </video>\n  <video class="video2">\n    <source id="mp4" src="http://media.w3.org/2010/05/sintel/trailer.mp4" type="video/mp4">\n  </video>');
}));                                                                                                                  // 88
                                                                                                                      // 89
Template.__define__("test_safestring_a", (function() {                                                                // 90
  var view = this;                                                                                                    // 91
  return [ Blaze.View(function() {                                                                                    // 92
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 93
  }), " ", Blaze.View(function() {                                                                                    // 94
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("foo")));                                                 // 95
  }), " ", Blaze.View(function() {                                                                                    // 96
    return Spacebars.mustache(view.lookup("bar"));                                                                    // 97
  }), " ", Blaze.View(function() {                                                                                    // 98
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("bar")));                                                 // 99
  }), "\n  ", Blaze.View(function() {                                                                                 // 100
    return Spacebars.mustache(view.lookup("fooprop"));                                                                // 101
  }), " ", Blaze.View(function() {                                                                                    // 102
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("fooprop")));                                             // 103
  }), " ", Blaze.View(function() {                                                                                    // 104
    return Spacebars.mustache(view.lookup("barprop"));                                                                // 105
  }), " ", Blaze.View(function() {                                                                                    // 106
    return Spacebars.makeRaw(Spacebars.mustache(view.lookup("barprop")));                                             // 107
  }) ];                                                                                                               // 108
}));                                                                                                                  // 109
                                                                                                                      // 110
Template.__define__("test_helpers_a", (function() {                                                                   // 111
  var view = this;                                                                                                    // 112
  return [ "platypus=", Blaze.View(function() {                                                                       // 113
    return Spacebars.mustache(view.lookup("platypus"));                                                               // 114
  }), "\n  watermelon=", Blaze.View(function() {                                                                      // 115
    return Spacebars.mustache(view.lookup("watermelon"));                                                             // 116
  }), "\n  daisy=", Blaze.View(function() {                                                                           // 117
    return Spacebars.mustache(view.lookup("daisy"));                                                                  // 118
  }), "\n  tree=", Blaze.View(function() {                                                                            // 119
    return Spacebars.mustache(view.lookup("tree"));                                                                   // 120
  }), "\n  warthog=", Blaze.View(function() {                                                                         // 121
    return Spacebars.mustache(view.lookup("warthog"));                                                                // 122
  }) ];                                                                                                               // 123
}));                                                                                                                  // 124
                                                                                                                      // 125
Template.__define__("test_helpers_b", (function() {                                                                   // 126
  var view = this;                                                                                                    // 127
  return [ "unknown=", Blaze.View(function() {                                                                        // 128
    return Spacebars.mustache(view.lookup("unknown"));                                                                // 129
  }), "\n  zero=", Blaze.View(function() {                                                                            // 130
    return Spacebars.mustache(view.lookup("zero"));                                                                   // 131
  }) ];                                                                                                               // 132
}));                                                                                                                  // 133
                                                                                                                      // 134
Template.__define__("test_helpers_c", (function() {                                                                   // 135
  var view = this;                                                                                                    // 136
  return [ "platypus.X=", Blaze.View(function() {                                                                     // 137
    return Spacebars.mustache(Spacebars.dot(view.lookup("platypus"), "X"));                                           // 138
  }), "\n  watermelon.X=", Blaze.View(function() {                                                                    // 139
    return Spacebars.mustache(Spacebars.dot(view.lookup("watermelon"), "X"));                                         // 140
  }), "\n  daisy.X=", Blaze.View(function() {                                                                         // 141
    return Spacebars.mustache(Spacebars.dot(view.lookup("daisy"), "X"));                                              // 142
  }), "\n  tree.X=", Blaze.View(function() {                                                                          // 143
    return Spacebars.mustache(Spacebars.dot(view.lookup("tree"), "X"));                                               // 144
  }), "\n  warthog.X=", Blaze.View(function() {                                                                       // 145
    return Spacebars.mustache(Spacebars.dot(view.lookup("warthog"), "X"));                                            // 146
  }), "\n  getNull.X=", Blaze.View(function() {                                                                       // 147
    return Spacebars.mustache(Spacebars.dot(view.lookup("getNull"), "X"));                                            // 148
  }), "\n  getUndefined.X=", Blaze.View(function() {                                                                  // 149
    return Spacebars.mustache(Spacebars.dot(view.lookup("getUndefined"), "X"));                                       // 150
  }), "\n  getUndefined.X.Y=", Blaze.View(function() {                                                                // 151
    return Spacebars.mustache(Spacebars.dot(view.lookup("getUndefined"), "X", "Y"));                                  // 152
  }) ];                                                                                                               // 153
}));                                                                                                                  // 154
                                                                                                                      // 155
Template.__define__("test_helpers_d", (function() {                                                                   // 156
  var view = this;                                                                                                    // 157
  return [ "daisygetter=", Blaze.View(function() {                                                                    // 158
    return Spacebars.mustache(view.lookup("daisygetter"));                                                            // 159
  }), "\n  thisTest=", Blaze.View(function() {                                                                        // 160
    return Spacebars.mustache(view.lookup("thisTest"));                                                               // 161
  }), "\n  ", Spacebars.With(function() {                                                                             // 162
    return Spacebars.call(view.lookup("fancy"));                                                                      // 163
  }, function() {                                                                                                     // 164
    return [ "\n    ../thisTest=", Blaze.View(function() {                                                            // 165
      return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "thisTest"));                                        // 166
    }), "\n  " ];                                                                                                     // 167
  }), "\n  ", Spacebars.With(function() {                                                                             // 168
    return "foo";                                                                                                     // 169
  }, function() {                                                                                                     // 170
    return [ "\n    ../fancy.currentFruit=", Blaze.View(function() {                                                  // 171
      return Spacebars.mustache(Spacebars.dot(view.lookup(".."), "fancy", "currentFruit"));                           // 172
    }), "\n  " ];                                                                                                     // 173
  }) ];                                                                                                               // 174
}));                                                                                                                  // 175
                                                                                                                      // 176
Template.__define__("test_helpers_e", (function() {                                                                   // 177
  var view = this;                                                                                                    // 178
  return [ "fancy.foo=", Blaze.View(function() {                                                                      // 179
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "foo"));                                            // 180
  }), "\n  fancy.apple.banana=", Blaze.View(function() {                                                              // 181
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "apple", "banana"));                                // 182
  }), "\n  fancy.currentFruit=", Blaze.View(function() {                                                              // 183
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "currentFruit"));                                   // 184
  }), "\n  fancy.currentCountry.name=", Blaze.View(function() {                                                       // 185
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "currentCountry", "name"));                         // 186
  }), "\n  fancy.currentCountry.population=", Blaze.View(function() {                                                 // 187
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "currentCountry", "population"));                   // 188
  }), "\n  fancy.currentCountry.unicorns=", Blaze.View(function() {                                                   // 189
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancy"), "currentCountry", "unicorns"));                     // 190
  }) ];                                                                                                               // 191
}));                                                                                                                  // 192
                                                                                                                      // 193
Template.__define__("test_helpers_f", (function() {                                                                   // 194
  var view = this;                                                                                                    // 195
  return [ "fancyhelper.foo=", Blaze.View(function() {                                                                // 196
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "foo"));                                      // 197
  }), "\n  fancyhelper.apple.banana=", Blaze.View(function() {                                                        // 198
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "apple", "banana"));                          // 199
  }), "\n  fancyhelper.currentFruit=", Blaze.View(function() {                                                        // 200
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"));                             // 201
  }), "\n  fancyhelper.currentCountry.name=", Blaze.View(function() {                                                 // 202
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "name"));                   // 203
  }), "\n  fancyhelper.currentCountry.population=", Blaze.View(function() {                                           // 204
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "population"));             // 205
  }), "\n  fancyhelper.currentCountry.unicorns=", Blaze.View(function() {                                             // 206
    return Spacebars.mustache(Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns"));               // 207
  }) ];                                                                                                               // 208
}));                                                                                                                  // 209
                                                                                                                      // 210
Template.__define__("test_helpers_g", (function() {                                                                   // 211
  var view = this;                                                                                                    // 212
  return [ "platypus=", Blaze.View(function() {                                                                       // 213
    return Spacebars.mustache(view.lookup("platypus"));                                                               // 214
  }), "\n  this.platypus=", Blaze.View(function() {                                                                   // 215
    return Spacebars.mustache(Spacebars.dot(view.lookup("."), "platypus"));                                           // 216
  }) ];                                                                                                               // 217
}));                                                                                                                  // 218
                                                                                                                      // 219
Template.__define__("test_helpers_h", (function() {                                                                   // 220
  var view = this;                                                                                                    // 221
  return [ "(methodListFour 6 7 8 9=", Blaze.View(function() {                                                        // 222
    return Spacebars.mustache(view.lookup("methodListFour"), 6, 7, 8, 9);                                             // 223
  }), ")\n  (methodListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns=", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("methodListFour"), view.lookup("platypus"), view.lookup("thisTest"), Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"), Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns"));
  }), ")\n  (methodListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns a=platypus b=thisTest c=fancyhelper.currentFruit d=fancyhelper.currentCountry.unicorns=", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("methodListFour"), view.lookup("platypus"), view.lookup("thisTest"), Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"), Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns"), Spacebars.kw({
      a: view.lookup("platypus"),                                                                                     // 228
      b: view.lookup("thisTest"),                                                                                     // 229
      c: Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"),                                                   // 230
      d: Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns")                                      // 231
    }));                                                                                                              // 232
  }), ")\n  (helperListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns=", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("helperListFour"), view.lookup("platypus"), view.lookup("thisTest"), Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"), Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns"));
  }), ")\n  (helperListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns a=platypus b=thisTest c=fancyhelper.currentFruit d=fancyhelper.currentCountry.unicorns=", Blaze.View(function() {
    return Spacebars.mustache(view.lookup("helperListFour"), view.lookup("platypus"), view.lookup("thisTest"), Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"), Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns"), Spacebars.kw({
      a: view.lookup("platypus"),                                                                                     // 237
      b: view.lookup("thisTest"),                                                                                     // 238
      c: Spacebars.dot(view.lookup("fancyhelper"), "currentFruit"),                                                   // 239
      d: Spacebars.dot(view.lookup("fancyhelper"), "currentCountry", "unicorns")                                      // 240
    }));                                                                                                              // 241
  }), ")" ];                                                                                                          // 242
}));                                                                                                                  // 243
                                                                                                                      // 244
Template.__define__("test_render_a", (function() {                                                                    // 245
  var view = this;                                                                                                    // 246
  return [ Blaze.View(function() {                                                                                    // 247
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 248
  }), HTML.Raw("<br><hr>") ];                                                                                         // 249
}));                                                                                                                  // 250
                                                                                                                      // 251
Template.__define__("test_render_b", (function() {                                                                    // 252
  var view = this;                                                                                                    // 253
  return Spacebars.With(function() {                                                                                  // 254
    return 200;                                                                                                       // 255
  }, function() {                                                                                                     // 256
    return [ Blaze.View(function() {                                                                                  // 257
      return Spacebars.mustache(view.lookup("foo"));                                                                  // 258
    }), HTML.BR(), HTML.HR() ];                                                                                       // 259
  });                                                                                                                 // 260
}));                                                                                                                  // 261
                                                                                                                      // 262
Template.__define__("test_render_c", (function() {                                                                    // 263
  var view = this;                                                                                                    // 264
  return HTML.Raw("<br><hr>");                                                                                        // 265
}));                                                                                                                  // 266
                                                                                                                      // 267
Template.__define__("test_template_arg_a", (function() {                                                              // 268
  var view = this;                                                                                                    // 269
  return HTML.Raw("<b>Foo</b> <i>Bar</i> <u>Baz</u>");                                                                // 270
}));                                                                                                                  // 271
                                                                                                                      // 272
Template.__define__("test_template_helpers_a", (function() {                                                          // 273
  var view = this;                                                                                                    // 274
  return [ Blaze.View(function() {                                                                                    // 275
    return Spacebars.mustache(view.lookup("foo"));                                                                    // 276
  }), Blaze.View(function() {                                                                                         // 277
    return Spacebars.mustache(view.lookup("bar"));                                                                    // 278
  }), Blaze.View(function() {                                                                                         // 279
    return Spacebars.mustache(view.lookup("baz"));                                                                    // 280
  }) ];                                                                                                               // 281
}));                                                                                                                  // 282
                                                                                                                      // 283
Template.__define__("test_template_helpers_b", (function() {                                                          // 284
  var view = this;                                                                                                    // 285
  return [ Blaze.View(function() {                                                                                    // 286
    return Spacebars.mustache(view.lookup("name"));                                                                   // 287
  }), Blaze.View(function() {                                                                                         // 288
    return Spacebars.mustache(view.lookup("arity"));                                                                  // 289
  }), Blaze.View(function() {                                                                                         // 290
    return Spacebars.mustache(view.lookup("toString"));                                                               // 291
  }), Blaze.View(function() {                                                                                         // 292
    return Spacebars.mustache(view.lookup("length"));                                                                 // 293
  }), Blaze.View(function() {                                                                                         // 294
    return Spacebars.mustache(view.lookup("var"));                                                                    // 295
  }) ];                                                                                                               // 296
}));                                                                                                                  // 297
                                                                                                                      // 298
Template.__define__("test_template_helpers_c", (function() {                                                          // 299
  var view = this;                                                                                                    // 300
  return [ Blaze.View(function() {                                                                                    // 301
    return Spacebars.mustache(view.lookup("name"));                                                                   // 302
  }), Blaze.View(function() {                                                                                         // 303
    return Spacebars.mustache(view.lookup("arity"));                                                                  // 304
  }), Blaze.View(function() {                                                                                         // 305
    return Spacebars.mustache(view.lookup("length"));                                                                 // 306
  }), Blaze.View(function() {                                                                                         // 307
    return Spacebars.mustache(view.lookup("var"));                                                                    // 308
  }), "x" ];                                                                                                          // 309
}));                                                                                                                  // 310
                                                                                                                      // 311
Template.__define__("test_template_events_a", (function() {                                                           // 312
  var view = this;                                                                                                    // 313
  return HTML.Raw("<b>foo</b><u>bar</u><i>baz</i>");                                                                  // 314
}));                                                                                                                  // 315
                                                                                                                      // 316
Template.__define__("test_template_events_b", (function() {                                                           // 317
  var view = this;                                                                                                    // 318
  return HTML.Raw("<b>foo</b><u>bar</u><i>baz</i>");                                                                  // 319
}));                                                                                                                  // 320
                                                                                                                      // 321
Template.__define__("test_template_events_c", (function() {                                                           // 322
  var view = this;                                                                                                    // 323
  return HTML.Raw("<b>foo</b><u>bar</u><i>baz</i>");                                                                  // 324
}));                                                                                                                  // 325
                                                                                                                      // 326
Template.__define__("test_type_casting", (function() {                                                                // 327
  var view = this;                                                                                                    // 328
  return Blaze.View(function() {                                                                                      // 329
    return Spacebars.mustache(view.lookup("testTypeCasting"), "true", "false", true, false, 0, 1, -1, 10, -10);       // 330
  });                                                                                                                 // 331
}));                                                                                                                  // 332
                                                                                                                      // 333
Template.__define__("test_template_issue801", (function() {                                                           // 334
  var view = this;                                                                                                    // 335
  return Blaze.Each(function() {                                                                                      // 336
    return Spacebars.call(view.lookup("values"));                                                                     // 337
  }, function() {                                                                                                     // 338
    return Blaze.View(function() {                                                                                    // 339
      return Spacebars.mustache(view.lookup("."));                                                                    // 340
    });                                                                                                               // 341
  });                                                                                                                 // 342
}));                                                                                                                  // 343
                                                                                                                      // 344
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/spacebars-tests/templating_tests.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
// for events to bubble an element needs to be in the DOM.                                                            // 2
// @return {Function} call this for cleanup                                                                           // 3
var addToBody = function (el) {                                                                                       // 4
  el.style.display = "none";                                                                                          // 5
  document.body.appendChild(el);                                                                                      // 6
  return function () {                                                                                                // 7
    document.body.removeChild(el);                                                                                    // 8
  };                                                                                                                  // 9
};                                                                                                                    // 10
                                                                                                                      // 11
                                                                                                                      // 12
Tinytest.add("spacebars-tests - templating_tests - assembly", function (test) {                                       // 13
                                                                                                                      // 14
  // Test for a bug that made it to production -- after a replacement,                                                // 15
  // we need to also check the newly replaced node for replacements                                                   // 16
  var div = renderToDiv(Template.test_assembly_a0);                                                                   // 17
  test.equal(canonicalizeHtml(div.innerHTML),                                                                         // 18
               "Hi");                                                                                                 // 19
                                                                                                                      // 20
  // Another production bug -- we must use LiveRange to replace the                                                   // 21
  // placeholder, or risk breaking other LiveRanges                                                                   // 22
  Session.set("stuff", true); // XXX bad form to use Session in a test?                                               // 23
  Template.test_assembly_b1.stuff = function () {                                                                     // 24
    return Session.get("stuff");                                                                                      // 25
  };                                                                                                                  // 26
  var onscreen = renderToDiv(Template.test_assembly_b0);                                                              // 27
  test.equal(canonicalizeHtml(onscreen.innerHTML), "xyhi");                                                           // 28
  Session.set("stuff", false);                                                                                        // 29
  Deps.flush();                                                                                                       // 30
  test.equal(canonicalizeHtml(onscreen.innerHTML), "xhi");                                                            // 31
  Deps.flush();                                                                                                       // 32
});                                                                                                                   // 33
                                                                                                                      // 34
// Test that if a template throws an error, then pending_partials is                                                  // 35
// cleaned up properly (that template rendering doesn't break..)                                                      // 36
                                                                                                                      // 37
                                                                                                                      // 38
                                                                                                                      // 39
                                                                                                                      // 40
                                                                                                                      // 41
                                                                                                                      // 42
Tinytest.add("spacebars-tests - templating_tests - table assembly", function(test) {                                  // 43
  var childWithTag = function(node, tag) {                                                                            // 44
    return _.find(node.childNodes, function(n) {                                                                      // 45
      return n.nodeName === tag;                                                                                      // 46
    });                                                                                                               // 47
  };                                                                                                                  // 48
                                                                                                                      // 49
  // The table.rows test would fail when TR/TD tags are stripped due                                                  // 50
  // to improper html-to-fragment                                                                                     // 51
  var table = childWithTag(renderToDiv(Template.test_table_b0), "TABLE");                                             // 52
  test.equal(table.rows.length, 3);                                                                                   // 53
                                                                                                                      // 54
  var c = new LocalCollection();                                                                                      // 55
  c.insert({bar:'a'});                                                                                                // 56
  c.insert({bar:'b'});                                                                                                // 57
  c.insert({bar:'c'});                                                                                                // 58
  var onscreen = renderToDiv(Template.test_table_each, {foo: c.find()});                                              // 59
  table = childWithTag(onscreen, "TABLE");                                                                            // 60
                                                                                                                      // 61
  test.equal(table.rows.length, 3, table.parentNode.innerHTML);                                                       // 62
  var tds = onscreen.getElementsByTagName("TD");                                                                      // 63
  test.equal(tds.length, 3);                                                                                          // 64
  test.equal(canonicalizeHtml(tds[0].innerHTML), "a");                                                                // 65
  test.equal(canonicalizeHtml(tds[1].innerHTML), "b");                                                                // 66
  test.equal(canonicalizeHtml(tds[2].innerHTML), "c");                                                                // 67
                                                                                                                      // 68
  Deps.flush();                                                                                                       // 69
});                                                                                                                   // 70
                                                                                                                      // 71
Tinytest.add("spacebars-tests - templating_tests - event handler this", function(test) {                              // 72
                                                                                                                      // 73
  Template.test_event_data_with.ONE = {str: "one"};                                                                   // 74
  Template.test_event_data_with.TWO = {str: "two"};                                                                   // 75
  Template.test_event_data_with.THREE = {str: "three"};                                                               // 76
                                                                                                                      // 77
  Template.test_event_data_with.events({                                                                              // 78
    'click': function(event, template) {                                                                              // 79
      test.isTrue(this.str);                                                                                          // 80
      test.equal(template.data.str, "one");                                                                           // 81
      event_buf.push(this.str);                                                                                       // 82
    }                                                                                                                 // 83
  });                                                                                                                 // 84
                                                                                                                      // 85
  var event_buf = [];                                                                                                 // 86
  var containerDiv = renderToDiv(Template.test_event_data_with,                                                       // 87
                                 Template.test_event_data_with.ONE);                                                  // 88
  var cleanupDiv = addToBody(containerDiv);                                                                           // 89
                                                                                                                      // 90
  var divs = containerDiv.getElementsByTagName("div");                                                                // 91
  test.equal(3, divs.length);                                                                                         // 92
                                                                                                                      // 93
  clickElement(divs[0]);                                                                                              // 94
  test.equal(event_buf, ['one']);                                                                                     // 95
  event_buf.length = 0;                                                                                               // 96
                                                                                                                      // 97
  clickElement(divs[1]);                                                                                              // 98
  test.equal(event_buf, ['two']);                                                                                     // 99
  event_buf.length = 0;                                                                                               // 100
                                                                                                                      // 101
  clickElement(divs[2]);                                                                                              // 102
  test.equal(event_buf, ['three']);                                                                                   // 103
  event_buf.length = 0;                                                                                               // 104
                                                                                                                      // 105
  cleanupDiv();                                                                                                       // 106
  Deps.flush();                                                                                                       // 107
});                                                                                                                   // 108
                                                                                                                      // 109
                                                                                                                      // 110
if (document.addEventListener) {                                                                                      // 111
  // Only run this test on browsers with support for event                                                            // 112
  // capturing. A more detailed analysis can be found at                                                              // 113
  // https://www.meteor.com/blog/2013/09/06/browser-events-bubbling-capturing-and-delegation                          // 114
                                                                                                                      // 115
  // This is related to issue at https://gist.github.com/mquandalle/8157017                                           // 116
  // Tests two situations related to events that can only be captured, not bubbled:                                   // 117
  // 1. Event should only fire the handler that matches the selector given                                            // 118
  // 2. Event should work on every element in the selector and not just the first element                             // 119
  // This test isn't written against mouseenter because it is synthesized by jQuery,                                  // 120
  // the bug also happened with the play event                                                                        // 121
  Tinytest.add("spacebars-tests - templating_tests - capturing events", function (test) {                             // 122
    var video1Played = 0,                                                                                             // 123
        video2Played = 0;                                                                                             // 124
                                                                                                                      // 125
    Template.test_capture_events.events({                                                                             // 126
      'play .video1': function () {                                                                                   // 127
        video1Played++;                                                                                               // 128
      },                                                                                                              // 129
      'play .video2': function () {                                                                                   // 130
        video2Played++;                                                                                               // 131
      }                                                                                                               // 132
    });                                                                                                               // 133
                                                                                                                      // 134
    // add to body or else events don't actually fire                                                                 // 135
    var containerDiv = renderToDiv(Template.test_capture_events);                                                     // 136
    var cleanupDiv = addToBody(containerDiv);                                                                         // 137
                                                                                                                      // 138
    var checkAndResetEvents = function(video1, video2) {                                                              // 139
      test.equal(video1Played, video1);                                                                               // 140
      test.equal(video2Played, video2);                                                                               // 141
                                                                                                                      // 142
      video1Played = 0;                                                                                               // 143
      video2Played = 0;                                                                                               // 144
    };                                                                                                                // 145
                                                                                                                      // 146
    simulateEvent($(containerDiv).find(".video1").get(0),                                                             // 147
                  "play", {}, {bubbles: false});                                                                      // 148
    checkAndResetEvents(1, 0);                                                                                        // 149
                                                                                                                      // 150
    simulateEvent($(containerDiv).find(".video2").get(0),                                                             // 151
                  "play", {}, {bubbles: false});                                                                      // 152
    checkAndResetEvents(0, 1);                                                                                        // 153
                                                                                                                      // 154
    simulateEvent($(containerDiv).find(".video2").get(1),                                                             // 155
                  "play", {}, {bubbles: false});                                                                      // 156
    checkAndResetEvents(0, 1);                                                                                        // 157
                                                                                                                      // 158
    // clean up DOM                                                                                                   // 159
    cleanupDiv();                                                                                                     // 160
    Deps.flush();                                                                                                     // 161
  });                                                                                                                 // 162
}                                                                                                                     // 163
                                                                                                                      // 164
Tinytest.add("spacebars-tests - templating_tests - safestring", function(test) {                                      // 165
                                                                                                                      // 166
  Template.test_safestring_a.foo = function() {                                                                       // 167
    return "<br>";                                                                                                    // 168
  };                                                                                                                  // 169
  Template.test_safestring_a.bar = function() {                                                                       // 170
    return new Spacebars.SafeString("<hr>");                                                                          // 171
  };                                                                                                                  // 172
                                                                                                                      // 173
  var obj = {fooprop: "<br>",                                                                                         // 174
             barprop: new Spacebars.SafeString("<hr>")};                                                              // 175
  var html = canonicalizeHtml(                                                                                        // 176
    renderToDiv(Template.test_safestring_a, obj).innerHTML);                                                          // 177
                                                                                                                      // 178
  test.equal(html,                                                                                                    // 179
             "&lt;br&gt;<br><hr><hr>"+                                                                                // 180
             "&lt;br&gt;<br><hr><hr>");                                                                               // 181
                                                                                                                      // 182
});                                                                                                                   // 183
                                                                                                                      // 184
Tinytest.add("spacebars-tests - templating_tests - helpers and dots", function(test) {                                // 185
  UI.registerHelper("platypus", function() {                                                                          // 186
    return "eggs";                                                                                                    // 187
  });                                                                                                                 // 188
  UI.registerHelper("watermelon", function() {                                                                        // 189
    return "seeds";                                                                                                   // 190
  });                                                                                                                 // 191
                                                                                                                      // 192
  UI.registerHelper("daisygetter", function() {                                                                       // 193
    return this.daisy;                                                                                                // 194
  });                                                                                                                 // 195
                                                                                                                      // 196
  // XXX for debugging                                                                                                // 197
  UI.registerHelper("debugger", function() {                                                                          // 198
    debugger;                                                                                                         // 199
  });                                                                                                                 // 200
                                                                                                                      // 201
  var getFancyObject = function() {                                                                                   // 202
    return {                                                                                                          // 203
      foo: 'bar',                                                                                                     // 204
      apple: {banana: 'smoothie'},                                                                                    // 205
      currentFruit: function() {                                                                                      // 206
        return 'guava';                                                                                               // 207
      },                                                                                                              // 208
      currentCountry: function() {                                                                                    // 209
        return {name: 'Iceland',                                                                                      // 210
                _pop: 321007,                                                                                         // 211
                population: function() {                                                                              // 212
                  return this._pop;                                                                                   // 213
                },                                                                                                    // 214
                unicorns: 0, // falsy value                                                                           // 215
                daisyGetter: function() {                                                                             // 216
                  return this.daisy;                                                                                  // 217
                }                                                                                                     // 218
               };                                                                                                     // 219
      }                                                                                                               // 220
    };                                                                                                                // 221
  };                                                                                                                  // 222
                                                                                                                      // 223
  UI.registerHelper("fancyhelper", getFancyObject);                                                                   // 224
                                                                                                                      // 225
  Template.test_helpers_a.platypus = 'bill';                                                                          // 226
  Template.test_helpers_a.warthog = function() {                                                                      // 227
    return 'snout';                                                                                                   // 228
  };                                                                                                                  // 229
                                                                                                                      // 230
  var listFour = function(a, b, c, d, options) {                                                                      // 231
    test.isTrue(options instanceof Spacebars.kw);                                                                     // 232
    var keywordArgs = _.map(_.keys(options.hash), function(k) {                                                       // 233
      var val = options.hash[k];                                                                                      // 234
      return k+':'+val;                                                                                               // 235
    });                                                                                                               // 236
    return [a, b, c, d].concat(keywordArgs).join(' ');                                                                // 237
  };                                                                                                                  // 238
                                                                                                                      // 239
  var dataObj = {                                                                                                     // 240
    zero: 0,                                                                                                          // 241
    platypus: 'weird',                                                                                                // 242
    watermelon: 'rind',                                                                                               // 243
    daisy: 'petal',                                                                                                   // 244
    tree: function() { return 'leaf'; },                                                                              // 245
    thisTest: function() { return this.tree(); },                                                                     // 246
    getNull: function() { return null; },                                                                             // 247
    getUndefined: function () { return; },                                                                            // 248
    fancy: getFancyObject(),                                                                                          // 249
    methodListFour: listFour                                                                                          // 250
  };                                                                                                                  // 251
                                                                                                                      // 252
  var html;                                                                                                           // 253
  html = canonicalizeHtml(                                                                                            // 254
    renderToDiv(Template.test_helpers_a, dataObj).innerHTML);                                                         // 255
  test.equal(html.match(/\S+/g), [                                                                                    // 256
    'platypus=bill', // helpers on Template object take first priority                                                // 257
    'watermelon=seeds', // global helpers take second priority                                                        // 258
    'daisy=petal', // unshadowed object property                                                                      // 259
    'tree=leaf', // function object property                                                                          // 260
    'warthog=snout' // function Template property                                                                     // 261
  ]);                                                                                                                 // 262
                                                                                                                      // 263
  html = canonicalizeHtml(                                                                                            // 264
    renderToDiv(Template.test_helpers_b, dataObj).innerHTML);                                                         // 265
  test.equal(html.match(/\S+/g), [                                                                                    // 266
    // unknown properties silently fail                                                                               // 267
    'unknown=',                                                                                                       // 268
    // falsy property comes through                                                                                   // 269
    'zero=0'                                                                                                          // 270
  ]);                                                                                                                 // 271
                                                                                                                      // 272
  html = canonicalizeHtml(                                                                                            // 273
    renderToDiv(Template.test_helpers_c, dataObj).innerHTML);                                                         // 274
  test.equal(html.match(/\S+/g), [                                                                                    // 275
    // property gets are supposed to silently fail                                                                    // 276
    'platypus.X=',                                                                                                    // 277
    'watermelon.X=',                                                                                                  // 278
    'daisy.X=',                                                                                                       // 279
    'tree.X=',                                                                                                        // 280
    'warthog.X=',                                                                                                     // 281
    'getNull.X=',                                                                                                     // 282
    'getUndefined.X=',                                                                                                // 283
    'getUndefined.X.Y='                                                                                               // 284
  ]);                                                                                                                 // 285
                                                                                                                      // 286
  html = canonicalizeHtml(                                                                                            // 287
    renderToDiv(Template.test_helpers_d, dataObj).innerHTML);                                                         // 288
  test.equal(html.match(/\S+/g), [                                                                                    // 289
    // helpers should get current data context in `this`                                                              // 290
    'daisygetter=petal',                                                                                              // 291
    // object methods should get object in `this`                                                                     // 292
    'thisTest=leaf',                                                                                                  // 293
    // nesting inside {{#with fancy}} shouldn't affect                                                                // 294
    // method                                                                                                         // 295
    '../thisTest=leaf',                                                                                               // 296
    // combine .. and .                                                                                               // 297
    '../fancy.currentFruit=guava'                                                                                     // 298
  ]);                                                                                                                 // 299
                                                                                                                      // 300
  html = canonicalizeHtml(                                                                                            // 301
    renderToDiv(Template.test_helpers_e, dataObj).innerHTML);                                                         // 302
  test.equal(html.match(/\S+/g), [                                                                                    // 303
    'fancy.foo=bar',                                                                                                  // 304
    'fancy.apple.banana=smoothie',                                                                                    // 305
    'fancy.currentFruit=guava',                                                                                       // 306
    'fancy.currentCountry.name=Iceland',                                                                              // 307
    'fancy.currentCountry.population=321007',                                                                         // 308
    'fancy.currentCountry.unicorns=0'                                                                                 // 309
  ]);                                                                                                                 // 310
                                                                                                                      // 311
  html = canonicalizeHtml(                                                                                            // 312
    renderToDiv(Template.test_helpers_f, dataObj).innerHTML);                                                         // 313
  test.equal(html.match(/\S+/g), [                                                                                    // 314
    'fancyhelper.foo=bar',                                                                                            // 315
    'fancyhelper.apple.banana=smoothie',                                                                              // 316
    'fancyhelper.currentFruit=guava',                                                                                 // 317
    'fancyhelper.currentCountry.name=Iceland',                                                                        // 318
    'fancyhelper.currentCountry.population=321007',                                                                   // 319
    'fancyhelper.currentCountry.unicorns=0'                                                                           // 320
  ]);                                                                                                                 // 321
                                                                                                                      // 322
  // test significance of 'this', which prevents helper from                                                          // 323
  // shadowing property                                                                                               // 324
  html = canonicalizeHtml(                                                                                            // 325
    renderToDiv(Template.test_helpers_g, dataObj).innerHTML);                                                         // 326
  test.equal(html.match(/\S+/g), [                                                                                    // 327
    'platypus=eggs',                                                                                                  // 328
    'this.platypus=weird'                                                                                             // 329
  ]);                                                                                                                 // 330
                                                                                                                      // 331
  // test interpretation of arguments                                                                                 // 332
                                                                                                                      // 333
  Template.test_helpers_h.helperListFour = listFour;                                                                  // 334
                                                                                                                      // 335
  html = canonicalizeHtml(                                                                                            // 336
    renderToDiv(Template.test_helpers_h, dataObj).innerHTML);                                                         // 337
  var trials =                                                                                                        // 338
        html.match(/\(.*?\)/g);                                                                                       // 339
  test.equal(trials[0],                                                                                               // 340
             '(methodListFour 6 7 8 9=6 7 8 9)');                                                                     // 341
  test.equal(trials[1],                                                                                               // 342
             '(methodListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns=eggs leaf guava 0)');
  test.equal(trials[2],                                                                                               // 344
             '(methodListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns a=platypus b=thisTest c=fancyhelper.currentFruit d=fancyhelper.currentCountry.unicorns=eggs leaf guava 0 a:eggs b:leaf c:guava d:0)');
  test.equal(trials[3],                                                                                               // 346
             '(helperListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns=eggs leaf guava 0)');
  test.equal(trials[4],                                                                                               // 348
             '(helperListFour platypus thisTest fancyhelper.currentFruit fancyhelper.currentCountry.unicorns a=platypus b=thisTest c=fancyhelper.currentFruit d=fancyhelper.currentCountry.unicorns=eggs leaf guava 0 a:eggs b:leaf c:guava d:0)');
  test.equal(trials.length, 5);                                                                                       // 350
                                                                                                                      // 351
});                                                                                                                   // 352
                                                                                                                      // 353
                                                                                                                      // 354
Tinytest.add("spacebars-tests - templating_tests - rendered template", function(test) {                               // 355
  var R = ReactiveVar('foo');                                                                                         // 356
  Template.test_render_a.foo = function() {                                                                           // 357
    R.get();                                                                                                          // 358
    return this.x + 1;                                                                                                // 359
  };                                                                                                                  // 360
                                                                                                                      // 361
  var div = renderToDiv(Template.test_render_a, {x: 123});                                                            // 362
  test.equal($(div).text().match(/\S+/)[0], "124");                                                                   // 363
                                                                                                                      // 364
  var br1 = div.getElementsByTagName('br')[0];                                                                        // 365
  var hr1 = div.getElementsByTagName('hr')[0];                                                                        // 366
  test.isTrue(br1);                                                                                                   // 367
  test.isTrue(hr1);                                                                                                   // 368
                                                                                                                      // 369
  R.set('bar');                                                                                                       // 370
  Deps.flush();                                                                                                       // 371
  var br2 = div.getElementsByTagName('br')[0];                                                                        // 372
  var hr2 = div.getElementsByTagName('hr')[0];                                                                        // 373
  test.isTrue(br2);                                                                                                   // 374
  test.isTrue(br1 === br2);                                                                                           // 375
  test.isTrue(hr2);                                                                                                   // 376
  test.isTrue(hr1 === hr2);                                                                                           // 377
                                                                                                                      // 378
  Deps.flush();                                                                                                       // 379
                                                                                                                      // 380
  /////                                                                                                               // 381
                                                                                                                      // 382
  R = ReactiveVar('foo');                                                                                             // 383
                                                                                                                      // 384
  Template.test_render_b.foo = function() {                                                                           // 385
    R.get();                                                                                                          // 386
    return (+this) + 1;                                                                                               // 387
  };                                                                                                                  // 388
                                                                                                                      // 389
  div = renderToDiv(Template.test_render_b, {x: 123});                                                                // 390
  test.equal($(div).text().match(/\S+/)[0], "201");                                                                   // 391
                                                                                                                      // 392
  var br1 = div.getElementsByTagName('br')[0];                                                                        // 393
  var hr1 = div.getElementsByTagName('hr')[0];                                                                        // 394
  test.isTrue(br1);                                                                                                   // 395
  test.isTrue(hr1);                                                                                                   // 396
                                                                                                                      // 397
  R.set('bar');                                                                                                       // 398
  Deps.flush();                                                                                                       // 399
  var br2 = div.getElementsByTagName('br')[0];                                                                        // 400
  var hr2 = div.getElementsByTagName('hr')[0];                                                                        // 401
  test.isTrue(br2);                                                                                                   // 402
  test.isTrue(br1 === br2);                                                                                           // 403
  test.isTrue(hr2);                                                                                                   // 404
  test.isTrue(hr1 === hr2);                                                                                           // 405
                                                                                                                      // 406
  Deps.flush();                                                                                                       // 407
                                                                                                                      // 408
});                                                                                                                   // 409
                                                                                                                      // 410
Tinytest.add("spacebars-tests - templating_tests - template arg", function (test) {                                   // 411
  Template.test_template_arg_a.events({                                                                               // 412
    click: function (event, template) {                                                                               // 413
      template.firstNode.innerHTML = 'Hello';                                                                         // 414
      template.lastNode.innerHTML = 'World';                                                                          // 415
      template.find('i').innerHTML =                                                                                  // 416
        (template.findAll('*').length)+"-element";                                                                    // 417
      template.lastNode.innerHTML += ' (the secret is '+                                                              // 418
        template.secret+')';                                                                                          // 419
    }                                                                                                                 // 420
  });                                                                                                                 // 421
                                                                                                                      // 422
  Template.test_template_arg_a.created = function() {                                                                 // 423
    var self = this;                                                                                                  // 424
    test.isFalse(self.firstNode);                                                                                     // 425
    test.isFalse(self.lastNode);                                                                                      // 426
    test.throws(function () { return self.find("*"); });                                                              // 427
    test.throws(function () { return self.findAll("*"); });                                                           // 428
  };                                                                                                                  // 429
                                                                                                                      // 430
  Template.test_template_arg_a.rendered = function () {                                                               // 431
    var template = this;                                                                                              // 432
    template.firstNode.innerHTML = 'Greetings';                                                                       // 433
    template.lastNode.innerHTML = 'Line';                                                                             // 434
    template.find('i').innerHTML =                                                                                    // 435
      (template.findAll('b').length)+"-bold";                                                                         // 436
    template.secret = "strawberry "+template.data.food;                                                               // 437
  };                                                                                                                  // 438
                                                                                                                      // 439
  Template.test_template_arg_a.destroyed = function() {                                                               // 440
    var self = this;                                                                                                  // 441
    test.isFalse(self.firstNode);                                                                                     // 442
    test.isFalse(self.lastNode);                                                                                      // 443
    test.throws(function () { return self.find("*"); });                                                              // 444
    test.throws(function () { return self.findAll("*"); });                                                           // 445
  };                                                                                                                  // 446
                                                                                                                      // 447
  var div = renderToDiv(Template.test_template_arg_a, {food: "pie"});                                                 // 448
  var cleanupDiv = addToBody(div);                                                                                    // 449
  Deps.flush(); // cause `rendered` to be called                                                                      // 450
  test.equal($(div).text(), "Greetings 1-bold Line");                                                                 // 451
  clickElement(div.querySelector('i'));                                                                               // 452
  test.equal($(div).text(), "Hello 3-element World (the secret is strawberry pie)");                                  // 453
                                                                                                                      // 454
  cleanupDiv();                                                                                                       // 455
  Deps.flush();                                                                                                       // 456
});                                                                                                                   // 457
                                                                                                                      // 458
Tinytest.add("spacebars-tests - templating_tests - helpers", function (test) {                                        // 459
  var tmpl = Template.test_template_helpers_a;                                                                        // 460
                                                                                                                      // 461
  tmpl.foo = 'z';                                                                                                     // 462
  tmpl.helpers({bar: 'b'});                                                                                           // 463
  // helpers(...) takes precendence of assigned helper                                                                // 464
  tmpl.helpers({foo: 'a', baz: function() { return 'c'; }});                                                          // 465
                                                                                                                      // 466
  var div = renderToDiv(tmpl);                                                                                        // 467
  test.equal($(div).text().match(/\S+/)[0], 'abc');                                                                   // 468
  Deps.flush();                                                                                                       // 469
                                                                                                                      // 470
  tmpl = Template.test_template_helpers_b;                                                                            // 471
                                                                                                                      // 472
  tmpl.helpers({                                                                                                      // 473
    'name': 'A',                                                                                                      // 474
    'arity': 'B',                                                                                                     // 475
    'toString': 'C',                                                                                                  // 476
    'length': 4,                                                                                                      // 477
    'var': 'D'                                                                                                        // 478
  });                                                                                                                 // 479
                                                                                                                      // 480
  div = renderToDiv(tmpl);                                                                                            // 481
  var txt = $(div).text();                                                                                            // 482
  txt = txt.replace('[object Object]', 'X'); // IE 8                                                                  // 483
  txt = txt.match(/\S+/)[0];                                                                                          // 484
  test.isTrue(txt.match(/^AB[CX]4D$/));                                                                               // 485
  // We don't make helpers with names like toString work in IE 8.                                                     // 486
  test.expect_fail();                                                                                                 // 487
  test.equal(txt, 'ABC4D');                                                                                           // 488
  Deps.flush();                                                                                                       // 489
                                                                                                                      // 490
  // test that helpers don't "leak"                                                                                   // 491
  tmpl = Template.test_template_helpers_c;                                                                            // 492
  div = renderToDiv(tmpl);                                                                                            // 493
  test.equal($(div).text(), 'x');                                                                                     // 494
  Deps.flush();                                                                                                       // 495
});                                                                                                                   // 496
                                                                                                                      // 497
Tinytest.add("spacebars-tests - templating_tests - events", function (test) {                                         // 498
  var tmpl = Template.test_template_events_a;                                                                         // 499
                                                                                                                      // 500
  var buf = [];                                                                                                       // 501
                                                                                                                      // 502
  // old style                                                                                                        // 503
  tmpl.events = {                                                                                                     // 504
    'click b': function () { buf.push('b'); }                                                                         // 505
  };                                                                                                                  // 506
                                                                                                                      // 507
  var div = renderToDiv(tmpl);                                                                                        // 508
  var cleanupDiv = addToBody(div);                                                                                    // 509
  clickElement($(div).find('b')[0]);                                                                                  // 510
  test.equal(buf, ['b']);                                                                                             // 511
  cleanupDiv();                                                                                                       // 512
  Deps.flush();                                                                                                       // 513
                                                                                                                      // 514
  ///                                                                                                                 // 515
                                                                                                                      // 516
  tmpl = Template.test_template_events_b;                                                                             // 517
  buf = [];                                                                                                           // 518
  // new style                                                                                                        // 519
  tmpl.events({                                                                                                       // 520
    'click u': function () { buf.push('u'); }                                                                         // 521
  });                                                                                                                 // 522
  tmpl.events({                                                                                                       // 523
    'click i': function () { buf.push('i'); }                                                                         // 524
  });                                                                                                                 // 525
                                                                                                                      // 526
  div = renderToDiv(tmpl);                                                                                            // 527
  cleanupDiv = addToBody(div);                                                                                        // 528
  clickElement($(div).find('u')[0]);                                                                                  // 529
  clickElement($(div).find('i')[0]);                                                                                  // 530
  test.equal(buf, ['u', 'i']);                                                                                        // 531
  cleanupDiv();                                                                                                       // 532
  Deps.flush();                                                                                                       // 533
                                                                                                                      // 534
  //Test for identical callbacks for issue #650                                                                       // 535
  tmpl = Template.test_template_events_c;                                                                             // 536
  buf = [];                                                                                                           // 537
  tmpl.events({                                                                                                       // 538
    'click u': function () { buf.push('a'); }                                                                         // 539
  });                                                                                                                 // 540
  tmpl.events({                                                                                                       // 541
    'click u': function () { buf.push('b'); }                                                                         // 542
  });                                                                                                                 // 543
                                                                                                                      // 544
  div = renderToDiv(tmpl);                                                                                            // 545
  cleanupDiv = addToBody(div);                                                                                        // 546
  clickElement($(div).find('u')[0]);                                                                                  // 547
  test.equal(buf.length, 2);                                                                                          // 548
  test.isTrue(_.contains(buf, 'a'));                                                                                  // 549
  test.isTrue(_.contains(buf, 'b'));                                                                                  // 550
  cleanupDiv();                                                                                                       // 551
  Deps.flush();                                                                                                       // 552
});                                                                                                                   // 553
                                                                                                                      // 554
                                                                                                                      // 555
Tinytest.add('spacebars-tests - templating_tests - helper typecast Issue #617', function (test) {                     // 556
                                                                                                                      // 557
  UI.registerHelper('testTypeCasting', function (/*arguments*/) {                                                     // 558
    // Return a string representing the arguments passed to this                                                      // 559
    // function, including types. eg:                                                                                 // 560
    // (1, true) -> "[number,1][boolean,true]"                                                                        // 561
    return _.reduce(_.toArray(arguments), function (memo, arg) {                                                      // 562
      if (typeof arg === 'object')                                                                                    // 563
        return memo + "[object]";                                                                                     // 564
      return memo + "[" + typeof arg + "," + arg + "]";                                                               // 565
    }, "");                                                                                                           // 566
    return x;                                                                                                         // 567
  });                                                                                                                 // 568
                                                                                                                      // 569
  var div = renderToDiv(Template.test_type_casting);                                                                  // 570
  var result = canonicalizeHtml(div.innerHTML);                                                                       // 571
  test.equal(                                                                                                         // 572
    result,                                                                                                           // 573
    // This corresponds to entries in templating_tests.html.                                                          // 574
    // true/faslse                                                                                                    // 575
    "[string,true][string,false][boolean,true][boolean,false]" +                                                      // 576
      // numbers                                                                                                      // 577
      "[number,0][number,1][number,-1][number,10][number,-10]" +                                                      // 578
      // handlebars 'options' argument. appended to args of all helpers.                                              // 579
      "[object]");                                                                                                    // 580
});                                                                                                                   // 581
                                                                                                                      // 582
Tinytest.add('spacebars-tests - templating_tests - each falsy Issue #801', function (test) {                          // 583
  //Minor test for issue #801 (#each over array containing nulls)                                                     // 584
  Template.test_template_issue801.values = function() { return [0,1,2,null,undefined,false]; };                       // 585
  var div = renderToDiv(Template.test_template_issue801);                                                             // 586
  test.equal(canonicalizeHtml(div.innerHTML), "012");                                                                 // 587
});                                                                                                                   // 588
                                                                                                                      // 589
Tinytest.add('spacebars-tests - templating_tests - duplicate template error', function (test) {                       // 590
  Template.__define__("test_duplicate_template", function () {});                                                     // 591
  test.throws(function () {                                                                                           // 592
    Template.__define__("test_duplicate_template", function () {});                                                   // 593
  });                                                                                                                 // 594
});                                                                                                                   // 595
                                                                                                                      // 596
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
