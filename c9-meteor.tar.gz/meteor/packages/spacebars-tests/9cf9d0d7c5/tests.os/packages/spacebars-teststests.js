(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/spacebars-tests/template_tests_server.js                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var path = Npm.require("path");                                      // 1
                                                                     // 2
Meteor.methods({                                                     // 3
  getAsset: function (filename) {                                    // 4
    return Assets.getText(path.join("assets", filename));            // 5
  }                                                                  // 6
});                                                                  // 7
                                                                     // 8
///////////////////////////////////////////////////////////////////////

}).call(this);
