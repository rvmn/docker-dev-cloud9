(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/stylus/template.stylus_tests.js                                             //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
                                                                                        // 1
Template.__define__("stylus_test_presence", (function() {                               // 2
  var view = this;                                                                      // 3
  return HTML.Raw('<p class="stylus-dashy-left-border"></p>');                          // 4
}));                                                                                    // 5
                                                                                        // 6
Template.__define__("stylus_test_import", (function() {                                 // 7
  var view = this;                                                                      // 8
  return HTML.Raw('<p class="stylus-import-dashy-border stylus-overwrite-color"></p>'); // 9
}));                                                                                    // 10
                                                                                        // 11
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/stylus/stylus_tests.js                                                      //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
                                                                                        // 1
Tinytest.add("stylus - presence", function(test) {                                      // 2
                                                                                        // 3
  var div = document.createElement('div');                                              // 4
  Blaze.render(Template.stylus_test_presence).attach(div);                              // 5
  div.style.display = 'block';                                                          // 6
  document.body.appendChild(div);                                                       // 7
                                                                                        // 8
  var p = div.querySelector('p');                                                       // 9
  var leftBorder = getStyleProperty(p, 'border-left-style');                            // 10
  test.equal(leftBorder, "dashed");                                                     // 11
                                                                                        // 12
  document.body.removeChild(div);                                                       // 13
});                                                                                     // 14
                                                                                        // 15
Tinytest.add("stylus - @import", function(test) {                                       // 16
  var div = document.createElement('div');                                              // 17
  Blaze.render(Template.stylus_test_import).attach(div);                                // 18
  div.style.display = 'block';                                                          // 19
  document.body.appendChild(div);                                                       // 20
                                                                                        // 21
  var p = div.querySelector('p');                                                       // 22
  test.equal(getStyleProperty(p, 'font-size'), "20px");                                 // 23
  test.equal(getStyleProperty(p, 'border-left-style'), "dashed");                       // 24
                                                                                        // 25
  document.body.removeChild(div);                                                       // 26
});                                                                                     // 27
                                                                                        // 28
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
